
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/generate-daily-brief.ts
import { createClient as createClient2 } from "@supabase/supabase-js";

// netlify/functions/scheduled-daily-brief.ts
import { createClient } from "@supabase/supabase-js";
import { Resend } from "resend";

// netlify/lib/clean-ai-output.ts
function cleanAIOutput(text) {
  return text.replace(/\s—\s/g, ", ").replace(/—/g, " - ").replace(/\s–\s/g, ", ").replace(/\bIn conclusion,?\s*/gi, "").replace(/\bTo summarize,?\s*/gi, "").replace(/\bIt is worth noting that\s*/gi, "").replace(/\bIt is important to note that\s*/gi, "").replace(/\bNotably,?\s*/gi, "").replace(/\bFurthermore,?\s*/gi, "").replace(/\bMoreover,?\s*/gi, "").replace(/\bAdditionally,?\s*/gi, "").replace(/\bIn other words,?\s*/gi, "").replace(/\bAs previously mentioned,?\s*/gi, "").replace(/\bAs we can see,?\s*/gi, "").replace(/\bIt goes without saying\s*/gi, "").replace(/\bNeedless to say,?\s*/gi, "").replace(/\bAt the end of the day,?\s*/gi, "").replace(/\bWith that said,?\s*/gi, "").replace(/\bThat being said,?\s*/gi, "").replace(/\bHaving said that,?\s*/gi, "").replace(/  +/g, " ").replace(/\s,/g, ",").trim();
}

// netlify/functions/scheduled-daily-brief.ts
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
function sb() {
  return createClient(supabaseUrl, supabaseServiceKey);
}
async function getRelevantSermonContext(supabase, topic) {
  try {
    const searchTerms = topic || [
      "deliverance",
      "spiritual warfare",
      "freedom",
      "authority",
      "healing",
      "generational",
      "prayer"
    ][Math.floor(Math.random() * 7)];
    const { data } = await supabase.from("library_chunks").select("content, book_title, chunk_index").ilike("content", `%${searchTerms}%`).limit(5).order("created_at", { ascending: false });
    if (!data || data.length === 0) return "";
    const context = data.map((c) => `[From: ${c.book_title}]
${c.content}`).join("\n\n---\n\n");
    return `

SOURCE MATERIAL FROM PASTOR JUSTIN'S SERMONS:
${context}

Use the above sermon content as the primary source and inspiration for the devotional. Draw from the language, illustrations, and theological points found in these excerpts. The devotional should feel like it came from these teachings.`;
  } catch {
    return "";
  }
}
async function buildDailyBrief(date) {
  const client = sb();
  const { data: ctxRow } = await client.from("ministry_context").select("context_text").eq("is_active", true).single();
  const ministryContext = ctxRow?.context_text || "War Room Intel \u2014 a deliverance ministry resource for serious ministers of spiritual warfare.";
  const dayOfWeek = (/* @__PURE__ */ new Date(date + "T12:00:00")).toLocaleDateString("en-US", { weekday: "long" });
  const fullDate = (/* @__PURE__ */ new Date(date + "T12:00:00")).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
  const sermonContext = await getRelevantSermonContext(client);
  const prompt = `Generate a complete War Room Intel Daily Brief for ${dayOfWeek}, ${fullDate}.

This is for serious ministers and students of spiritual warfare. Ground every section in scripture.

Return ONLY valid JSON with this exact structure (no markdown, no explanation):
{
  "title": "A compelling title for today's devotion (10 words max)",
  "morning_prayer": "A focused morning intercession prayer for spiritual warriors (2-3 paragraphs, first person plural)",
  "scripture": "The full scripture text for today (1-3 verses)",
  "scripture_reference": "Book Chapter:Verse format (e.g. Ephesians 6:10-12)",
  "devotional_text": "A substantive devotional message (400-600 words, grounded in deliverance ministry principles, practical application)",
  "evening_prayer": "An evening prayer of declaration and thanksgiving (1-2 paragraphs)"
}` + sermonContext;
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 3e3,
      system: ministryContext,
      messages: [{ role: "user", content: prompt }]
    }),
    signal: AbortSignal.timeout(55e3)
  });
  if (!res.ok) throw new Error(`Claude API error: ${res.status}`);
  const data = await res.json();
  const text = (data.content?.[0]?.text || "").trim();
  const jsonMatch = text.match(/\{[\s\S]*\}/);
  if (!jsonMatch) throw new Error("No JSON in response");
  const parsed = JSON.parse(jsonMatch[0]);
  return {
    title: parsed.title,
    morning_prayer: cleanAIOutput(parsed.morning_prayer || ""),
    scripture: parsed.scripture,
    scripture_reference: parsed.scripture_reference,
    devotional_text: cleanAIOutput(parsed.devotional_text || ""),
    evening_prayer: cleanAIOutput(parsed.evening_prayer || "")
  };
}

// netlify/functions/generate-daily-brief.ts
var { url: supabaseUrl2, serviceRoleKey: supabaseServiceKey2 } = JSON.parse(process.env.SUPABASE || "{}");
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function sb2() {
  return createClient2(supabaseUrl2, supabaseServiceKey2);
}
async function resolveMinister(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return false;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return false;
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return false;
    const data = await res.json();
    return data?.public_metadata?.role === "minister";
  } catch {
    return false;
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: HEADERS });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "POST required" }), { status: 405, headers: HEADERS });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: HEADERS });
  const isMinister = await resolveMinister(token);
  if (!isMinister) return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: HEADERS });
  const body = await req.json().catch(() => ({}));
  const date = body.date || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const brief = await buildDailyBrief(date);
  if (!brief) return new Response(JSON.stringify({ error: "Generation failed" }), { status: 500, headers: HEADERS });
  const client = sb2();
  const { data, error } = await client.from("daily_devotions").insert({
    date,
    title: brief.title,
    morning_prayer: brief.morning_prayer,
    scripture: brief.scripture,
    scripture_reference: brief.scripture_reference,
    devotional_text: brief.devotional_text,
    evening_prayer: brief.evening_prayer,
    min_tier: "watchman",
    published: false,
    created_by: "ai-agent"
  }).select().single();
  if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: HEADERS });
  return new Response(JSON.stringify({ success: true, devotion: data }), { status: 200, headers: HEADERS });
}
var config = { path: "/api/generate-daily-brief" };
export {
  config,
  handler as default
};
