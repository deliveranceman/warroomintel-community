
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/getMinistryContext.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var _cached = null;
var _cacheExpiry = 0;
async function getMinistryContext() {
  if (_cached !== null && Date.now() < _cacheExpiry) return _cached;
  try {
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { data } = await supabase.from("ministry_context").select("context_text").eq("is_active", true).single();
    const text = data?.context_text || "";
    _cached = text;
    _cacheExpiry = Date.now() + 6e4;
    return text;
  } catch {
    return "";
  }
}

// netlify/lib/ai-rate-limit.ts
import { createClient as createClient2 } from "@supabase/supabase-js";
var { url: supabaseUrl2, serviceRoleKey: supabaseServiceKey2 } = JSON.parse(process.env.SUPABASE || "{}");
async function checkAndIncrementUsage(_userId, _tier, _feature) {
  return { allowed: true, remaining: 999, limit: 999, current: 0 };
}
var FEATURE_LABELS = {
  ask_dake: "Ask Dake",
  ai_assistant: "AI Assistant",
  bible_ask: "Bible Study AI",
  symptom_investigator: "Symptom Investigator",
  gateway: "Gateway Investigator",
  dream: "Dream Interpreter",
  document: "Document Creator",
  session_ai: "Session AI",
  assessment: "Assessment Strategy"
};
function getUpgradeMessage(tier, feature) {
  const tiers = {
    watchman: "Soldier",
    free: "Soldier",
    soldier: "Commander",
    charter_soldier: "Commander",
    commander: "General",
    charter_commander: "General"
  };
  const nextTier = tiers[tier];
  const label = FEATURE_LABELS[feature] || feature;
  if (!nextTier) return `You have reached your daily limit for ${label}.`;
  return `Daily limit reached for ${label}. Upgrade to ${nextTier} for more.`;
}

// netlify/lib/clean-ai-output.ts
function cleanAIOutput(text) {
  return text.replace(/\s—\s/g, ", ").replace(/—/g, " - ").replace(/\s–\s/g, ", ").replace(/\bIn conclusion,?\s*/gi, "").replace(/\bTo summarize,?\s*/gi, "").replace(/\bIt is worth noting that\s*/gi, "").replace(/\bIt is important to note that\s*/gi, "").replace(/\bNotably,?\s*/gi, "").replace(/\bFurthermore,?\s*/gi, "").replace(/\bMoreover,?\s*/gi, "").replace(/\bAdditionally,?\s*/gi, "").replace(/\bIn other words,?\s*/gi, "").replace(/\bAs previously mentioned,?\s*/gi, "").replace(/\bAs we can see,?\s*/gi, "").replace(/\bIt goes without saying\s*/gi, "").replace(/\bNeedless to say,?\s*/gi, "").replace(/\bAt the end of the day,?\s*/gi, "").replace(/\bWith that said,?\s*/gi, "").replace(/\bThat being said,?\s*/gi, "").replace(/\bHaving said that,?\s*/gi, "").replace(/  +/g, " ").replace(/\s,/g, ",").trim();
}

// netlify/functions/dream-interpreter.ts
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
var { url: _sbUrl, serviceRoleKey: _sbKey } = JSON.parse(process.env.SUPABASE || "{}");
async function resolveUser(token) {
  try {
    if (!token || token.split(".").length !== 3) return { ok: false, tier: "", userId: "" };
    const payload = JSON.parse(Buffer.from(token.split(".")[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return { ok: false, tier: "", userId: "" };
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return { ok: false, tier: "", userId: "" };
    const data = await res.json();
    const role = data?.public_metadata?.role;
    const tier = data?.public_metadata?.tier || "";
    const lvl = (t) => ({ free: 0, watchman: 0, soldier: 1, commander: 2, general: 3, minister: 99 })[t?.toLowerCase()] ?? 0;
    return { ok: role === "minister" || lvl(tier) >= 1, tier, userId };
  } catch {
    return { ok: false, tier: "", userId: "" };
  }
}
async function callClaude(dreamDescription, dreamerContext) {
  const systemPrompt = `You are a prophetic and spiritual dream interpreter for deliverance ministers.
You analyze dreams through three lenses:
1. Biblical/Prophetic \u2014 what God may be communicating through symbols and narrative; specific Scripture references
2. Spiritual Warfare \u2014 demonic assignments, open doors, or strongholds revealed in the dream
3. Soulical/Trauma \u2014 unresolved wounds, fears, or soul wounds manifesting symbolically

You draw from Scripture, prophetic tradition, and deliverance ministry practice.
You name spirits, legal grounds, and Scripture references specifically \u2014 no vague generalities.
You MUST respond with ONLY a valid JSON object.
Do NOT include any text before or after the JSON.
Do NOT use markdown code fences.
Start your response with { and end with }.`;
  const userPrompt = `Analyze this dream from a deliverance ministry perspective.

Dream: ${dreamDescription}
${dreamerContext ? `
Dreamer context: ${dreamerContext}` : ""}

Return this exact JSON structure:
{
  "verdict": "prophetic" | "warning" | "deliverance" | "trauma" | "mixed",
  "summary": "2-3 sentence executive summary for a deliverance minister \u2014 what is happening spiritually",
  "sections": [
    {
      "title": "Key Symbols",
      "items": ["Symbol \u2014 Biblical/spiritual meaning with Scripture if applicable", "Symbol 2 \u2014 meaning"]
    },
    {
      "title": "Prophetic Message",
      "items": ["Specific message, direction, or confirmation God may be communicating", "Scripture reference and application: Book Chapter:Verse \u2014 quote"]
    },
    {
      "title": "Warfare Indicators",
      "items": ["Specific demonic assignment or open door identified in the dream", "Legal ground, stronghold, or spirit named (if applicable)"]
    },
    {
      "title": "Prayer Response",
      "items": ["Declaration: specific proclamation to make over this person", "Renunciation: specific thing to renounce if warfare element present", "Scripture to stand on: Book Chapter:Verse \u2014 quote"]
    },
    {
      "title": "Follow-Up Questions",
      "items": ["Specific intake question based on dream content", "Pattern question: Is there a recurring...?"]
    }
  ]
}

Rules:
- Name specific Scripture by Book Chapter:Verse
- Name specific spirits if indicated
- Keep verdict to one of the five exact values
- Each section must have 2-5 specific, actionable items
- Return ONLY the JSON. Nothing else.`;
  const ministryContext = await getMinistryContext();
  const effectiveSystem = ministryContext ? `${ministryContext}

---

${systemPrompt}` : systemPrompt;
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 2e3,
      system: effectiveSystem,
      messages: [{ role: "user", content: userPrompt }]
    }),
    signal: AbortSignal.timeout(25e3)
  });
  if (!res.ok) throw new Error(`Claude error ${res.status}`);
  const data = await res.json();
  const rawText = cleanAIOutput((data.content?.[0]?.text || "").trim());
  let result = null;
  try {
    result = JSON.parse(rawText);
  } catch {
  }
  if (!result) {
    try {
      const stripped = rawText.replace(/^```json\s*/im, "").replace(/^```\s*/im, "").replace(/```\s*$/im, "").trim();
      result = JSON.parse(stripped);
    } catch {
    }
  }
  if (!result) {
    try {
      const match = rawText.match(/\{[\s\S]*\}/);
      if (match) result = JSON.parse(match[0]);
    } catch {
    }
  }
  if (!result) {
    result = {
      verdict: "mixed",
      summary: "Analysis complete \u2014 see content below.",
      sections: [{ title: "Dream Analysis", items: [rawText] }]
    };
  }
  return result;
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: HEADERS });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "POST required" }), { status: 405, headers: HEADERS });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: HEADERS });
  const auth = await resolveUser(token);
  if (!auth.ok) return new Response(JSON.stringify({ error: "Soldier tier or higher required" }), { status: 403, headers: HEADERS });
  const usage = await checkAndIncrementUsage(auth.userId, auth.tier || "watchman", "dream");
  if (!usage.allowed) {
    return new Response(JSON.stringify({ error: getUpgradeMessage(auth.tier || "watchman", "dream"), rateLimited: true, limit: usage.limit, remaining: 0 }), { status: 429, headers: HEADERS });
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: HEADERS });
  }
  const { dreamDescription = "", dreamerContext = "" } = body || {};
  if (!dreamDescription?.trim()) {
    return new Response(JSON.stringify({ error: "dreamDescription is required" }), { status: 400, headers: HEADERS });
  }
  if (dreamDescription.trim().length < 20) {
    return new Response(JSON.stringify({ error: "Please describe the dream in more detail (at least 20 characters)." }), { status: 400, headers: HEADERS });
  }
  try {
    const report = await callClaude(dreamDescription.trim(), dreamerContext?.trim() || "");
    if (auth.userId && _sbUrl && _sbKey) {
      fetch(`${_sbUrl}/rest/v1/ai_search_history`, {
        method: "POST",
        headers: { apikey: _sbKey, Authorization: `Bearer ${_sbKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ user_id: auth.userId, tool: "dream-interpreter", query: dreamDescription.trim().slice(0, 500), response: JSON.stringify(report).slice(0, 1e3), context: {} })
      }).catch(() => {
      });
    }
    return new Response(JSON.stringify(report), { status: 200, headers: HEADERS });
  } catch (e) {
    console.error("[dream-interpreter] Error:", e.message);
    return new Response(JSON.stringify({ error: e.message || "Interpretation failed" }), { status: 500, headers: HEADERS });
  }
}
var config = { path: "/api/dream-interpreter" };
export {
  config,
  handler as default
};
