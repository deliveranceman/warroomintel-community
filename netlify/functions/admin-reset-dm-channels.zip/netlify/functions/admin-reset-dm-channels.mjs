
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-reset-dm-channels.ts
import { createHmac } from "crypto";
var KEEP = /* @__PURE__ */ new Set(["war-room-general", "prayer-wall-requests"]);
function makeServerToken(apiSecret) {
  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
  const payload = Buffer.from(JSON.stringify({ server: true })).toString("base64url");
  const sig = createHmac("sha256", apiSecret).update(`${header}.${payload}`).digest("base64url");
  return `${header}.${payload}.${sig}`;
}
function streamFetch(path, method, token, apiKey, body) {
  return fetch(`https://chat.stream-io-api.com${path}?api_key=${apiKey}`, {
    method,
    headers: { "Content-Type": "application/json", "Authorization": token, "Stream-Auth-Type": "jwt" },
    ...body ? { body: JSON.stringify(body) } : {}
  }).then((r) => r.json());
}
var admin_reset_dm_channels_default = async (req, _context) => {
  if (req.headers.get("x-admin-secret") !== process.env.ADMIN_SECRET) {
    return new Response(JSON.stringify({ error: "Forbidden" }), {
      status: 403,
      headers: { "Content-Type": "application/json" }
    });
  }
  const stream = JSON.parse(process.env.STREAM || "{}");
  const streamApiKey = stream.apiKey;
  const streamApiSecret = stream.apiSecret;
  const apiKey = streamApiKey;
  const apiSecret = streamApiSecret;
  if (!apiKey || !apiSecret) {
    return new Response(JSON.stringify({ error: "Stream not configured" }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
  try {
    const token = makeServerToken(apiSecret);
    const data = await streamFetch("/channels", "POST", token, apiKey, {
      filter_conditions: { type: "messaging" },
      limit: 30
    });
    const channels = data.channels || [];
    const toDelete = channels.filter((ch) => {
      const id = ch.channel?.id || ch.id;
      return id && !KEEP.has(id);
    });
    const deletedIds = [];
    const errors = [];
    for (const ch of toDelete) {
      const id = ch.channel?.id || ch.id;
      try {
        await streamFetch(`/channels/messaging/${id}`, "DELETE", token, apiKey);
        deletedIds.push(id);
      } catch (err) {
        console.error(`Failed to delete channel ${id}:`, err.message);
        errors.push(id);
      }
    }
    return new Response(
      JSON.stringify({ deleted: deletedIds.length, ids: deletedIds, errors }),
      { status: 200, headers: { "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("admin-reset-dm-channels error:", err);
    return new Response(JSON.stringify({ error: err.message || "Stream error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
var config = { path: "/api/admin-reset-dm-channels" };
export {
  config,
  admin_reset_dm_channels_default as default
};
