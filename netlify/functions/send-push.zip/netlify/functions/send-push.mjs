
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/send-push.ts
import { createClient } from "@supabase/supabase-js";

// netlify/functions/_shared/sendWebPush.ts
import webpush from "web-push";
function getVapid() {
  const json = JSON.parse(process.env.VAPID || "{}");
  const publicKey = process.env.VAPID_PUBLIC_KEY || json.publicKey || "";
  const privateKey = process.env.VAPID_PRIVATE_KEY || json.privateKey || "";
  const email = json.email || "exorcist@warroomintel.com";
  const contact = email.startsWith("mailto:") ? email : `mailto:${email}`;
  return { publicKey, privateKey, contact };
}
async function sendWebPushToUser(userId, title, body, extraData) {
  const { url: supabaseUrl2, serviceRoleKey } = JSON.parse(process.env.SUPABASE || "{}");
  const sbH = { apikey: serviceRoleKey, Authorization: `Bearer ${serviceRoleKey}` };
  const { publicKey, privateKey, contact } = getVapid();
  webpush.setVapidDetails(contact, publicKey, privateKey);
  const subRes = await fetch(
    `${supabaseUrl2}/rest/v1/push_subscriptions?user_id=eq.${encodeURIComponent(userId)}&select=id,user_id,endpoint,subscription`,
    { headers: sbH }
  );
  const rows = await subRes.json().catch(() => []);
  console.log(`[push] user=${userId} subscriptions=${Array.isArray(rows) ? rows.length : 0}`);
  if (!Array.isArray(rows) || rows.length === 0) {
    return { sent: 0, failed: 0, total: 0, errors: [] };
  }
  const payload = JSON.stringify({
    title,
    body,
    url: "/community",
    icon: "/icons/icon-192.png",
    badge: "/icons/badge-72.png",
    ...extraData ? { data: extraData } : {}
  });
  let sent = 0, failed = 0;
  const errors = [];
  for (const row of rows) {
    let pushSub;
    try {
      pushSub = typeof row.subscription === "string" ? JSON.parse(row.subscription) : row.subscription;
    } catch {
      failed++;
      errors.push({ id: row.id, statusCode: null, message: "Invalid subscription JSON" });
      continue;
    }
    try {
      await webpush.sendNotification(pushSub, payload, { TTL: 86400 });
      sent++;
      console.log(`[push] sent user=${userId} sub=${row.id}`);
    } catch (err) {
      failed++;
      const sc = err.statusCode ?? 0;
      errors.push({ id: row.id, statusCode: sc, message: err.body || err.message || String(err) });
      console.error(`[push] failed user=${userId} sub=${row.id} status=${sc} body=${err.body || err.message}`);
      if (sc === 410 || sc === 404 || sc === 400) {
        await fetch(
          `${supabaseUrl2}/rest/v1/push_subscriptions?id=eq.${encodeURIComponent(row.id)}`,
          { method: "DELETE", headers: sbH }
        ).catch(() => {
        });
        console.log(`[push] deleted stale sub ${row.id} (status=${sc})`);
      }
    }
  }
  return { sent, failed, total: rows.length, errors };
}

// netlify/functions/send-push.ts
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var _vapidJson = JSON.parse(process.env.VAPID || "{}");
var vapidPublicKey = process.env.VAPID_PUBLIC_KEY || _vapidJson.publicKey || "";
var vapidPrivateKey = process.env.VAPID_PRIVATE_KEY || _vapidJson.privateKey || "";
var HEADERS = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization"
};
function sb() {
  return createClient(supabaseUrl, supabaseServiceKey);
}
async function isMinisterToken(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return false;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return false;
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return false;
    const data = await res.json();
    return data?.public_metadata?.role === "minister";
  } catch {
    return false;
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("", { status: 204, headers: HEADERS });
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: HEADERS });
  }
  const receivedKey = req.headers.get("x-internal-key") || req.headers.get("x-api-key") || "";
  const validKey = process.env.INTERNAL_API_KEY || "wri-internal-2026-backfill";
  console.log("[send-push] received key:", receivedKey.slice(0, 10) + "...");
  console.log("[send-push] valid key:", validKey.slice(0, 10) + "...");
  console.log("[send-push] match:", receivedKey === validKey);
  const authHeader = req.headers.get("Authorization") || "";
  const token = authHeader.replace("Bearer ", "").trim();
  const isServiceKey = token === supabaseServiceKey;
  if (receivedKey !== validKey && !isServiceKey) {
    const minister = await isMinisterToken(token);
    if (!minister) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: HEADERS });
    }
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: HEADERS });
  }
  const { title, body: msgBody, url, userId } = body || {};
  if (!title) {
    return new Response(JSON.stringify({ error: "title is required" }), { status: 400, headers: HEADERS });
  }
  console.log("[send-push] Request:", { title, userId: userId || "all", url });
  if (!vapidPublicKey || !vapidPrivateKey) {
    console.error("[send-push] VAPID keys not configured");
    return new Response(JSON.stringify({ error: "VAPID keys not configured" }), { status: 500, headers: HEADERS });
  }
  const pushResult = await sendWebPushToUser(
    userId,
    title,
    msgBody || "New activity in the War Room",
    url ? { url } : void 0
  );
  console.log("[send-push] Done:", { sent: pushResult.sent, failed: pushResult.failed, total: pushResult.total });
  if (pushResult.total > 0) {
    try {
      const client = sb();
      await client.from("user_notifications").insert(
        [{ user_id: userId, title, body: msgBody || null, url: url || "/community" }]
      );
    } catch (e) {
      console.warn("[send-push] user_notifications insert failed:", e.message);
    }
  }
  return new Response(JSON.stringify(pushResult), { status: 200, headers: HEADERS });
}
var config = { path: "/api/send-push" };
export {
  config,
  handler as default
};
