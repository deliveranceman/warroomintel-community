
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/founding-general-count.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var headers = {
  "Access-Control-Allow-Origin": "*",
  "Content-Type": "application/json"
};
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  try {
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { count } = await supabase.from("founding_generals").select("*", { count: "exact", head: true });
    return new Response(JSON.stringify({ count: count ?? 0, cap: 100, remaining: Math.max(0, 100 - (count ?? 0)) }), { status: 200, headers });
  } catch {
    return new Response(JSON.stringify({ count: 0, cap: 100, remaining: 100 }), { status: 200, headers });
  }
}
var config = { path: "/api/founding-general-count" };
export {
  config,
  handler as default
};
