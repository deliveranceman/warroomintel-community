
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/send-email.ts
import { Resend } from "resend";
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
var FROM = "exorcist@warroomintel.com";
var ADMIN = "exorcist@warroomintel.com";
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: HEADERS });
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: HEADERS });
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: HEADERS });
  }
  const { type, to, name, submissionId, details } = body || {};
  if (!type || !to) {
    return new Response(JSON.stringify({ error: "type and to are required" }), { status: 400, headers: HEADERS });
  }
  const resend = new Resend(process.env.RESEND_API_KEY);
  let emailPayload;
  if (type === "intake-confirmation") {
    emailPayload = {
      from: FROM,
      to,
      subject: "Your Ministry Assessment Has Been Received \u2014 War Room Intel",
      html: `
        <div style="background:#08060e;color:#F4F0FC;font-family:Georgia,serif;max-width:600px;margin:0 auto;padding:40px 32px;border:1px solid rgba(201,168,76,0.2)">
          <div style="border-bottom:1px solid rgba(201,168,76,0.3);padding-bottom:20px;margin-bottom:28px">
            <p style="font-family:serif;font-size:11px;color:#C9A84C;letter-spacing:3px;text-transform:uppercase;margin:0 0 8px">WAR ROOM INTEL</p>
            <h1 style="font-size:22px;color:#C9A84C;margin:0;letter-spacing:1px">Assessment Received</h1>
          </div>
          <p style="font-size:16px;line-height:1.7;color:#e8e3d9">Dear ${name || "Warrior"},</p>
          <p style="font-size:15px;line-height:1.8;color:#b9b2a4">Your ministry assessment has been received and is now in review. Our team will personally respond to your submission. Please allow 24\u201372 hours for a response.</p>
          <p style="font-size:15px;line-height:1.8;color:#b9b2a4">In the meantime, you can access the War Room Intel community at <a href="https://warroomintel.com/community" style="color:#C9A84C">warroomintel.com</a>.</p>
          ${submissionId ? `<p style="font-family:monospace;font-size:11px;color:#605a4f;margin-top:28px">Reference: ${submissionId}</p>` : ""}
          <div style="margin-top:32px;padding-top:20px;border-top:1px solid rgba(201,168,76,0.2)">
            <p style="font-size:13px;color:#605a4f;margin:0">In His service,<br/>Pastor Justin Payne<br/>War Room Intel</p>
          </div>
        </div>
      `
    };
  } else if (type === "intake-admin") {
    emailPayload = {
      from: FROM,
      to: ADMIN,
      subject: `New Ministry Assessment \u2014 ${name || "Unknown"} (${to})`,
      html: `
        <div style="background:#08060e;color:#F4F0FC;font-family:monospace;max-width:600px;margin:0 auto;padding:32px;border:1px solid rgba(201,168,76,0.3)">
          <p style="font-size:11px;color:#C9A84C;letter-spacing:3px;text-transform:uppercase;margin:0 0 16px">NEW INTAKE SUBMISSION</p>
          <table style="width:100%;border-collapse:collapse;font-size:14px">
            <tr><td style="color:#8d8576;padding:6px 0;width:140px;vertical-align:top">Name</td><td style="color:#f4ecdb">${name || "\u2014"}</td></tr>
            <tr><td style="color:#8d8576;padding:6px 0;vertical-align:top">Email</td><td style="color:#f4ecdb">${to}</td></tr>
            ${details?.phone ? `<tr><td style="color:#8d8576;padding:6px 0;vertical-align:top">Phone</td><td style="color:#f4ecdb">${details.phone}</td></tr>` : ""}
            ${details?.issues?.length ? `<tr><td style="color:#8d8576;padding:6px 0;vertical-align:top">Issues</td><td style="color:#f4ecdb">${details.issues.join(", ")}</td></tr>` : ""}
            ${details?.duration ? `<tr><td style="color:#8d8576;padding:6px 0;vertical-align:top">Duration</td><td style="color:#f4ecdb">${details.duration}</td></tr>` : ""}
            ${details?.received_before !== void 0 ? `<tr><td style="color:#8d8576;padding:6px 0;vertical-align:top">Prior Ministry</td><td style="color:#f4ecdb">${details.received_before ? "Yes" : "No"}</td></tr>` : ""}
            ${details?.contact_method ? `<tr><td style="color:#8d8576;padding:6px 0;vertical-align:top">Contact Via</td><td style="color:#f4ecdb">${details.contact_method}</td></tr>` : ""}
            ${submissionId ? `<tr><td style="color:#8d8576;padding:6px 0;vertical-align:top">ID</td><td style="color:#605a4f;font-size:12px">${submissionId}</td></tr>` : ""}
          </table>
          ${details?.description ? `
          <div style="margin-top:20px;padding:16px;background:#0d0b14;border:1px solid rgba(201,168,76,0.15)">
            <p style="font-size:11px;color:#8d8576;letter-spacing:2px;text-transform:uppercase;margin:0 0 10px">Description</p>
            <p style="font-size:14px;color:#e8e3d9;line-height:1.7;margin:0;white-space:pre-wrap">${String(details.description).replace(/</g, "&lt;").replace(/>/g, "&gt;")}</p>
          </div>` : ""}
          <p style="font-size:12px;color:#605a4f;margin-top:24px"><a href="https://warroomintel.com/community" style="color:#C9A84C">Open War Room Intel</a></p>
        </div>
      `
    };
  } else if (type === "welcome") {
    emailPayload = {
      from: FROM,
      to,
      subject: "Welcome to War Room Intel \u2014 Intelligence for the Fight",
      html: `
        <div style="background:#08060e;color:#F4F0FC;font-family:Georgia,serif;max-width:600px;margin:0 auto;padding:40px 32px;border:1px solid rgba(201,168,76,0.2)">
          <div style="border-bottom:1px solid rgba(201,168,76,0.3);padding-bottom:20px;margin-bottom:28px">
            <p style="font-family:serif;font-size:11px;color:#C9A84C;letter-spacing:3px;text-transform:uppercase;margin:0 0 8px">WAR ROOM INTEL</p>
            <h1 style="font-size:22px;color:#C9A84C;margin:0;letter-spacing:1px">Welcome, Warrior</h1>
          </div>
          <p style="font-size:16px;line-height:1.7;color:#e8e3d9">Dear ${name || "Warrior"},</p>
          <p style="font-size:15px;line-height:1.8;color:#b9b2a4">You are now part of the War Room Intel community \u2014 the most comprehensive spiritual warfare intelligence platform available to the Body of Christ.</p>
          <p style="font-size:15px;line-height:1.8;color:#b9b2a4">Access your dashboard, explore the Intel Archive, and connect with fellow warriors at:</p>
          <p style="text-align:center;margin:28px 0">
            <a href="https://warroomintel.com/community" style="display:inline-block;padding:12px 28px;background:#C9A84C;color:#1a1305;font-family:Georgia,serif;font-size:13px;font-weight:600;text-decoration:none;letter-spacing:1px">ENTER THE WAR ROOM</a>
          </p>
          <div style="margin-top:32px;padding-top:20px;border-top:1px solid rgba(201,168,76,0.2)">
            <p style="font-size:13px;color:#605a4f;margin:0">In His service,<br/>Pastor Justin Payne<br/>War Room Intel</p>
          </div>
        </div>
      `
    };
  } else if (type === "event-published") {
    const { eventTitle, eventDate, eventType, eventDescription, joinLink, tierName } = body || {};
    const dateStr = eventDate ? new Date(eventDate).toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" }) : "";
    const timeStr = eventDate ? new Date(eventDate).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZoneName: "short" }) : "";
    const typeLabel = { live_training: "LIVE TRAINING", prayer_call: "PRAYER CALL", q_and_a: "Q&A SESSION", deliverance_workshop: "DELIVERANCE WORKSHOP", group_warfare_prayer: "GROUP WARFARE PRAYER", generals_table: "GENERAL'S TABLE", youtube_premiere: "YOUTUBE PREMIERE" }[eventType] || (eventType || "EVENT").toUpperCase();
    emailPayload = {
      from: FROM,
      to,
      subject: `\u2694 New Event: ${eventTitle} \u2014 ${dateStr}`,
      html: `
        <div style="background:#08060e;color:#F4F0FC;font-family:Georgia,serif;max-width:600px;margin:0 auto;padding:40px 32px;border:1px solid rgba(201,168,76,0.2)">
          <div style="border-bottom:1px solid rgba(201,168,76,0.3);padding-bottom:20px;margin-bottom:28px">
            <p style="font-family:serif;font-size:11px;color:#C9A84C;letter-spacing:3px;text-transform:uppercase;margin:0 0 8px">WAR ROOM INTEL</p>
            <h1 style="font-size:22px;color:#C9A84C;margin:0;letter-spacing:1px">New Event Announced</h1>
          </div>
          <div style="display:inline-block;padding:3px 12px;background:rgba(201,168,76,0.12);border:1px solid rgba(201,168,76,0.4);border-radius:4px;font-family:serif;font-size:10px;color:#C9A84C;letter-spacing:2px;margin-bottom:16px">${typeLabel}</div>
          <h2 style="font-size:20px;color:#f0e8d8;margin:0 0 10px;letter-spacing:0.5px">${eventTitle || ""}</h2>
          <p style="font-size:14px;color:#8B7355;margin:0 0 20px">\u{1F4C5} ${dateStr} \xB7 ${timeStr}</p>
          ${eventDescription ? `<p style="font-size:15px;line-height:1.8;color:#b9b2a4;margin:0 0 24px">${String(eventDescription).replace(/</g, "&lt;").replace(/>/g, "&gt;")}</p>` : ""}
          ${tierName ? `<p style="font-size:13px;color:#8B7355;margin:0 0 24px;font-style:italic">This event is exclusive to ${tierName} members and above.</p>` : ""}
          <p style="text-align:center;margin:28px 0">
            ${joinLink ? `<a href="${joinLink}" style="display:inline-block;padding:12px 28px;background:#C9A84C;color:#1a1305;font-family:Georgia,serif;font-size:13px;font-weight:600;text-decoration:none;letter-spacing:1px">JOIN THE CALL \u2192</a>` : `<a href="https://warroomintel.com/community?section=events" style="display:inline-block;padding:12px 28px;background:#C9A84C;color:#1a1305;font-family:Georgia,serif;font-size:13px;font-weight:600;text-decoration:none;letter-spacing:1px">WATCH INSIDE PLATFORM \u2192</a>`}
          </p>
          <p style="text-align:center;margin:0"><a href="https://warroomintel.com/community?section=events" style="font-size:12px;color:#8B7355">View Event \u2192</a></p>
          <div style="margin-top:32px;padding-top:20px;border-top:1px solid rgba(201,168,76,0.2)">
            <p style="font-size:13px;color:#605a4f;margin:0">In His service,<br/>Pastor Justin Payne<br/>War Room Intel</p>
          </div>
        </div>
      `
    };
  } else if (type === "event-reminder") {
    const { eventTitle, eventDate, eventId, joinLink } = body || {};
    const dateStr = eventDate ? new Date(eventDate).toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" }) : "";
    const timeStr = eventDate ? new Date(eventDate).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", timeZoneName: "short" }) : "";
    emailPayload = {
      from: FROM,
      to,
      subject: `\u2694 Starting in 1 Hour: ${eventTitle}`,
      html: `
        <div style="background:#08060e;color:#F4F0FC;font-family:Georgia,serif;max-width:600px;margin:0 auto;padding:40px 32px;border:1px solid rgba(201,168,76,0.2)">
          <div style="border-bottom:1px solid rgba(201,168,76,0.3);padding-bottom:20px;margin-bottom:28px">
            <p style="font-family:serif;font-size:11px;color:#C9A84C;letter-spacing:3px;text-transform:uppercase;margin:0 0 8px">WAR ROOM INTEL</p>
            <h1 style="font-size:22px;color:#C9A84C;margin:0;letter-spacing:1px">Starting in 1 Hour</h1>
          </div>
          <p style="font-size:15px;line-height:1.8;color:#b9b2a4">Your event starts in <strong style="color:#C9A84C">1 hour</strong>. Don't miss it.</p>
          <h2 style="font-size:20px;color:#f0e8d8;margin:16px 0 8px;letter-spacing:0.5px">${eventTitle || ""}</h2>
          <p style="font-size:14px;color:#8B7355;margin:0 0 24px">\u{1F4C5} ${dateStr} \xB7 ${timeStr}</p>
          ${joinLink ? `
          <p style="text-align:center;margin:28px 0">
            <a href="${joinLink}" style="display:inline-block;padding:14px 32px;background:#C9A84C;color:#1a1305;font-family:Georgia,serif;font-size:14px;font-weight:600;text-decoration:none;letter-spacing:1px">JOIN THE CALL \u2192</a>
          </p>
          <p style="text-align:center;font-size:12px;color:#605a4f;margin:0 0 24px">Or copy this link: <span style="color:#C9A84C;font-family:monospace">${joinLink}</span></p>
          ` : `
          <p style="text-align:center;margin:28px 0">
            <a href="https://warroomintel.com/community?section=events" style="display:inline-block;padding:14px 32px;background:#C9A84C;color:#1a1305;font-family:Georgia,serif;font-size:14px;font-weight:600;text-decoration:none;letter-spacing:1px">WATCH INSIDE PLATFORM \u2192</a>
          </p>
          `}
          ${eventId ? `<p style="text-align:center;margin:0"><a href="https://warroomintel.com/api/events-ics?id=${eventId}" style="font-size:11px;color:#8B7355">\u{1F4C5} Download .ics</a></p>` : ""}
          <div style="margin-top:32px;padding-top:20px;border-top:1px solid rgba(201,168,76,0.2)">
            <p style="font-size:13px;color:#605a4f;margin:0">In His service,<br/>Pastor Justin Payne<br/>War Room Intel</p>
          </div>
        </div>
      `
    };
  } else {
    return new Response(JSON.stringify({ error: "Unknown email type" }), { status: 400, headers: HEADERS });
  }
  const { data, error } = await resend.emails.send(emailPayload);
  if (error) {
    console.error("[send-email] error:", error);
    return new Response(JSON.stringify({ error: "Failed to send email" }), { status: 500, headers: HEADERS });
  }
  return new Response(JSON.stringify({ success: true, id: data?.id }), { status: 200, headers: HEADERS });
}
var config = { path: "/api/send-email" };
export {
  config,
  handler as default
};
