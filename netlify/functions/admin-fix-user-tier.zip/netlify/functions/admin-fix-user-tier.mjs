
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-fix-user-tier.ts
import { StreamChat } from "stream-chat";
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
var VALID_TIERS = /* @__PURE__ */ new Set([
  "watchman",
  "free",
  "soldier",
  "charter_soldier",
  "commander",
  "charter_commander",
  "general",
  "founding_general"
]);
var TIER_LEVEL = {
  watchman: 0,
  free: 0,
  soldier: 1,
  charter_soldier: 1,
  commander: 2,
  charter_commander: 2,
  general: 3,
  founding_general: 3,
  minister: 4
};
var STREAM_CHANNELS = [
  { id: "war-room-general", minTier: 0 },
  { id: "field-reports-live", minTier: 1 },
  { id: "commanders-room", minTier: 2 },
  { id: "generals-table", minTier: 3 }
];
async function resolveMinister(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return false;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return false;
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return false;
    const data = await res.json();
    return data?.public_metadata?.role === "minister";
  } catch {
    return false;
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: HEADERS });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "POST required" }), { status: 405, headers: HEADERS });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: HEADERS });
  const ok = await resolveMinister(token);
  if (!ok) return new Response(JSON.stringify({ error: "Minister role required" }), { status: 403, headers: HEADERS });
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: HEADERS });
  }
  const { userId, tier, extra } = body;
  if (!userId || typeof userId !== "string") {
    return new Response(JSON.stringify({ error: "userId required" }), { status: 400, headers: HEADERS });
  }
  if (!tier || !VALID_TIERS.has(tier)) {
    return new Response(JSON.stringify({ error: `Invalid tier. Must be one of: ${[...VALID_TIERS].join(", ")}` }), { status: 400, headers: HEADERS });
  }
  const clerkRes = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
    headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
  });
  if (!clerkRes.ok) {
    const err = await clerkRes.text();
    return new Response(JSON.stringify({ error: `Clerk user not found: ${err}` }), { status: 404, headers: HEADERS });
  }
  const clerkUser = await clerkRes.json();
  const currentMeta = clerkUser.public_metadata || {};
  const newMeta = {
    ...currentMeta,
    tier,
    tierSetAt: (/* @__PURE__ */ new Date()).toISOString(),
    tierSetBy: "admin",
    ...extra || {}
  };
  const updateRes = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ public_metadata: newMeta })
  });
  if (!updateRes.ok) {
    const err = await updateRes.text();
    return new Response(JSON.stringify({ error: `Clerk update failed: ${err}` }), { status: 500, headers: HEADERS });
  }
  const streamResults = {};
  const _stream = JSON.parse(process.env.STREAM || "{}");
  const streamApiKey = _stream.apiKey;
  const streamApiSecret = _stream.apiSecret;
  if (streamApiKey && streamApiSecret) {
    const streamUserId = userId.replace(/[^a-zA-Z0-9_-]/g, "_");
    const level = TIER_LEVEL[tier] ?? 0;
    const firstName = clerkUser.first_name || "";
    const lastName = clerkUser.last_name || "";
    const name2 = `${firstName} ${lastName}`.trim() || clerkUser.email_addresses?.[0]?.email_address || "Warrior";
    try {
      const client = new StreamChat(streamApiKey, streamApiSecret);
      await client.upsertUser({ id: streamUserId, name: name2, role: "user" });
      for (const ch of STREAM_CHANNELS) {
        if (level >= ch.minTier) {
          try {
            const channel = client.channel("messaging", ch.id);
            await channel.addMembers([streamUserId]);
            streamResults[ch.id] = "added";
          } catch (e) {
            streamResults[ch.id] = `error: ${e.message}`;
          }
        }
      }
    } catch (e) {
      console.error("[admin-fix-user-tier] Stream error:", e.message);
    }
  }
  const name = `${clerkUser.first_name || ""} ${clerkUser.last_name || ""}`.trim();
  console.log(`[admin-fix-user-tier] ${userId} (${name}) \u2192 ${tier}`, streamResults);
  return new Response(JSON.stringify({
    success: true,
    userId,
    name,
    tier,
    previousTier: currentMeta.tier || null,
    streamChannels: streamResults
  }), { status: 200, headers: HEADERS });
}
var config = { path: "/api/admin-fix-user-tier" };
export {
  config,
  handler as default
};
