
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/library-chunks.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
var STOPWORDS = /* @__PURE__ */ new Set(["about", "above", "after", "also", "because", "been", "before", "being", "between", "during", "their", "there", "these", "those", "through", "under", "until", "which", "while", "would", "could", "should", "shall", "other", "every", "first", "second", "third", "where", "when", "then", "them", "they", "this", "that", "from", "have", "with", "into", "will", "your", "more", "some", "such"]);
function extractTerms(spiritName, description) {
  const terms = [];
  spiritName.toLowerCase().split(/\s+/).forEach((w) => {
    if (w.length > 2) terms.push(w);
  });
  if (description) {
    description.toLowerCase().replace(/[^a-z\s]/g, " ").split(/\s+/).filter((w) => w.length > 5 && !STOPWORDS.has(w)).slice(0, 20).forEach((w) => terms.push(w));
  }
  const ministryTerms = ["generational", "territorial", "idolatry", "deliverance", "strongman", "principality", "witchcraft", "occult", "bloodline", "covenant", "legal", "rights", "familiar"];
  if (description) {
    ministryTerms.forEach((t) => {
      if (description.toLowerCase().includes(t)) terms.push(t);
    });
  }
  return [...new Set(terms)];
}
function chunkText(text, chunkSize = 2e3) {
  const chunks = [];
  let i = 0;
  while (i < text.length) {
    let end = Math.min(i + chunkSize, text.length);
    if (end < text.length) {
      const nlIdx = text.lastIndexOf("\n", end);
      if (nlIdx > i + chunkSize * 0.6) end = nlIdx;
    }
    const chunk = text.slice(i, end).trim();
    if (chunk.length > 150) chunks.push(chunk);
    i = end;
  }
  return chunks;
}
function scoreChunk(chunk, terms) {
  const lc = chunk.toLowerCase();
  let score = 0;
  for (const term of terms) {
    const regex = new RegExp(`\\b${term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}`, "gi");
    const matches = lc.match(regex);
    if (matches) {
      score += matches.length * (term.length > 7 ? 3 : 1);
    }
  }
  return score;
}
async function resolveMinister(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return false;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return false;
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return false;
    const data = await res.json();
    return data?.public_metadata?.role === "minister";
  } catch {
    return false;
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
  const ok = await resolveMinister(token);
  if (!ok) return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers });
  const body = await req.json();
  const { spiritName = "", spiritDescription = "" } = body;
  const sb = createClient(supabaseUrl, supabaseServiceKey);
  const [booksResult, contextResult] = await Promise.all([
    sb.from("resources").select("id,title,author,extracted_text").eq("topic", "ministry-library").neq("active", false).not("extracted_text", "is", null).limit(50),
    sb.from("ministry_context").select("context_text").eq("is_active", true).order("updated_at", { ascending: false }).limit(1).single()
  ]);
  const books = booksResult.data || [];
  const contextText = contextResult.data?.context_text || "";
  if (books.length === 0) {
    return new Response(JSON.stringify({ chunks: [], contextText, totalBooks: 0 }), { status: 200, headers });
  }
  const terms = extractTerms(spiritName, spiritDescription);
  const allScored = [];
  for (const book of books) {
    if (!book.extracted_text) continue;
    const chunks = chunkText(book.extracted_text);
    for (const chunk of chunks) {
      const score = scoreChunk(chunk, terms);
      if (score > 0) {
        allScored.push({
          bookTitle: book.title,
          author: book.author || "",
          text: chunk.slice(0, 1600),
          // cap at ~400 tokens
          score
        });
      }
    }
  }
  allScored.sort((a, b) => b.score - a.score);
  const topChunks = allScored.slice(0, 5).map(({ bookTitle, author, text }) => ({ bookTitle, author, text }));
  return new Response(JSON.stringify({ chunks: topChunks, contextText, totalBooks: books.length }), { status: 200, headers });
}
var config = { path: "/api/library-chunks" };
export {
  config,
  handler as default
};
