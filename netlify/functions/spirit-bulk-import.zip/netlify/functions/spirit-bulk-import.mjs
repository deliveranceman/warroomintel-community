
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/spirit-bulk-import.ts
var { token: airtableToken } = JSON.parse(process.env.AIRTABLE || "{}");
var CLERK_SECRET = process.env.CLERK_SECRET_KEY;
var AIRTABLE_TOKEN = airtableToken || process.env.AIRTABLE_API_TOKEN || "";
var BASE_ID = "appVXEj2DLPBTJTtD";
var TABLE_ID = "tblcP4lgVykzOhLi4";
var NAME_FIELD = "\u2694 WAR ROOM COMMUNITY \u2014 MASTER DEMON DATABASE";
var FM = {
  name: NAME_FIELD,
  aka: "Also Known As",
  typeRank: "Type / Rank",
  description: "Description",
  manifestations: "Manifestiation",
  // Airtable has this typo
  scripture: "Scripture Reference",
  entryPoints: "Entry Points",
  source: "Source / Orgin",
  // Airtable has this typo
  kingdom: "Kingdom",
  strongman: "Strongman",
  rank: "Rank",
  legalRights: "Legal Rights",
  symptoms: "Symptoms",
  companionSpirits: "Companion Spirits",
  wriNotes: "WRI Exorcist Notes",
  assignment: "Assignment",
  hierarchyCategory: "Hierarchy Category",
  parentStrongman: "Parent Strongman"
};
async function resolveUser(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return null;
    const userRes = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${CLERK_SECRET}` }
    });
    if (!userRes.ok) return null;
    const userData = await userRes.json();
    return { userId, userData };
  } catch {
    return null;
  }
}
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function buildFields(spirit) {
  const out = {};
  for (const [camel, airtable] of Object.entries(FM)) {
    const val = spirit[camel];
    if (val === null || val === void 0 || val === "") continue;
    out[airtable] = Array.isArray(val) ? val.join("\n") : val;
  }
  return out;
}
async function findByName(name) {
  const safe = name.toLowerCase().replace(/'/g, "\\'");
  const url = new URL(`https://api.airtable.com/v0/${BASE_ID}/${TABLE_ID}`);
  url.searchParams.set("filterByFormula", `LOWER({${NAME_FIELD}})='${safe}'`);
  url.searchParams.append("fields[]", NAME_FIELD);
  url.searchParams.set("maxRecords", "1");
  const res = await fetch(url.toString(), {
    headers: { Authorization: `Bearer ${AIRTABLE_TOKEN}` }
  });
  if (!res.ok) return null;
  const data = await res.json();
  return data.records?.[0]?.id ?? null;
}
async function handler(req) {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }
  const authHeader = req.headers.get("Authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });
  }
  const auth = await resolveUser(token);
  if (!auth) {
    return new Response(JSON.stringify({ error: "Unauthorized \u2014 invalid session" }), { status: 401 });
  }
  if (auth.userData?.public_metadata?.role !== "minister") {
    return new Response(JSON.stringify({ error: "Forbidden \u2014 minister role required" }), { status: 403 });
  }
  let spirits;
  try {
    const body = await req.json();
    spirits = body.spirits;
    if (!Array.isArray(spirits) || spirits.length === 0) {
      return new Response(JSON.stringify({ error: "spirits array required" }), { status: 400 });
    }
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON body" }), { status: 400 });
  }
  let created = 0;
  let updated = 0;
  const errors = [];
  for (const spirit of spirits) {
    const name = spirit.name?.trim();
    if (!name) {
      errors.push({ name: "(unnamed)", error: "Missing name field" });
      continue;
    }
    try {
      const fields = buildFields(spirit);
      if (Object.keys(fields).length === 0) {
        errors.push({ name, error: "No mappable fields found" });
        await delay(400);
        continue;
      }
      const existingId = await findByName(name);
      if (existingId) {
        const patchRes = await fetch(`https://api.airtable.com/v0/${BASE_ID}/${TABLE_ID}/${existingId}`, {
          method: "PATCH",
          headers: {
            Authorization: `Bearer ${AIRTABLE_TOKEN}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ fields })
        });
        if (!patchRes.ok) {
          const errBody = await patchRes.json().catch(() => ({}));
          errors.push({ name, error: errBody?.error?.message || `PATCH ${patchRes.status}` });
        } else {
          updated++;
        }
      } else {
        const postRes = await fetch(`https://api.airtable.com/v0/${BASE_ID}/${TABLE_ID}`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${AIRTABLE_TOKEN}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ fields })
        });
        if (!postRes.ok) {
          const errBody = await postRes.json().catch(() => ({}));
          errors.push({ name, error: errBody?.error?.message || `POST ${postRes.status}` });
        } else {
          created++;
        }
      }
    } catch (e) {
      errors.push({ name, error: e.message || "Unknown error" });
    }
    await delay(400);
  }
  return new Response(
    JSON.stringify({ created, updated, errors }),
    { status: 200, headers: { "Content-Type": "application/json" } }
  );
}
var config = { path: "/api/spirit-bulk-import" };
export {
  config,
  handler as default
};
