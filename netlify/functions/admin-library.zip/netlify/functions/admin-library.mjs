
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-library.ts
import { createClient } from "@supabase/supabase-js";
import Busboy from "busboy";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var BUCKET = "ministry-library";
var headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function supabaseClient() {
  return createClient(
    supabaseUrl,
    supabaseServiceKey
  );
}
async function isMinister(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return false;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return false;
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return false;
    const data = await res.json();
    return data?.public_metadata?.role === "minister";
  } catch {
    return false;
  }
}
function parseMultipart(_req, bodyBuf, contentType) {
  return new Promise((resolve, reject) => {
    const fields = {};
    let file;
    const busboy = Busboy({ headers: { "content-type": contentType } });
    busboy.on("field", (name, val) => {
      fields[name] = val;
    });
    busboy.on("file", (_fieldname, stream, info) => {
      const chunks = [];
      stream.on("data", (c) => chunks.push(c));
      stream.on("end", () => {
        file = { buffer: Buffer.concat(chunks), filename: info.filename, mimeType: info.mimeType };
      });
    });
    busboy.on("finish", () => resolve({ fields, file }));
    busboy.on("error", reject);
    busboy.write(bodyBuf);
    busboy.end();
  });
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
  const ok = await isMinister(token);
  if (!ok) return new Response(JSON.stringify({ error: "Forbidden \u2014 minister role required" }), { status: 403, headers });
  const sb = supabaseClient();
  if (req.method === "GET") {
    const url = new URL(req.url);
    const bookId = url.searchParams.get("id");
    if (bookId) {
      const { data: book, error: error2 } = await sb.from("resources").select("id,title,author,file_path,file_size,filename,active,ai_generated,created_at,notes,topic,spirit_tags,extracted_text,description,function_tags,source_type").eq("topic", "ministry-library").eq("id", bookId).single();
      if (error2 || !book) return new Response(JSON.stringify({ error: error2?.message || "Not found" }), { status: 404, headers });
      return new Response(JSON.stringify({ book }), { status: 200, headers });
    }
    const { data, error } = await sb.from("resources").select("id,title,author,file_path,file_size,filename,active,ai_generated,created_at,notes,topic,spirit_tags,extracted_text,source_type").eq("topic", "ministry-library").order("created_at", { ascending: false });
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers });
    const books = (data || []).map((b) => ({
      ...b,
      // Strip extracted_text from response — only send indexed flag
      extracted_text: void 0,
      is_indexed: !!(b.extracted_text && b.extracted_text.length > 100),
      file_url: ""
    }));
    await Promise.all(books.map(async (b) => {
      if (b.filename?.toLowerCase().endsWith(".pdf") && b.file_path) {
        try {
          const { data: signed } = await sb.storage.from(BUCKET).createSignedUrl(b.file_path, 3600);
          b.file_url = signed?.signedUrl || "";
        } catch {
        }
      }
    }));
    return new Response(JSON.stringify({ books }), { status: 200, headers });
  }
  if (req.method === "POST") {
    const contentType = req.headers.get("content-type") || "";
    let title = "", author = "", notes = "", fileName = "", fileSize = 0;
    let fileBuffer;
    if (contentType.includes("multipart/form-data")) {
      const bodyBuf = Buffer.from(await req.arrayBuffer());
      let parsed;
      try {
        parsed = await parseMultipart(req, bodyBuf, contentType);
      } catch (e) {
        return new Response(JSON.stringify({ error: `Multipart parse failed: ${e?.message}` }), { status: 400, headers });
      }
      title = parsed.fields.title || "";
      author = parsed.fields.author || "";
      notes = parsed.fields.notes || "";
      if (parsed.file) {
        fileBuffer = parsed.file.buffer;
        fileName = parsed.file.filename || parsed.fields.filename || "upload";
        fileSize = fileBuffer.length;
      }
    } else {
      const body = await req.json();
      title = body.title || "";
      author = body.author || "";
      notes = body.notes || "";
      fileName = body.fileName || "";
      fileSize = body.fileSize || 0;
      if (body.fileBase64) {
        fileBuffer = Buffer.from(body.fileBase64, "base64");
        fileSize = fileBuffer.length;
      }
    }
    if (!title.trim() || !fileBuffer || !fileName) {
      return new Response(JSON.stringify({ error: "title, file, and fileName required" }), { status: 400, headers });
    }
    console.log(`[admin-library] Uploading: ${fileName} (${fileBuffer.length} bytes)`);
    const safeName = `${Date.now()}-${fileName.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
    const isTxt = fileName.toLowerCase().endsWith(".txt");
    const mimeType = isTxt ? "text/plain" : "application/pdf";
    const { error: uploadErr } = await sb.storage.from(BUCKET).upload(safeName, fileBuffer, {
      contentType: mimeType,
      upsert: false
    });
    if (uploadErr) {
      console.error("[admin-library] Storage upload error:", uploadErr.message);
      return new Response(JSON.stringify({ error: `Storage upload failed: ${uploadErr.message}` }), { status: 500, headers });
    }
    const { data: row, error: insertErr } = await sb.from("ministry_library").insert({
      title: title.trim(),
      author: author?.trim() || null,
      file_path: safeName,
      file_size_bytes: fileSize || fileBuffer.length,
      page_count: 0,
      extracted_text: null,
      notes: notes?.trim() || null,
      is_enabled: true,
      ai_enabled: true
    }).select("id,title,author,file_path,file_size_bytes,page_count,is_enabled,ai_enabled,upload_date,notes").single();
    if (insertErr) {
      await sb.storage.from(BUCKET).remove([safeName]);
      console.error("[admin-library] DB insert error:", insertErr.message);
      return new Response(JSON.stringify({ error: `DB insert failed: ${insertErr.message}` }), { status: 500, headers });
    }
    return new Response(JSON.stringify({ success: true, book: row }), { status: 200, headers });
  }
  if (req.method === "PATCH") {
    const body = await req.json();
    const { id, cleanTitle, ...fields } = body;
    if (!id) return new Response(JSON.stringify({ error: "id required" }), { status: 400, headers });
    const allowed = ["title", "author", "notes", "active", "ai_generated", "topic", "spirit_tags", "source_type"];
    const update = {};
    for (const k of allowed) {
      if (k in fields) update[k] = fields[k];
    }
    if (cleanTitle && update.title) {
      update.title = update.title.replace(/^\d+[-\s]*/g, "").trim();
    } else if (cleanTitle) {
      const { data: current } = await sb.from("resources").select("title").eq("id", id).eq("topic", "ministry-library").single();
      if (current?.title) update.title = current.title.replace(/^\d+[-\s]*/g, "").trim();
    }
    const { data, error } = await sb.from("resources").update(update).eq("id", id).eq("topic", "ministry-library").select("id,title,author,file_path,file_size,filename,active,ai_generated,created_at,notes,topic,spirit_tags,source_type").single();
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers });
    return new Response(JSON.stringify({ success: true, book: data }), { status: 200, headers });
  }
  if (req.method === "DELETE") {
    const body = await req.json();
    const { id, file_path } = body;
    if (!id) return new Response(JSON.stringify({ error: "id required" }), { status: 400, headers });
    if (file_path) {
      await sb.storage.from(BUCKET).remove([file_path]);
    }
    const { error } = await sb.from("resources").delete().eq("id", id).eq("topic", "ministry-library");
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers });
    return new Response(JSON.stringify({ success: true }), { status: 200, headers });
  }
  return new Response("Method not allowed", { status: 405 });
}
var config = { path: "/api/admin-library" };
export {
  config,
  handler as default
};
