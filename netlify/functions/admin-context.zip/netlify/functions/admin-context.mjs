
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-context.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function supabaseClient() {
  return createClient(supabaseUrl, supabaseServiceKey);
}
async function resolveMinister(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return false;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return false;
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return false;
    const data = await res.json();
    return data?.public_metadata?.role === "minister";
  } catch {
    return false;
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
  const ok = await resolveMinister(token);
  if (!ok) return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers });
  const sb = supabaseClient();
  if (req.method === "GET") {
    const { data, error } = await sb.from("ministry_context").select("id, label, context_text, scope, is_active, updated_at").order("scope").order("updated_at", { ascending: false });
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers });
    return new Response(JSON.stringify({ contexts: data || [] }), { status: 200, headers });
  }
  if (req.method === "POST") {
    const body = await req.json();
    const { label, context_text, scope = "global", is_active = true } = body;
    if (!context_text?.trim()) return new Response(JSON.stringify({ error: "context_text required" }), { status: 400, headers });
    if (!["global", "regional", "session", "assessment"].includes(scope)) {
      return new Response(JSON.stringify({ error: "scope must be global, regional, session, or assessment" }), { status: 400, headers });
    }
    const { data, error } = await sb.from("ministry_context").insert({
      label: label?.trim() || "Ministry Context",
      context_text: context_text.trim(),
      scope,
      is_active
    }).select().single();
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers });
    return new Response(JSON.stringify({ success: true, context: data }), { status: 200, headers });
  }
  if (req.method === "PATCH") {
    const body = await req.json();
    const { id, label, context_text, scope, is_active } = body;
    if (!id) return new Response(JSON.stringify({ error: "id required" }), { status: 400, headers });
    if (scope && !["global", "regional", "session", "assessment"].includes(scope)) {
      return new Response(JSON.stringify({ error: "invalid scope" }), { status: 400, headers });
    }
    const updates = { updated_at: (/* @__PURE__ */ new Date()).toISOString() };
    if (label !== void 0) updates.label = label?.trim() || "Ministry Context";
    if (context_text !== void 0) updates.context_text = context_text.trim();
    if (scope !== void 0) updates.scope = scope;
    if (is_active !== void 0) updates.is_active = is_active;
    const { data, error } = await sb.from("ministry_context").update(updates).eq("id", id).select().single();
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers });
    return new Response(JSON.stringify({ success: true, context: data }), { status: 200, headers });
  }
  if (req.method === "DELETE") {
    const body = await req.json();
    const { id } = body;
    if (!id) return new Response(JSON.stringify({ error: "id required" }), { status: 400, headers });
    const { error } = await sb.from("ministry_context").delete().eq("id", id);
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers });
    return new Response(JSON.stringify({ success: true }), { status: 200, headers });
  }
  return new Response("Method not allowed", { status: 405 });
}
var config = { path: "/api/admin-context" };
export {
  config,
  handler as default
};
