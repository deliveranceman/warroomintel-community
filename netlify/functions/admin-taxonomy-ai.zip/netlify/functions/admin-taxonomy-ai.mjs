
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-taxonomy-ai.ts
var { token: airtableToken } = JSON.parse(process.env.AIRTABLE || "{}");
var AIRTABLE_TOKEN = airtableToken;
var ANTHROPIC_KEY = process.env.ANTHROPIC_API_KEY;
var BASE_ID = "appVXEj2DLPBTJTtD";
var TABLE_ID = "tblcP4lgVykzOhLi4";
var NAME_FIELD = "\u2694 WAR ROOM COMMUNITY \u2014 MASTER DEMON DATABASE";
var headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" };
var VALID_RANKS = [
  "Principality",
  "World Ruler",
  "Power",
  "Wicked Spirit",
  "Demon",
  "Familiar Spirit",
  "Spirit of Infirmity",
  "Fallen Angel"
];
var VALID_KINGDOMS = [
  "Hell / Darkness",
  "Air",
  "Water / Marine",
  "Earth",
  "Witchcraft",
  "Occult",
  "Religion / False Religion",
  "False Religion / Paganism",
  "Infirmity / Sickness",
  "Mind / Intellect",
  "Sexual Perversion",
  "Death / Destruction",
  "Fear / Torment",
  "Pride / Self",
  "Deception / Lies",
  "Anger / Violence",
  "Mammon / Greed"
];
var VALID_SUB_KINGDOMS = [
  "Norse / Germanic",
  "Celtic / Druidic",
  "Greek / Roman",
  "Egyptian",
  "Babylonian / Sumerian",
  "Canaanite / Phoenician",
  "Assyrian / Akkadian",
  "Persian / Zoroastrian",
  "Hindu / Vedic",
  "Buddhist / Eastern",
  "Native American / Indigenous",
  "African Traditional / Vodou",
  "Aztec / Mayan / Mesoamerican",
  "Polynesian / Pacific",
  "Freemasonry / Rosicrucian",
  "Satanism / Luciferianism",
  "New Age / Theosophy",
  "Witchcraft / Wicca",
  "Kabbalah / Jewish Mysticism",
  "Gnosticism",
  "Hermeticism / Alchemy",
  "Marine / Aquatic",
  "Celestial / Astral",
  "Infernal / Hellish",
  "Generational / Bloodline",
  "Religious Spirit / False Religion",
  "Sexual Covenant",
  "Death Covenant",
  "Mind / Intellect",
  "Trauma / Wound",
  "Fallen Angel / Watcher",
  "Nephilim / Giant Bloodline",
  "Goetic / Solomonic",
  "Apocryphal",
  "None"
];
async function resolveMinister(token) {
  try {
    if (!token || token.split(".").length !== 3) return { ok: false, reason: "Invalid JWT" };
    const payload = JSON.parse(Buffer.from(token.split(".")[1], "base64url").toString("utf-8"));
    const userId = payload.sub;
    if (!userId || !String(userId).startsWith("user_")) return { ok: false, reason: "Invalid userId" };
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return { ok: false, reason: `Clerk error ${res.status}` };
    const data = await res.json();
    if (data?.public_metadata?.role !== "minister") return { ok: false, reason: "Minister role required" };
    return { ok: true, reason: "" };
  } catch (e) {
    return { ok: false, reason: e.message || "Auth error" };
  }
}
async function fetchPage(batchSize, airtableOffset) {
  const url = new URL(`https://api.airtable.com/v0/${BASE_ID}/${TABLE_ID}`);
  url.searchParams.set("pageSize", String(Math.min(batchSize, 100)));
  for (const f of [NAME_FIELD, "Description", "Manifestiation", "Source / Orgin", "Kingdom", "Biblical Rank", "Sub-Kingdom", "Also Known As"]) {
    url.searchParams.append("fields[]", f);
  }
  if (airtableOffset) url.searchParams.set("offset", airtableOffset);
  const res = await fetch(url.toString(), {
    headers: { Authorization: `Bearer ${AIRTABLE_TOKEN}` }
  });
  if (!res.ok) throw new Error(`Airtable error ${res.status}`);
  const data = await res.json();
  return {
    records: data.records || [],
    nextOffset: data.offset || null,
    total: 0
    // Airtable doesn't return total — caller tracks
  };
}
function buildPrompt(r) {
  const f = r.fields || {};
  const name = f[NAME_FIELD] || "(unknown)";
  const desc = f["Description"] || "";
  const manif = f["Manifestiation"] || "";
  const origin = f["Source / Orgin"] || "";
  const curRank = f["Biblical Rank"] || "";
  const curKing = f["Kingdom"] || "";
  return `You are a deliverance ministry taxonomy expert. Classify this spirit using ONLY the exact options listed. Return ONLY valid JSON, no explanation.

Spirit name: ${name}
Known function: ${desc.slice(0, 300)}
Known manifestation: ${manif.slice(0, 200)}
Origin/source: ${origin.slice(0, 150)}
Current Kingdom: ${curKing || "(unset)"}
Current Biblical Rank: ${curRank || "(unset)"}

BIBLICAL RANK \u2014 choose exactly one:
- Principality: ONLY if it governs a nation-state or government structure
- World Ruler: High-ranking spirit that received mass worship across a civilization and operates atmospherically OVER people (not indwelling). Examples: Baal, Leviathan, Thor, Odin, Molech, Ra
- Power: Broad authority over a domain/sphere. Examples: spirit of death, Jezebel as a controlling system, spirit of lust as governing force
- Wicked Spirit: Operates through deception and chaos from within. Examples: Loki, lying spirits, confusion, deceiving spirits
- Demon: Characteristically indwells and harasses individuals directly. Most common. Examples: Fear, Anger, Rejection, Pride
- Familiar Spirit: Generational assignment to a specific bloodline. Mimics and counterfeits
- Spirit of Infirmity: Manifests primarily through physical disease or affliction
- Fallen Angel: Named pre-flood Watchers with specific rebellion roles. Examples: Azazel, Semyaza

KINGDOM \u2014 choose exactly one:
Hell / Darkness, Air, Water / Marine, Earth, Witchcraft, Occult,
False Religion / Paganism, Religion / False Religion,
Infirmity / Sickness, Mind / Intellect, Sexual Perversion,
Death / Destruction, Fear / Torment, Pride / Self,
Deception / Lies, Anger / Violence, Mammon / Greed

KINGDOM RULES:
- Witchcraft: spirit operates THROUGH active practice of witchcraft, hexes, curses, divination
- Occult: tied to secret society or hidden knowledge system (Freemasonry, Kabbalah, Hermeticism, Satanism)
- False Religion / Paganism: gained authority through organized worship of false gods (Norse, Egyptian, Canaanite, Hindu, Native American, Aztec, etc.)
- Water / Marine: operates from or through water realm

SUB-KINGDOM \u2014 choose exactly one or "None":
Norse / Germanic, Celtic / Druidic, Greek / Roman, Egyptian,
Babylonian / Sumerian, Canaanite / Phoenician, Assyrian / Akkadian,
Persian / Zoroastrian, Hindu / Vedic, Buddhist / Eastern,
Native American / Indigenous, African Traditional / Vodou,
Aztec / Mayan / Mesoamerican, Polynesian / Pacific,
Freemasonry / Rosicrucian, Satanism / Luciferianism,
New Age / Theosophy, Witchcraft / Wicca, Kabbalah / Jewish Mysticism,
Gnosticism, Hermeticism / Alchemy, Marine / Aquatic,
Celestial / Astral, Infernal / Hellish, Generational / Bloodline,
Religious Spirit / False Religion, Sexual Covenant, Death Covenant,
Mind / Intellect, Trauma / Wound, Fallen Angel / Watcher,
Nephilim / Giant Bloodline, Goetic / Solomonic, Apocryphal, None

Return ONLY this JSON:
{"biblicalRank":"...","kingdom":"...","subKingdom":"...","confidence":"high|medium|low","reasoning":"one sentence max"}`;
}
async function classifySpirit(record) {
  const f = record.fields || {};
  const name = f[NAME_FIELD] || "";
  if (!name || name === "Primary Name") return null;
  const prompt = buildPrompt(record);
  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": ANTHROPIC_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 200,
        system: "Return ONLY valid JSON. No markdown, no code blocks, no explanation. Start with { end with }.",
        messages: [{ role: "user", content: prompt }]
      }),
      signal: AbortSignal.timeout(12e3)
    });
    if (!res.ok) {
      console.warn(`[taxonomy-ai] Claude error ${res.status} for "${name}"`);
      return null;
    }
    const data = await res.json();
    const raw = (data.content?.[0]?.text || "").trim().replace(/^```[\w]*\s*/i, "").replace(/\s*```\s*$/i, "").trim();
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      const m = raw.match(/\{[\s\S]*\}/);
      if (!m) {
        console.warn(`[taxonomy-ai] Parse failed for "${name}":`, raw.slice(0, 80));
        return null;
      }
      try {
        parsed = JSON.parse(m[0]);
      } catch {
        return null;
      }
    }
    const biblicalRank = VALID_RANKS.includes(parsed.biblicalRank) ? parsed.biblicalRank : "";
    const kingdom = VALID_KINGDOMS.includes(parsed.kingdom) ? parsed.kingdom : "";
    const subKingdom = VALID_SUB_KINGDOMS.includes(parsed.subKingdom) ? parsed.subKingdom : "None";
    const confidence = ["high", "medium", "low"].includes(parsed.confidence) ? parsed.confidence : "medium";
    const reasoning = String(parsed.reasoning || "").slice(0, 200);
    const current = {
      biblicalRank: f["Biblical Rank"] || "",
      kingdom: f["Kingdom"] || "",
      subKingdom: f["Sub-Kingdom"] || ""
    };
    const suggested = { biblicalRank, kingdom, subKingdom };
    const changed = !!biblicalRank && biblicalRank !== current.biblicalRank || !!kingdom && kingdom !== current.kingdom || !!subKingdom && subKingdom !== "None" && subKingdom !== current.subKingdom || !current.biblicalRank || !current.kingdom || !current.subKingdom;
    return {
      recordId: record.id,
      name,
      current,
      suggested,
      confidence,
      reasoning,
      changed
    };
  } catch (e) {
    console.warn(`[taxonomy-ai] Exception for "${name}":`, e.message);
    return null;
  }
}
async function classifyBatch(records) {
  const results = await Promise.all(records.map(classifySpirit));
  return results.filter(Boolean);
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { status: 200, headers });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "POST required" }), { status: 405, headers });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
  const auth = await resolveMinister(token);
  if (!auth.ok) return new Response(JSON.stringify({ error: auth.reason }), { status: 403, headers });
  let body = {};
  try {
    body = await req.json();
  } catch {
  }
  const limit = Math.min(Number(body.limit) || 20, 30);
  const airtableOffset = body.airtableOffset || void 0;
  try {
    console.log(`[taxonomy-ai] Fetching page (limit=${limit}, offset=${airtableOffset || "first"})`);
    const { records: allPage, nextOffset } = await fetchPage(limit, airtableOffset);
    const records = allPage.filter((r) => {
      const name = r.fields?.[NAME_FIELD];
      return name && name !== "Primary Name";
    });
    console.log(`[taxonomy-ai] Classifying ${records.length} spirits`);
    const suggestions = await classifyBatch(records);
    const relevant = suggestions.filter((s) => s.changed);
    const highCount = relevant.filter((s) => s.confidence === "high").length;
    return new Response(JSON.stringify({
      suggestions: relevant,
      batchCount: records.length,
      changed: relevant.length,
      highConfidence: highCount,
      nextOffset: nextOffset || null
      // null = no more pages
    }), { status: 200, headers });
  } catch (e) {
    console.error("[taxonomy-ai] Error:", e.message);
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
  }
}
var config = { path: "/api/admin-taxonomy-ai" };
export {
  config,
  handler as default
};
