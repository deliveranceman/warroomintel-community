
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/generate-document.ts
import { createClient as createClient2 } from "@supabase/supabase-js";

// netlify/lib/ai-rate-limit.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
async function checkAndIncrementUsage(_userId, _tier, _feature) {
  return { allowed: true, remaining: 999, limit: 999, current: 0 };
}
var FEATURE_LABELS = {
  ask_dake: "Ask Dake",
  ai_assistant: "AI Assistant",
  bible_ask: "Bible Study AI",
  symptom_investigator: "Symptom Investigator",
  gateway: "Gateway Investigator",
  dream: "Dream Interpreter",
  document: "Document Creator",
  session_ai: "Session AI",
  assessment: "Assessment Strategy"
};
function getUpgradeMessage(tier, feature) {
  const tiers = {
    watchman: "Soldier",
    free: "Soldier",
    soldier: "Commander",
    charter_soldier: "Commander",
    commander: "General",
    charter_commander: "General"
  };
  const nextTier = tiers[tier];
  const label = FEATURE_LABELS[feature] || feature;
  if (!nextTier) return `You have reached your daily limit for ${label}.`;
  return `Daily limit reached for ${label}. Upgrade to ${nextTier} for more.`;
}

// netlify/lib/clean-ai-output.ts
function cleanAIOutput(text) {
  return text.replace(/\s—\s/g, ", ").replace(/—/g, " - ").replace(/\s–\s/g, ", ").replace(/\bIn conclusion,?\s*/gi, "").replace(/\bTo summarize,?\s*/gi, "").replace(/\bIt is worth noting that\s*/gi, "").replace(/\bIt is important to note that\s*/gi, "").replace(/\bNotably,?\s*/gi, "").replace(/\bFurthermore,?\s*/gi, "").replace(/\bMoreover,?\s*/gi, "").replace(/\bAdditionally,?\s*/gi, "").replace(/\bIn other words,?\s*/gi, "").replace(/\bAs previously mentioned,?\s*/gi, "").replace(/\bAs we can see,?\s*/gi, "").replace(/\bIt goes without saying\s*/gi, "").replace(/\bNeedless to say,?\s*/gi, "").replace(/\bAt the end of the day,?\s*/gi, "").replace(/\bWith that said,?\s*/gi, "").replace(/\bThat being said,?\s*/gi, "").replace(/\bHaving said that,?\s*/gi, "").replace(/  +/g, " ").replace(/\s,/g, ",").trim();
}

// netlify/functions/generate-document.ts
var { url: supabaseUrl2, serviceRoleKey: supabaseServiceKey2 } = JSON.parse(process.env.SUPABASE || "{}");
var headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function sb() {
  return createClient2(supabaseUrl2, supabaseServiceKey2);
}
function getTierLevel(tier) {
  const levels = {
    watchman: 0,
    free: 0,
    soldier: 1,
    charter_soldier: 1,
    commander: 2,
    charter_commander: 2,
    general: 3,
    founding_general: 3,
    minister: 4,
    admin: 4
  };
  return levels[tier] ?? 0;
}
async function resolveUser(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return { ok: false, isMinister: false, tier: "watchman", userId: "" };
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return { ok: false, isMinister: false, tier: "watchman", userId: "" };
    const jwtMeta = payload?.publicMetadata || payload?.public_metadata || {};
    let tier = jwtMeta.tier || "watchman";
    let isMinister = jwtMeta.role === "minister";
    try {
      const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
        headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
      });
      if (res.ok) {
        const data = await res.json();
        isMinister = data?.public_metadata?.role === "minister";
        tier = data?.public_metadata?.tier || tier;
      }
    } catch {
    }
    return { ok: true, isMinister, tier, userId };
  } catch {
    return { ok: false, isMinister: false, tier: "watchman", userId: "" };
  }
}
function parseDocumentJson(raw) {
  let text = raw.trim();
  text = text.replace(/^```json\s*/i, "").replace(/\s*```\s*$/i, "").trim();
  text = text.replace(/^```\s*/i, "").replace(/\s*```\s*$/i, "").trim();
  try {
    return JSON.parse(text);
  } catch {
  }
  const firstBrace = text.indexOf("{");
  const lastBrace = text.lastIndexOf("}");
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    try {
      return JSON.parse(text.slice(firstBrace, lastBrace + 1));
    } catch {
    }
  }
  return null;
}
function logUsage(token, baseUrl, callType, inputTokens, outputTokens) {
  fetch(`${baseUrl}/api/ai-usage`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify({ call_type: callType, input_tokens: inputTokens, output_tokens: outputTokens, model: "claude-sonnet-4-20250514" })
  }).catch(() => {
  });
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
  const { ok, tier, userId } = await resolveUser(token);
  if (!ok) return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers });
  if (getTierLevel(tier) < 1) {
    return new Response(JSON.stringify({ error: "Soldier tier or higher required" }), { status: 403, headers });
  }
  const usage = await checkAndIncrementUsage(userId, tier, "document");
  if (!usage.allowed) {
    return new Response(JSON.stringify({ error: getUpgradeMessage(tier, "document"), rateLimited: true, limit: usage.limit, remaining: 0 }), { status: 429, headers });
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers });
  }
  const { templateId, templateName, sections, subject, spiritData, specialInstructions } = body;
  if (!templateId || !subject?.trim()) {
    return new Response(JSON.stringify({ error: "templateId and subject required" }), { status: 400, headers });
  }
  try {
    const client = sb();
    const { data: contexts } = await client.from("ministry_context").select("label, context_text, scope").eq("is_active", true).in("scope", ["global", "session"]).order("scope");
    const contextText = (contexts || []).map((c) => `[${c.label || c.scope}]:
${c.context_text}`).join("\n\n---\n\n");
    const systemPrompt = [
      contextText ? `MINISTRY CONTEXT:
${contextText}

Apply this ministry voice to the document.` : "",
      `You are generating a professional ministry document for Pastor Justin Payne of Staffordtown Church (Church on Fire), Copperhill, Tennessee.`,
      `CRITICAL: Return ONLY valid JSON. No markdown. No explanation. Start with { end with }.`
    ].filter(Boolean).join("\n\n");
    const sectionList = (sections || []).map((s) => `  "${s.id}" (${s.label}): ${s.instruction}`).join("\n");
    const spiritBlock = spiritData ? `
Spirit database data:
${JSON.stringify(spiritData, null, 2)}` : "";
    const userPrompt = `Generate a "${templateName}" document for: ${subject.trim()}
${spiritBlock}
${specialInstructions ? `
Special instructions: ${specialInstructions}` : ""}

Template sections to generate:
${sectionList}

Return JSON in this exact structure:
{
  "title": "document title",
  "subtitle": "document subtitle or date",
  "sections": [
    { "id": "section-id", "label": "Section Label", "content": "Full section content, well-written and ministry-appropriate." }
  ]
}

Write each section with pastoral authority, biblical grounding, and practical ministry application. Format for print.`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25e3);
    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY || "",
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 4e3,
        system: systemPrompt,
        messages: [{ role: "user", content: userPrompt }]
      }),
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (!anthropicRes.ok) {
      const err = await anthropicRes.text();
      throw new Error(`Anthropic error ${anthropicRes.status}: ${err}`);
    }
    const data = await anthropicRes.json();
    const rawText = data.content?.[0]?.text || "";
    const inputTokens = data.usage?.input_tokens || 0;
    const outputTokens = data.usage?.output_tokens || 0;
    const url = new URL(req.url);
    const baseUrl = `${url.protocol}//${url.host}`;
    logUsage(token, baseUrl, "document", inputTokens, outputTokens);
    const document = parseDocumentJson(rawText);
    if (!document) throw new Error("Failed to parse document JSON from AI response");
    if (document?.sections) {
      document.sections = document.sections.map((s) => ({ ...s, content: cleanAIOutput(s.content || "") }));
    }
    return new Response(JSON.stringify({ success: true, document }), { status: 200, headers });
  } catch (e) {
    if (e.name === "AbortError") {
      return new Response(JSON.stringify({ error: "Document generation timed out \u2014 try again" }), { status: 504, headers });
    }
    return new Response(JSON.stringify({ error: e.message || "Generation failed" }), { status: 500, headers });
  }
}
var config = { path: "/api/generate-document" };
export {
  config,
  handler as default
};
