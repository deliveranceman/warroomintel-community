
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/library-summary.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function supabaseClient() {
  return createClient(
    supabaseUrl,
    supabaseServiceKey
  );
}
async function isMinister(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return false;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return false;
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return false;
    const data = await res.json();
    return data?.public_metadata?.role === "minister";
  } catch {
    return false;
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "GET") return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: CORS });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: CORS });
  const ok = await isMinister(token);
  if (!ok) return new Response(JSON.stringify({ error: "Forbidden \u2014 minister role required" }), { status: 403, headers: CORS });
  const sb = supabaseClient();
  const { data, error } = await sb.from("resources").select("id,title,author,notes,file_size,active,ai_generated,created_at").eq("topic", "ministry-library").order("created_at", { ascending: false });
  if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: CORS });
  const books = data || [];
  const total = books.length;
  const activeCount = books.filter((b) => b.active !== false).length;
  const aiCount = books.filter((b) => b.ai_generated).length;
  const summary = [
    `You have ${total} book${total !== 1 ? "s" : ""} in your ministry library.`,
    `${activeCount} ${activeCount === 1 ? "is" : "are"} active in AI context.`,
    "When enhancing spirits in the Intel Archive, Claude reads your library metadata to inform its analysis.",
    `Books marked AI=ON are referenced as theological context.`,
    `${aiCount > 0 ? `${aiCount} book${aiCount !== 1 ? "s were" : " was"} catalogued by AI auto-fill. ` : ""}Full text extraction is not yet active \u2014 books contribute their title, author, and notes to AI prompts.`
  ].join(" ");
  return new Response(JSON.stringify({ books, summary }), { status: 200, headers: CORS });
}
var config = { path: "/api/library-summary" };
export {
  config,
  handler as default
};
