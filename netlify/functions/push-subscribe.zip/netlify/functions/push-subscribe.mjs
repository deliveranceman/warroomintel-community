
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/push-subscribe.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function sb() {
  return createClient(supabaseUrl, supabaseServiceKey);
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: HEADERS });
  if (req.method === "POST") {
    let body;
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: HEADERS });
    }
    const { userId, subscription } = body || {};
    if (!userId || !subscription) {
      return new Response(JSON.stringify({ error: "userId and subscription required" }), { status: 400, headers: HEADERS });
    }
    const sub = typeof subscription === "string" ? JSON.parse(subscription) : subscription;
    const endpoint = sub.endpoint;
    if (!endpoint) {
      return new Response(JSON.stringify({ error: "Subscription missing endpoint" }), { status: 400, headers: HEADERS });
    }
    if (!sub.keys?.auth || !sub.keys?.p256dh) {
      return new Response(JSON.stringify({ error: "Subscription missing keys.auth or keys.p256dh \u2014 subscription is incomplete" }), { status: 400, headers: HEADERS });
    }
    const { error } = await sb().from("push_subscriptions").upsert(
      { user_id: userId, endpoint, subscription: sub, updated_at: (/* @__PURE__ */ new Date()).toISOString() },
      { onConflict: "endpoint" }
    );
    if (error) {
      console.error("[push-subscribe] upsert error:", error.message);
      return new Response(JSON.stringify({ error: "Failed to save subscription" }), { status: 500, headers: HEADERS });
    }
    return new Response(JSON.stringify({ success: true }), { status: 200, headers: HEADERS });
  }
  if (req.method === "DELETE") {
    let body;
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: HEADERS });
    }
    const { userId } = body || {};
    if (!userId) {
      return new Response(JSON.stringify({ error: "userId required" }), { status: 400, headers: HEADERS });
    }
    const { error } = await sb().from("push_subscriptions").delete().eq("user_id", userId);
    if (error) {
      console.error("[push-subscribe] delete error:", error.message);
      return new Response(JSON.stringify({ error: "Failed to remove subscription" }), { status: 500, headers: HEADERS });
    }
    return new Response(JSON.stringify({ success: true }), { status: 200, headers: HEADERS });
  }
  return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: HEADERS });
}
var config = { path: "/api/push-subscribe" };
export {
  config,
  handler as default
};
