
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/update-profile.ts
var clerkSecretKey = process.env.CLERK_SECRET_KEY;
var update_profile_default = async (req, _context) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }
  const authHeader = req.headers.get("Authorization");
  const sessionToken = authHeader?.replace("Bearer ", "");
  if (!sessionToken) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });
  }
  const verifyRes = await fetch("https://api.clerk.com/v1/sessions/verify", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${clerkSecretKey}`,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: new URLSearchParams({ token: sessionToken })
  });
  if (!verifyRes.ok) {
    return new Response(JSON.stringify({ error: "Invalid session" }), { status: 401 });
  }
  const session = await verifyRes.json();
  const userId = session.user_id;
  if (!userId) {
    return new Response(JSON.stringify({ error: "Could not identify user" }), { status: 401 });
  }
  const { bio, city, state, expertiseTags } = await req.json();
  const getRes = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
    headers: { Authorization: `Bearer ${clerkSecretKey}` }
  });
  const existing = await getRes.json();
  const existingMeta = existing.public_metadata || {};
  const patchRes = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${clerkSecretKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      public_metadata: {
        ...existingMeta,
        ...bio !== void 0 && { bio },
        ...city !== void 0 && { city },
        ...state !== void 0 && { state },
        ...expertiseTags !== void 0 && { expertiseTags }
      }
    })
  });
  if (!patchRes.ok) {
    const err = await patchRes.text();
    return new Response(JSON.stringify({ error: err }), { status: 500 });
  }
  return new Response(JSON.stringify({ success: true }), {
    status: 200,
    headers: { "Content-Type": "application/json" }
  });
};
var config = { path: "/api/update-profile-secure" };
export {
  config,
  update_profile_default as default
};
