
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/ai-enhance-poll.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
async function verifyToken(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return false;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    return !!payload.sub;
  } catch {
    return false;
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  if (req.method !== "GET") return new Response("Method not allowed", { status: 405 });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
  const ok = await verifyToken(token);
  if (!ok) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
  const url = new URL(req.url);
  const jobId = url.searchParams.get("jobId");
  if (!jobId) return new Response(JSON.stringify({ error: "jobId required" }), { status: 400, headers });
  const sb = createClient(supabaseUrl, supabaseServiceKey);
  const { data, error } = await sb.from("ai_enhance_jobs").select("status,fields,error").eq("id", jobId).single();
  if (error || !data) {
    return new Response(JSON.stringify({ status: "pending" }), { status: 200, headers });
  }
  return new Response(JSON.stringify({
    status: data.status,
    fields: data.fields || void 0,
    error: data.error || void 0
  }), { status: 200, headers });
}
var config = { path: "/api/ai-enhance-poll" };
export {
  config,
  handler as default
};
