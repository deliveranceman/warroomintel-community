
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/sol-research.ts
var { url: supabaseUrl, serviceRoleKey } = JSON.parse(process.env.SUPABASE || "{}");
var SB_HEADERS = {
  apikey: serviceRoleKey,
  Authorization: `Bearer ${serviceRoleKey}`,
  "Content-Type": "application/json"
};
var sb = (path) => `${supabaseUrl}/rest/v1${path}`;
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
};
var JSON_HEADERS = { ...CORS, "Content-Type": "application/json" };
function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });
}
async function resolveMinister(token) {
  try {
    if (!token || token.split(".").length !== 3) return { ok: false, userId: "", reason: "Invalid JWT" };
    const parts = token.split(".");
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf-8"));
    const userId = payload.sub || payload.userId || payload.user_id;
    if (!userId) return { ok: false, userId: "", reason: "No userId in JWT" };
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return { ok: false, userId: "", reason: `Clerk error ${res.status}` };
    const data = await res.json();
    const role = data?.public_metadata?.role;
    if (role !== "minister") return { ok: false, userId: "", reason: `Role '${role}' \u2014 minister required` };
    return { ok: true, userId, reason: "" };
  } catch (e) {
    return { ok: false, userId: "", reason: e.message || "Auth exception" };
  }
}
var MAX_TEXT = 5e4;
async function extractFromBuffer(buffer, mimeType, fileName) {
  const ext = fileName.split(".").pop()?.toLowerCase() || "";
  if (mimeType.startsWith("image/") || ["jpg", "jpeg", "png", "webp", "gif"].includes(ext)) {
    return { text: null, base64: buffer.toString("base64"), isImage: true, contentType: mimeType || "image/jpeg" };
  }
  if (mimeType === "application/pdf" || ext === "pdf") {
    try {
      const pdfParse = (await import("pdf-parse")).default;
      const data = await pdfParse(buffer);
      return { text: (data.text || "").slice(0, MAX_TEXT), base64: null, isImage: false, contentType: "pdf" };
    } catch (e) {
      console.error("[sol-research] PDF extraction failed:", e.message);
      return { text: null, base64: null, isImage: false, contentType: "pdf" };
    }
  }
  const text = new TextDecoder("utf-8").decode(buffer).replace(/\0/g, " ").slice(0, MAX_TEXT);
  return { text: text || null, base64: null, isImage: false, contentType: "text" };
}
async function extractFromUrl(url) {
  const res = await fetch(url, {
    headers: { "User-Agent": "WRI-Research/1.0" },
    signal: AbortSignal.timeout(1e4)
  });
  const html = await res.text();
  const text = html.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, MAX_TEXT);
  return { text, contentType: "url" };
}
var SYSTEM_PROMPT = `You are SOL, War Room Intel's AI intelligence officer for spiritual warfare ministry. You have deep knowledge of deliverance ministry, demonic spirits, their manifestations, legal grounds, and biblical responses. You are analyzing content submitted by Pastor Justin Payne for ministry research purposes. Be thorough, specific, and ministerially useful. Structure your response clearly with headers and bullet points where appropriate.`;
var DEFAULT_QUESTION = `Extract all demonic spirits mentioned or implied in this content. For each spirit found, provide: name, how it manifests, what legal ground it uses, and any scripture references. Format as a structured list.`;
async function callClaude(params) {
  const question = params.question?.trim() || DEFAULT_QUESTION;
  let userContent;
  if (params.base64 && params.mimeType) {
    userContent = [
      {
        type: "image",
        source: { type: "base64", media_type: params.mimeType, data: params.base64 }
      },
      {
        type: "text",
        text: `RESEARCH QUESTION:
${question}

Please provide a thorough, structured response.`
      }
    ];
  } else {
    userContent = `CONTENT TO ANALYZE:
---
${params.text || ""}
---

RESEARCH QUESTION:
${question}

Please provide a thorough, structured response.`;
  }
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY || "",
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-5",
      max_tokens: 2e3,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: userContent }]
    }),
    signal: AbortSignal.timeout(25e3)
  });
  if (!res.ok) throw new Error(`Anthropic API error ${res.status}: ${await res.text()}`);
  const data = await res.json();
  const answer = data.content?.[0]?.text || "";
  const tokensUsed = (data.usage?.input_tokens || 0) + (data.usage?.output_tokens || 0);
  return { answer, tokensUsed };
}
async function logResearch(params) {
  try {
    await fetch(`${sb("/sol_research_log")}`, {
      method: "POST",
      headers: { ...SB_HEADERS, Prefer: "return=minimal" },
      body: JSON.stringify({
        user_id: params.userId,
        question: params.question,
        content_type: params.contentType,
        content_preview: params.contentPreview.slice(0, 200),
        answer: params.answer,
        tokens_used: params.tokensUsed
      })
    });
  } catch (e) {
    console.error("[sol-research] Log insert failed:", e);
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const token = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "").trim();
  if (!token) return json({ error: "Unauthorized" }, 401);
  const auth = await resolveMinister(token);
  if (!auth.ok) return json({ error: auth.reason }, 403);
  if (req.method === "GET") {
    const res = await fetch(
      `${sb("/sol_research_log")}?user_id=eq.${encodeURIComponent(auth.userId)}&order=created_at.desc&limit=10&select=id,question,content_type,content_preview,answer,tokens_used,created_at`,
      { headers: SB_HEADERS }
    );
    if (!res.ok) return json({ error: "Database error" }, 500);
    return json({ log: await res.json() });
  }
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  const contentTypeHeader = req.headers.get("content-type") || "";
  let extracted = null;
  let question = "";
  let contentPreview = "";
  try {
    if (contentTypeHeader.includes("multipart/form-data")) {
      const formData = await req.formData();
      const file = formData.get("file");
      question = String(formData.get("question") || "").trim();
      if (!file || typeof file === "string") return json({ error: "file field required" }, 400);
      const f = file;
      if (f.size > 20 * 1024 * 1024) return json({ error: "Max file size is 20MB" }, 400);
      const arrayBuffer = await f.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);
      extracted = await extractFromBuffer(buffer, f.type, f.name);
      contentPreview = extracted.isImage ? `[image: ${f.name}]` : extracted.text?.slice(0, 200) || "[no text extracted]";
    } else {
      const body = await req.json().catch(() => ({}));
      question = String(body.question || "").trim();
      if (body.url) {
        const { text, contentType } = await extractFromUrl(String(body.url));
        extracted = { text, base64: null, isImage: false, contentType };
        contentPreview = text.slice(0, 200);
      } else if (body.text) {
        const t = String(body.text).slice(0, MAX_TEXT);
        extracted = { text: t, base64: null, isImage: false, contentType: "text" };
        contentPreview = t.slice(0, 200);
      } else {
        return json({ error: "Provide a file, url, or text field" }, 400);
      }
    }
  } catch (e) {
    return json({ error: `Content processing failed: ${e.message}` }, 400);
  }
  if (!extracted) return json({ error: "No content extracted" }, 400);
  if (!extracted.isImage && !extracted.text?.trim()) {
    return json({ error: "Could not extract readable text from this content" }, 422);
  }
  try {
    const { answer, tokensUsed } = await callClaude({
      text: extracted.text,
      base64: extracted.base64,
      mimeType: extracted.isImage ? extracted.contentType : void 0,
      question
    });
    logResearch({
      userId: auth.userId,
      question: question || DEFAULT_QUESTION,
      contentType: extracted.contentType,
      contentPreview,
      answer,
      tokensUsed
    }).catch(() => {
    });
    return json({ answer, tokensUsed, contentType: extracted.contentType });
  } catch (e) {
    console.error("[sol-research] Claude call failed:", e.message);
    return json({ error: e.message || "Analysis failed" }, 500);
  }
}
var config = { path: "/api/sol-research" };
export {
  config,
  handler as default
};
