
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/daily-devotion.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var supabase = createClient(supabaseUrl, supabaseServiceKey);
var CLERK_SECRET = process.env.CLERK_SECRET_KEY;
var headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
async function resolveUser(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return null;
    const userRes = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${CLERK_SECRET}` }
    });
    if (!userRes.ok) return null;
    const userData = await userRes.json();
    return { userId, userData };
  } catch {
    return null;
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  const url = new URL(req.url);
  const dateParam = url.searchParams.get("date");
  const archive = url.searchParams.get("archive");
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (req.method === "POST" || req.method === "PUT" || req.method === "DELETE") {
    if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
    const auth = await resolveUser(token);
    if (!auth) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
    const role = auth.userData?.public_metadata?.role;
    if (role !== "minister") return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers });
    if (req.method === "DELETE") {
      const id = url.searchParams.get("id");
      if (!id) return new Response(JSON.stringify({ error: "id required" }), { status: 400, headers });
      await supabase.from("daily_devotions").delete().eq("id", id);
      return new Response(JSON.stringify({ success: true }), { status: 200, headers });
    }
    const body = await req.json();
    if (req.method === "PUT") {
      const id = url.searchParams.get("id");
      if (!id) return new Response(JSON.stringify({ error: "id required" }), { status: 400, headers });
      const { data: data2, error: error2 } = await supabase.from("daily_devotions").update({
        date: body.date,
        title: body.title,
        morning_prayer: body.morningPrayer || null,
        evening_prayer: body.eveningPrayer || null,
        devotional_text: body.devotionalText || null,
        scripture: body.scripture || null,
        scripture_reference: body.scriptureReference || null,
        youtube_url: body.youtubeUrl || null,
        min_tier: body.minTier || "watchman",
        published: body.published ?? false
      }).eq("id", id).select().single();
      if (error2) return new Response(JSON.stringify({ error: error2.message }), { status: 500, headers });
      return new Response(JSON.stringify({ devotion: data2 }), { status: 200, headers });
    }
    const { data, error } = await supabase.from("daily_devotions").insert({
      date: body.date,
      title: body.title,
      morning_prayer: body.morningPrayer || null,
      evening_prayer: body.eveningPrayer || null,
      devotional_text: body.devotionalText || null,
      scripture: body.scripture || null,
      scripture_reference: body.scriptureReference || null,
      youtube_url: body.youtubeUrl || null,
      min_tier: body.minTier || "watchman",
      published: body.published ?? false,
      created_by: auth.userId
    }).select().single();
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers });
    return new Response(JSON.stringify({ devotion: data }), { status: 201, headers });
  }
  if (req.method === "GET") {
    if (url.searchParams.get("drafts") === "true") {
      const draftToken = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
      if (!draftToken) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
      const draftAuth = await resolveUser(draftToken);
      if (!draftAuth || draftAuth.userData?.public_metadata?.role !== "minister") {
        return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers });
      }
      const { data: data2 } = await supabase.from("daily_devotions").select("*").eq("published", false).order("date", { ascending: false }).limit(20);
      return new Response(JSON.stringify({ drafts: data2 || [] }), { status: 200, headers });
    }
    if (archive === "true") {
      const archiveToken = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
      const archiveAuth = archiveToken ? await resolveUser(archiveToken) : null;
      const isAdminCall = archiveAuth?.userData?.public_metadata?.role === "minister";
      const since = /* @__PURE__ */ new Date();
      since.setDate(since.getDate() - 30);
      let query = supabase.from("daily_devotions").select("id, date, title, published, created_by").gte("date", since.toISOString().slice(0, 10)).order("date", { ascending: false });
      if (!isAdminCall) query = query.eq("published", true);
      const { data: data2 } = await query;
      return new Response(JSON.stringify({ devotions: data2 || [] }), { status: 200, headers });
    }
    const targetDate = dateParam || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
    const { data } = await supabase.from("daily_devotions").select("*").eq("date", targetDate).eq("published", true).single();
    return new Response(JSON.stringify({ devotion: data || null }), { status: 200, headers });
  }
  return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers });
}
var config = { path: "/api/daily-devotion" };
export {
  config,
  handler as default
};
