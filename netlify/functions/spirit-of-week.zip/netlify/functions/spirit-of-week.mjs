
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/spirit-of-week.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function sb() {
  return createClient(supabaseUrl, supabaseServiceKey);
}
function resolveUserId(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return "";
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
    return payload.sub || "";
  } catch {
    return "";
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method === "GET") {
    const { data, error } = await sb().from("spirit_of_week").select("*").eq("active", true).order("published_at", { ascending: false }).limit(1).single();
    if (error || !data) {
      return new Response(JSON.stringify({ sotw: null }), { status: 200, headers: CORS });
    }
    return new Response(JSON.stringify({ sotw: data }), { status: 200, headers: CORS });
  }
  if (req.method === "POST") {
    const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim() || "";
    const userId = resolveUserId(token);
    if (!userId) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: CORS });
    }
    const body = await req.json().catch(() => ({}));
    const { spirit_name, minister_note, deliverance_tip } = body;
    if (!spirit_name?.trim()) {
      return new Response(JSON.stringify({ error: "spirit_name required" }), { status: 400, headers: CORS });
    }
    await sb().from("spirit_of_week").update({ active: false }).eq("active", true);
    const { data, error } = await sb().from("spirit_of_week").insert({
      spirit_name: spirit_name.trim(),
      minister_note: minister_note?.trim() || null,
      deliverance_tip: deliverance_tip?.trim() || null,
      active: true,
      created_by: userId
    }).select("*").single();
    if (error) {
      return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: CORS });
    }
    return new Response(JSON.stringify({ success: true, sotw: data }), { status: 200, headers: CORS });
  }
  return new Response("Method not allowed", { status: 405, headers: CORS });
}
var config = { path: "/api/spirit-of-week" };
export {
  config,
  handler as default
};
