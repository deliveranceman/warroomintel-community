
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/clerk-webhook.ts
import crypto from "crypto";
import { Webhook } from "svix";
import { StreamChat } from "stream-chat";
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Content-Type": "application/json"
};
var TIER_LEVEL = {
  watchman: 0,
  free: 0,
  soldier: 1,
  charter_soldier: 1,
  commander: 2,
  charter_commander: 2,
  general: 3,
  founding_general: 3,
  minister: 4
};
function tierNum(tier) {
  return TIER_LEVEL[(tier || "").toLowerCase()] ?? 0;
}
var STREAM_CHANNELS = [
  { id: "war-room-general", name: "War Room Community", minTier: 0 },
  { id: "field-reports-live", name: "Field Reports Live", minTier: 1 },
  { id: "commanders-room", name: "Commanders Room", minTier: 2 },
  { id: "generals-table", name: "General's Table", minTier: 3 }
];
async function addUserToStreamChannels(client, streamUserId, tier) {
  const level = tierNum(tier);
  const eligible = STREAM_CHANNELS.filter((ch) => level >= ch.minTier);
  for (const ch of eligible) {
    try {
      const channel = client.channel("messaging", ch.id);
      await channel.addMembers([streamUserId]);
      console.log(`[clerk-webhook] Added ${streamUserId} to ${ch.id}`);
    } catch (e) {
      console.error(`[clerk-webhook] Failed to add ${streamUserId} to ${ch.id}:`, e.message);
    }
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: HEADERS });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const webhookSecret = process.env.CLERK_WEBHOOK_SECRET;
  if (!webhookSecret) {
    console.error("[clerk-webhook] CLERK_WEBHOOK_SECRET not set");
    return new Response(JSON.stringify({ error: "Webhook secret not configured" }), { status: 500, headers: HEADERS });
  }
  const svixId = req.headers.get("svix-id") ?? "";
  const svixTimestamp = req.headers.get("svix-timestamp") ?? "";
  const svixSignature = req.headers.get("svix-signature") ?? "";
  if (!svixId || !svixTimestamp || !svixSignature) {
    return new Response(JSON.stringify({ error: "Missing Svix headers" }), { status: 400, headers: HEADERS });
  }
  const body = await req.text();
  let event;
  try {
    const wh = new Webhook(webhookSecret);
    event = wh.verify(body, {
      "svix-id": svixId,
      "svix-timestamp": svixTimestamp,
      "svix-signature": svixSignature
    });
  } catch (err) {
    console.error("[clerk-webhook] Signature verification failed:", err.message);
    return new Response(JSON.stringify({ error: "Invalid signature" }), { status: 400, headers: HEADERS });
  }
  const { type, data } = event;
  console.log("[clerk-webhook] Event:", type);
  const _stream = JSON.parse(process.env.STREAM || "{}");
  const streamApiKey = _stream.apiKey;
  const streamApiSecret = _stream.apiSecret;
  try {
    if (type === "user.created") {
      const { id, first_name, last_name, email_addresses } = data;
      const email = email_addresses?.[0]?.email_address || "";
      const name = `${first_name || ""} ${last_name || ""}`.trim() || email || "Warrior";
      const tier = "general";
      await fetch(`https://api.clerk.com/v1/users/${id}`, {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ public_metadata: { tier } })
      });
      console.log(`[clerk-webhook] Set tier=general (beta default) for ${id}`);
      if (streamApiKey && streamApiSecret) {
        const client = new StreamChat(streamApiKey, streamApiSecret);
        const streamUserId = id.replace(/[^a-zA-Z0-9_-]/g, "_");
        await client.upsertUser({ id: streamUserId, name, role: "user" });
        await addUserToStreamChannels(client, streamUserId, tier);
        console.log(`[clerk-webhook] Stream setup complete for ${streamUserId}`);
        const feedsJWT = (() => {
          const h = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
          const p = Buffer.from(JSON.stringify({ resource: "*", action: "*", feed_id: "*" })).toString("base64url");
          const s = crypto.createHmac("sha256", streamApiSecret).update(`${h}.${p}`).digest("base64url");
          return `${h}.${p}.${s}`;
        })();
        fetch(`https://us-east-api.stream-io-api.com/api/v1.0/users/?api_key=${streamApiKey}`, {
          method: "POST",
          headers: { "Content-Type": "application/json", "Authorization": feedsJWT, "Stream-Auth-Type": "jwt" },
          body: JSON.stringify({ users: [{ id: streamUserId, name }] })
        }).catch((e) => console.error("[clerk-webhook] Feeds upsert error:", e));
      }
    }
    if (type === "user.updated") {
      const { id, public_metadata } = data;
      const tier = public_metadata?.tier || "watchman";
      if (streamApiKey && streamApiSecret) {
        const client = new StreamChat(streamApiKey, streamApiSecret);
        const streamUserId = id.replace(/[^a-zA-Z0-9_-]/g, "_");
        const firstName = data.first_name || "";
        const lastName = data.last_name || "";
        const name = `${firstName} ${lastName}`.trim() || "Warrior";
        await client.upsertUser({ id: streamUserId, name, role: "user" });
        await addUserToStreamChannels(client, streamUserId, tier);
        console.log(`[clerk-webhook] Updated Stream membership for ${streamUserId} at tier=${tier}`);
      }
    }
  } catch (err) {
    console.error("[clerk-webhook] Handler error:", err.message);
  }
  return new Response(JSON.stringify({ received: true }), { status: 200, headers: HEADERS });
}
var config = { path: "/api/clerk-webhook" };
export {
  config,
  handler as default
};
