
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/create-dm.ts
import { createHmac } from "crypto";
function makeServerToken(apiSecret) {
  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
  const payload = Buffer.from(JSON.stringify({ server: true })).toString("base64url");
  const sig = createHmac("sha256", apiSecret).update(`${header}.${payload}`).digest("base64url");
  return `${header}.${payload}.${sig}`;
}
function streamFetch(path, method, token, apiKey, body) {
  return fetch(`https://chat.stream-io-api.com${path}?api_key=${apiKey}`, {
    method,
    headers: { "Content-Type": "application/json", "Authorization": token, "Stream-Auth-Type": "jwt" },
    ...body ? { body: JSON.stringify(body) } : {}
  }).then((r) => r.json());
}
var create_dm_default = async (req, _context) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    });
  }
  const stream = JSON.parse(process.env.STREAM || "{}");
  const streamApiKey = stream.apiKey;
  const streamApiSecret = stream.apiSecret;
  try {
    const { userId, otherUserId } = await req.json();
    if (!userId || !otherUserId) {
      return new Response(JSON.stringify({ error: "userId and otherUserId required" }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }
    const apiKey = streamApiKey;
    const apiSecret = streamApiSecret;
    const token = makeServerToken(apiSecret);
    const sortedIds = [userId, otherUserId].sort();
    const hash = (s) => s.split("").reduce((a, c) => Math.imul(31, a) + c.charCodeAt(0) | 0, 0).toString(36).replace("-", "z");
    const channelId = ("dm" + hash(sortedIds[0]) + hash(sortedIds[1])).slice(0, 64);
    const createRes = await streamFetch(
      `/channels/messaging/${channelId}/query`,
      "POST",
      token,
      apiKey,
      {
        data: { created_by_id: userId },
        state: true,
        watch: false,
        presence: false
      }
    );
    console.log("create-dm query result:", JSON.stringify(createRes).slice(0, 200));
    const addRes = await streamFetch(
      `/channels/messaging/${channelId}`,
      "POST",
      token,
      apiKey,
      { add_members: sortedIds.map((id) => ({ user_id: id })) }
    );
    console.log("create-dm add_members result:", JSON.stringify(addRes).slice(0, 200));
    return new Response(JSON.stringify({ channelId }), {
      status: 200,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  } catch (err) {
    console.error("create-dm error:", err);
    return new Response(JSON.stringify({ error: err.message || "Stream error" }), {
      status: 500,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
};
var config = { path: "/api/create-dm" };
export {
  config,
  create_dm_default as default
};
