
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/bible-ask.ts
import { createClient as createClient3 } from "@supabase/supabase-js";

// netlify/lib/getMinistryContext.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var _cached = null;
var _cacheExpiry = 0;
async function getMinistryContext() {
  if (_cached !== null && Date.now() < _cacheExpiry) return _cached;
  try {
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { data } = await supabase.from("ministry_context").select("context_text").eq("is_active", true).single();
    const text = data?.context_text || "";
    _cached = text;
    _cacheExpiry = Date.now() + 6e4;
    return text;
  } catch {
    return "";
  }
}

// netlify/lib/ai-rate-limit.ts
import { createClient as createClient2 } from "@supabase/supabase-js";
var { url: supabaseUrl2, serviceRoleKey: supabaseServiceKey2 } = JSON.parse(process.env.SUPABASE || "{}");
async function checkAndIncrementUsage(_userId, _tier, _feature) {
  return { allowed: true, remaining: 999, limit: 999, current: 0 };
}
var FEATURE_LABELS = {
  ask_dake: "Ask Dake",
  ai_assistant: "AI Assistant",
  bible_ask: "Bible Study AI",
  symptom_investigator: "Symptom Investigator",
  gateway: "Gateway Investigator",
  dream: "Dream Interpreter",
  document: "Document Creator",
  session_ai: "Session AI",
  assessment: "Assessment Strategy"
};
function getUpgradeMessage(tier, feature) {
  const tiers = {
    watchman: "Soldier",
    free: "Soldier",
    soldier: "Commander",
    charter_soldier: "Commander",
    commander: "General",
    charter_commander: "General"
  };
  const nextTier = tiers[tier];
  const label = FEATURE_LABELS[feature] || feature;
  if (!nextTier) return `You have reached your daily limit for ${label}.`;
  return `Daily limit reached for ${label}. Upgrade to ${nextTier} for more.`;
}

// netlify/lib/clean-ai-output.ts
function cleanAIOutput(text) {
  return text.replace(/\s—\s/g, ", ").replace(/—/g, " - ").replace(/\s–\s/g, ", ").replace(/\bIn conclusion,?\s*/gi, "").replace(/\bTo summarize,?\s*/gi, "").replace(/\bIt is worth noting that\s*/gi, "").replace(/\bIt is important to note that\s*/gi, "").replace(/\bNotably,?\s*/gi, "").replace(/\bFurthermore,?\s*/gi, "").replace(/\bMoreover,?\s*/gi, "").replace(/\bAdditionally,?\s*/gi, "").replace(/\bIn other words,?\s*/gi, "").replace(/\bAs previously mentioned,?\s*/gi, "").replace(/\bAs we can see,?\s*/gi, "").replace(/\bIt goes without saying\s*/gi, "").replace(/\bNeedless to say,?\s*/gi, "").replace(/\bAt the end of the day,?\s*/gi, "").replace(/\bWith that said,?\s*/gi, "").replace(/\bThat being said,?\s*/gi, "").replace(/\bHaving said that,?\s*/gi, "").replace(/  +/g, " ").replace(/\s,/g, ",").trim();
}

// netlify/functions/bible-ask.ts
var { url: supabaseUrl3, serviceRoleKey: supabaseServiceKey3 } = JSON.parse(process.env.SUPABASE || "{}");
function sb() {
  return createClient3(supabaseUrl3, supabaseServiceKey3);
}
async function searchLibrary(question) {
  try {
    const client = sb();
    const keywords = question.toLowerCase().split(/\s+/).filter((w) => w.length > 4).slice(0, 5);
    if (keywords.length === 0) return "";
    const orFilter = keywords.map((k) => `title.ilike.%${k}%,description.ilike.%${k}%`).join(",");
    const { data } = await client.from("resources").select("title, description, spirit_tags, author").or(orFilter).limit(4);
    if (!data || data.length === 0) return "";
    return data.map(
      (r) => `TITLE: ${r.title}${r.author ? ` by ${r.author}` : ""}
${r.description || ""}
Tags: ${(r.spirit_tags || []).join(", ")}`
    ).join("\n\n");
  } catch {
    return "";
  }
}
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
async function resolveUser(token) {
  try {
    if (!token || token.split(".").length !== 3) return { ok: false, tier: "", userId: "" };
    const payload = JSON.parse(Buffer.from(token.split(".")[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return { ok: false, tier: "", userId: "" };
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return { ok: false, tier: "", userId: "" };
    const data = await res.json();
    const role = data?.public_metadata?.role;
    const tier = data?.public_metadata?.tier || "";
    const lvl = (t) => ({ free: 0, watchman: 0, soldier: 1, commander: 2, general: 3, minister: 99 })[t?.toLowerCase()] ?? 0;
    return { ok: role === "minister" || lvl(tier) >= 1, tier, userId };
  } catch {
    return { ok: false, tier: "", userId: "" };
  }
}
async function callClaude(question, book, chapter, verseText, conversationHistory, libraryContext) {
  const systemPrompt = `You are a theological scholar with deep knowledge of Finis Jennings Dake's Annotated Reference Bible.
You answer questions about Scripture passages drawing from:
- Dake's specific annotations, notes, and theological positions
- Greek and Hebrew word studies
- Spiritual warfare implications in the text
- Prophetic significance and prophetic fulfillment
- Deliverance ministry applications

When the user asks about Greek or Hebrew meanings, be specific with the original words.
When they ask about spirits mentioned, name them specifically and give biblical context.
When referencing Dake's notes, begin with "According to Dake," and present his position clearly.
Include Scripture citations in the format Book Chapter:Verse whenever applicable.
Be specific, scholarly, and spiritually practical.
Keep responses focused \u2014 typically 2-4 paragraphs.${libraryContext ? `

Relevant ministry library resources for additional context:
${libraryContext}` : ""}`;
  const contextLine = verseText ? `Current passage: ${book} ${chapter}
Selected verse: "${verseText}"` : `Current passage: ${book} ${chapter}`;
  const messages = [
    ...conversationHistory.map((m) => ({ role: m.role, content: m.content })),
    { role: "user", content: `${contextLine}

${question}` }
  ];
  const ministryContext = await getMinistryContext();
  const effectiveSystem = ministryContext ? `${ministryContext}

---

${systemPrompt}` : systemPrompt;
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1500,
      system: effectiveSystem,
      messages
    }),
    signal: AbortSignal.timeout(25e3)
  });
  if (!res.ok) throw new Error(`Claude error ${res.status}`);
  const data = await res.json();
  return cleanAIOutput((data.content?.[0]?.text || "").trim());
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: HEADERS });
  if (req.method === "GET") {
    const url = new URL(req.url);
    if (url.searchParams.get("commentary") !== "true") {
      return new Response(JSON.stringify({ error: "commentary=true required" }), { status: 400, headers: HEADERS });
    }
    const reference = url.searchParams.get("reference") || "";
    if (!reference) {
      return new Response(JSON.stringify({ error: "reference required" }), { status: 400, headers: HEADERS });
    }
    const token2 = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
    if (!token2) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: HEADERS });
    const auth2 = await resolveUser(token2);
    if (!auth2.ok) return new Response(JSON.stringify({ error: "Soldier tier or higher required" }), { status: 403, headers: HEADERS });
    try {
      const aiRes = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 400,
          system: `You are a theological scholar writing brief commentary in the style of Finis Jennings Dake's Annotated Reference Bible. Focus on spiritual warfare applications, prophetic significance, and deliverance ministry insights. Write 2-3 short paragraphs. No headers, plain prose only.`,
          messages: [{ role: "user", content: `Write a brief Dake-style commentary on ${reference}, focusing on spiritual warfare and deliverance applications.` }]
        }),
        signal: AbortSignal.timeout(2e4)
      });
      if (!aiRes.ok) throw new Error(`Claude error ${aiRes.status}`);
      const data = await aiRes.json();
      const commentary = cleanAIOutput((data.content?.[0]?.text || "").trim());
      return new Response(JSON.stringify({ commentary, source: "SOL \xB7 Dake Style" }), { headers: HEADERS });
    } catch (e) {
      console.error("[bible-ask] commentary error:", e.message);
      return new Response(JSON.stringify({ error: e.message || "Commentary failed" }), { status: 500, headers: HEADERS });
    }
  }
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "POST required" }), { status: 405, headers: HEADERS });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: HEADERS });
  const auth = await resolveUser(token);
  if (!auth.ok) return new Response(JSON.stringify({ error: "Soldier tier or higher required" }), { status: 403, headers: HEADERS });
  const usage = await checkAndIncrementUsage(auth.userId, auth.tier || "watchman", "bible_ask");
  if (!usage.allowed) {
    return new Response(JSON.stringify({ error: getUpgradeMessage(auth.tier || "watchman", "bible_ask"), rateLimited: true, limit: usage.limit, remaining: 0 }), { status: 429, headers: HEADERS });
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: HEADERS });
  }
  const { question = "", book = "Genesis", chapter = 1, verseText = "", conversationHistory = [], useLibrary } = body || {};
  if (!question?.trim()) {
    return new Response(JSON.stringify({ error: "question is required" }), { status: 400, headers: HEADERS });
  }
  try {
    const libraryContext = useLibrary !== false ? await searchLibrary(question.trim()) : "";
    const response = await callClaude(question.trim(), book, Number(chapter), verseText, conversationHistory, libraryContext);
    return new Response(JSON.stringify({ response }), { status: 200, headers: HEADERS });
  } catch (e) {
    console.error("[bible-ask] Error:", e.message);
    return new Response(JSON.stringify({ error: e.message || "Analysis failed" }), { status: 500, headers: HEADERS });
  }
}
var config = { path: "/api/bible-ask" };
export {
  config,
  handler as default
};
