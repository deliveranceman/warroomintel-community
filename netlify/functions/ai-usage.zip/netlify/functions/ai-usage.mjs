
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/ai-usage.ts
import { createClient as createClient2 } from "@supabase/supabase-js";

// netlify/lib/ai-rate-limit.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var DAILY_LIMITS = {
  watchman: {
    ask_dake: 5,
    ai_assistant: 5,
    bible_ask: 5,
    symptom_investigator: 0,
    gateway: 0,
    dream: 0,
    document: 0,
    session_ai: 0,
    assessment: 1
  },
  free: {
    ask_dake: 5,
    ai_assistant: 5,
    bible_ask: 5,
    symptom_investigator: 0,
    gateway: 0,
    dream: 0,
    document: 0,
    session_ai: 0,
    assessment: 1
  },
  soldier: {
    ask_dake: 20,
    ai_assistant: 20,
    bible_ask: 20,
    symptom_investigator: 0,
    gateway: 10,
    dream: 10,
    document: 10,
    session_ai: 0,
    assessment: 5
  },
  charter_soldier: {
    ask_dake: 20,
    ai_assistant: 20,
    bible_ask: 20,
    symptom_investigator: 0,
    gateway: 10,
    dream: 10,
    document: 10,
    session_ai: 0,
    assessment: 5
  },
  commander: {
    ask_dake: 50,
    ai_assistant: 50,
    bible_ask: 50,
    symptom_investigator: 30,
    gateway: 30,
    dream: 30,
    document: 25,
    session_ai: 15,
    assessment: 15
  },
  charter_commander: {
    ask_dake: 50,
    ai_assistant: 50,
    bible_ask: 50,
    symptom_investigator: 30,
    gateway: 30,
    dream: 30,
    document: 25,
    session_ai: 15,
    assessment: 15
  },
  general: {
    ask_dake: -1,
    ai_assistant: -1,
    bible_ask: -1,
    symptom_investigator: -1,
    gateway: -1,
    dream: -1,
    document: -1,
    session_ai: 50,
    assessment: -1
  },
  founding_general: {
    ask_dake: -1,
    ai_assistant: -1,
    bible_ask: -1,
    symptom_investigator: -1,
    gateway: -1,
    dream: -1,
    document: -1,
    session_ai: 50,
    assessment: -1
  },
  minister: {
    ask_dake: -1,
    ai_assistant: -1,
    bible_ask: -1,
    symptom_investigator: -1,
    gateway: -1,
    dream: -1,
    document: -1,
    session_ai: -1,
    assessment: -1
  },
  admin: {
    ask_dake: -1,
    ai_assistant: -1,
    bible_ask: -1,
    symptom_investigator: -1,
    gateway: -1,
    dream: -1,
    document: -1,
    session_ai: -1,
    assessment: -1
  }
};

// netlify/functions/ai-usage.ts
var { url: supabaseUrl2, serviceRoleKey: supabaseServiceKey2 } = JSON.parse(process.env.SUPABASE || "{}");
var headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function sb() {
  return createClient2(supabaseUrl2, supabaseServiceKey2);
}
async function resolveTokenUser(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return null;
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return null;
    const data = await res.json();
    const tier = data?.public_metadata?.tier || "watchman";
    const isMinister = data?.public_metadata?.role === "minister";
    return { userId, tier, isMinister };
  } catch {
    return null;
  }
}
var INPUT_COST_PER_TOKEN = 3e-6;
var OUTPUT_COST_PER_TOKEN = 15e-6;
function calcCost(inputTokens, outputTokens) {
  return inputTokens * INPUT_COST_PER_TOKEN + outputTokens * OUTPUT_COST_PER_TOKEN;
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
  if (req.method === "POST") {
    try {
      const parts = token.split(".");
      const body = await req.json();
      const { call_type, spirit_name, input_tokens = 0, output_tokens = 0, model } = body;
      if (!call_type) return new Response(JSON.stringify({ error: "call_type required" }), { status: 400, headers });
      const client2 = sb();
      if (parts.length === 3) {
        const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
        await client2.from("ai_usage_log").insert({
          user_id: payload.sub || null,
          call_type,
          spirit_name: spirit_name || null,
          input_tokens,
          output_tokens,
          model: model || null
        });
      }
      return new Response(JSON.stringify({ success: true }), { status: 200, headers });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
    }
  }
  if (req.method !== "GET") return new Response("Method not allowed", { status: 405 });
  const authUser = await resolveTokenUser(token);
  if (!authUser) return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers });
  if (!authUser.isMinister) {
    try {
      const features = Object.keys(DAILY_LIMITS.watchman).map((feature) => ({
        feature,
        used: 0,
        limit: -1,
        remaining: -1
      }));
      return new Response(JSON.stringify({ tier: authUser.tier, features }), { status: 200, headers });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
    }
  }
  const client = sb();
  if (true) {
    try {
      const now = /* @__PURE__ */ new Date();
      const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
      const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString();
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1e3).toISOString();
      const { data: allRows } = await client.from("ai_usage_log").select("called_at, call_type, spirit_name, input_tokens, output_tokens").gte("called_at", lastMonthStart).order("called_at", { ascending: false });
      const rows = allRows || [];
      const thisMonthRows = rows.filter((r) => r.called_at >= thisMonthStart);
      const lastMonthRows = rows.filter((r) => r.called_at >= lastMonthStart && r.called_at < thisMonthStart);
      const summarize = (r) => ({
        calls: r.length,
        inputTokens: r.reduce((s, x) => s + (x.input_tokens || 0), 0),
        outputTokens: r.reduce((s, x) => s + (x.output_tokens || 0), 0),
        estimatedCost: r.reduce((s, x) => s + calcCost(x.input_tokens || 0, x.output_tokens || 0), 0)
      });
      const dayMap = {};
      const recent30 = rows.filter((r) => r.called_at >= thirtyDaysAgo);
      for (const r of recent30) {
        const day = r.called_at.slice(0, 10);
        if (!dayMap[day]) dayMap[day] = { calls: 0, cost: 0 };
        dayMap[day].calls++;
        dayMap[day].cost += calcCost(r.input_tokens || 0, r.output_tokens || 0);
      }
      const byDay = Object.entries(dayMap).sort(([a], [b]) => a.localeCompare(b)).map(([date, v]) => ({ date, ...v }));
      const recentCalls = rows.slice(0, 10).map((r) => ({
        called_at: r.called_at,
        call_type: r.call_type,
        spirit_name: r.spirit_name,
        estimatedCost: calcCost(r.input_tokens || 0, r.output_tokens || 0)
      }));
      return new Response(JSON.stringify({
        thisMonth: summarize(thisMonthRows),
        lastMonth: summarize(lastMonthRows),
        byDay,
        recentCalls
      }), { status: 200, headers });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
    }
  }
  return new Response("Method not allowed", { status: 405 });
}
var config = { path: "/api/ai-usage" };
export {
  config,
  handler as default
};
