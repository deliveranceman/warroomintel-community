
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/events-ics.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
async function handler(req) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (!id) {
    return new Response("Missing id", { status: 400 });
  }
  const supabase = createClient(supabaseUrl, supabaseServiceKey);
  const { data: event, error } = await supabase.from("events").select("*").eq("id", id).eq("is_published", true).single();
  if (error || !event) return new Response("Event not found", { status: 404 });
  const start = new Date(event.event_date);
  const end = new Date(start.getTime() + (event.duration_minutes || 60) * 6e4);
  const fmt = (d) => d.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  const escape = (s) => (s || "").replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\n/g, "\\n");
  const ics = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//War Room Intel//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "BEGIN:VEVENT",
    `DTSTART:${fmt(start)}`,
    `DTEND:${fmt(end)}`,
    `SUMMARY:${escape(event.title)}`,
    event.description ? `DESCRIPTION:${escape(event.description)}` : "",
    event.zoom_link ? `LOCATION:${escape(event.zoom_link)}` : "",
    event.zoom_link ? `URL:${event.zoom_link}` : "",
    `UID:wri-event-${event.id}@warroomintel.com`,
    `DTSTAMP:${fmt(/* @__PURE__ */ new Date())}`,
    "END:VEVENT",
    "END:VCALENDAR"
  ].filter(Boolean).join("\r\n");
  const slug = (event.title || "wri-event").replace(/\s+/g, "-").replace(/[^a-zA-Z0-9-]/g, "").toLowerCase();
  return new Response(ics, {
    status: 200,
    headers: {
      "Content-Type": "text/calendar; charset=utf-8",
      "Content-Disposition": `attachment; filename="${slug}.ics"`,
      "Access-Control-Allow-Origin": "*"
    }
  });
}
var config = { path: "/api/events-ics" };
export {
  config,
  handler as default
};
