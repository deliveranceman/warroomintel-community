
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/generate-content-suggestions.ts
import { createClient as createClient2 } from "@supabase/supabase-js";

// netlify/functions/scheduled-content-suggestions.ts
import { createClient } from "@supabase/supabase-js";
import { Resend } from "resend";

// netlify/lib/clean-ai-output.ts
function cleanAIOutput(text) {
  return text.replace(/\s—\s/g, ", ").replace(/—/g, " - ").replace(/\s–\s/g, ", ").replace(/\bIn conclusion,?\s*/gi, "").replace(/\bTo summarize,?\s*/gi, "").replace(/\bIt is worth noting that\s*/gi, "").replace(/\bIt is important to note that\s*/gi, "").replace(/\bNotably,?\s*/gi, "").replace(/\bFurthermore,?\s*/gi, "").replace(/\bMoreover,?\s*/gi, "").replace(/\bAdditionally,?\s*/gi, "").replace(/\bIn other words,?\s*/gi, "").replace(/\bAs previously mentioned,?\s*/gi, "").replace(/\bAs we can see,?\s*/gi, "").replace(/\bIt goes without saying\s*/gi, "").replace(/\bNeedless to say,?\s*/gi, "").replace(/\bAt the end of the day,?\s*/gi, "").replace(/\bWith that said,?\s*/gi, "").replace(/\bThat being said,?\s*/gi, "").replace(/\bHaving said that,?\s*/gi, "").replace(/  +/g, " ").replace(/\s,/g, ",").trim();
}

// netlify/functions/scheduled-content-suggestions.ts
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
function sb() {
  return createClient(supabaseUrl, supabaseServiceKey);
}
async function generateSuggestions(topic) {
  const client = sb();
  const { data: ctxRow } = await client.from("ministry_context").select("context_text").eq("is_active", true).single();
  const ministryContext = ctxRow?.context_text || "War Room Intel \u2014 a deliverance ministry resource for serious ministers of spiritual warfare.";
  const { data: historyRows } = await client.from("ai_search_history").select("query").in("tool", ["spirit-network", "symptom-investigator"]).order("created_at", { ascending: false }).limit(30);
  const recentTopics = historyRows && historyRows.length > 0 ? [...new Set(historyRows.map((r) => r.query))].slice(0, 10).join(", ") : "general deliverance ministry topics";
  const topicInstruction = topic ? `

Focus especially on this topic the admin requested: "${topic}".` : "";
  const prompt = `Generate exactly 5 content suggestions for War Room Intel this week. Members have been researching these topics recently: ${recentTopics}.${topicInstruction}

Return ONLY a JSON array of exactly 5 objects:
[
  {
    "content_type": "weekly_intel" | "arsenal_pdf" | "daily_brief" | "field_manual" | "youtube_outline",
    "title": "Compelling title (10 words max)",
    "summary": "2-3 sentence description of what this content covers and why it matters to ministers",
    "suggested_tier": "watchman" | "soldier" | "commander" | "general"
  }
]

Make suggestions varied \u2014 not all the same type.
Ground all content in scripture and deliverance ministry.
Target serious ministers and students of spiritual warfare.
At least one suggestion should be free tier (watchman).
At least one should be general tier deep intel.

Return ONLY valid JSON. No markdown, no explanation.`;
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 800,
      system: ministryContext,
      messages: [{ role: "user", content: prompt }]
    }),
    signal: AbortSignal.timeout(25e3)
  });
  if (!res.ok) throw new Error(`Claude API error: ${res.status}`);
  const data = await res.json();
  const text = (data.content?.[0]?.text || "").trim();
  const jsonMatch = text.match(/\[[\s\S]*\]/);
  if (!jsonMatch) throw new Error("No JSON array in response");
  return JSON.parse(jsonMatch[0]);
}

// netlify/functions/generate-content-suggestions.ts
var { url: supabaseUrl2, serviceRoleKey: supabaseServiceKey2 } = JSON.parse(process.env.SUPABASE || "{}");
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function sb2() {
  return createClient2(supabaseUrl2, supabaseServiceKey2);
}
async function resolveMinister(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return false;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return false;
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return false;
    const data = await res.json();
    return data?.public_metadata?.role === "minister";
  } catch {
    return false;
  }
}
function getMondayDate() {
  const now = /* @__PURE__ */ new Date();
  const day = now.getUTCDay();
  const diff = day === 0 ? -6 : 1 - day;
  const monday = new Date(now);
  monday.setUTCDate(now.getUTCDate() + diff);
  return monday.toISOString().slice(0, 10);
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: HEADERS });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "POST required" }), { status: 405, headers: HEADERS });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: HEADERS });
  const isMinister = await resolveMinister(token);
  if (!isMinister) return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: HEADERS });
  const body = await req.json().catch(() => ({}));
  const topic = body.topic || void 0;
  const weekOf = getMondayDate();
  const suggestions = await generateSuggestions(topic);
  const client = sb2();
  const rows = suggestions.map((s) => ({
    week_of: weekOf,
    content_type: s.content_type,
    title: s.title,
    summary: cleanAIOutput(s.summary || ""),
    full_draft: s.full_draft ? cleanAIOutput(s.full_draft) : null,
    suggested_tier: s.suggested_tier || "watchman",
    status: "pending",
    created_by: "ai-agent"
  }));
  const { data, error } = await client.from("content_suggestions").insert(rows).select("id, title, content_type");
  if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: HEADERS });
  return new Response(JSON.stringify({ success: true, count: suggestions.length, suggestions: data }), { status: 200, headers: HEADERS });
}
var config = { path: "/api/generate-content-suggestions" };
export {
  config,
  handler as default
};
