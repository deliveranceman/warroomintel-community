
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/ministry-context.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function sb() {
  return createClient(supabaseUrl, supabaseServiceKey);
}
async function resolveMinister(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return false;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return false;
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return false;
    const data = await res.json();
    return data?.public_metadata?.role === "minister";
  } catch {
    return false;
  }
}
var _cached = null;
var _cacheExpiry = 0;
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  const url = new URL(req.url);
  const isAdmin = url.searchParams.get("admin") === "true";
  const id = url.searchParams.get("id");
  const action = url.searchParams.get("action");
  if (req.method === "GET" && !isAdmin) {
    if (_cached !== null && Date.now() < _cacheExpiry) {
      return new Response(JSON.stringify({ context: _cached }), { status: 200, headers });
    }
    const { data } = await sb().from("ministry_context").select("context_text").eq("is_active", true).single();
    _cached = data?.context_text || null;
    _cacheExpiry = Date.now() + 6e4;
    return new Response(JSON.stringify({ context: _cached }), { status: 200, headers });
  }
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
  const isMinister = await resolveMinister(token);
  if (!isMinister) return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers });
  if (req.method === "GET" && isAdmin) {
    const { data, error } = await sb().from("ministry_context").select("*").order("version", { ascending: false });
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers });
    return new Response(JSON.stringify({ versions: data || [] }), { status: 200, headers });
  }
  if (req.method === "POST") {
    const body = await req.json();
    const { label, context_text, notes, activate = true } = body;
    if (!label?.trim() || !context_text?.trim()) {
      return new Response(JSON.stringify({ error: "label and context_text required" }), { status: 400, headers });
    }
    const { data: maxRow } = await sb().from("ministry_context").select("version").order("version", { ascending: false }).limit(1).single();
    const nextVersion = (maxRow?.version || 0) + 1;
    if (activate) {
      await sb().from("ministry_context").update({ is_active: false }).neq("id", "00000000-0000-0000-0000-000000000000");
      _cached = null;
    }
    const { data, error } = await sb().from("ministry_context").insert({
      version: nextVersion,
      label: label.trim(),
      context_text: context_text.trim(),
      notes: notes?.trim() || null,
      is_active: activate,
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    }).select().single();
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers });
    return new Response(JSON.stringify({ id: data.id, version: data.version }), { status: 201, headers });
  }
  if (req.method === "PATCH" && id && action === "activate") {
    await sb().from("ministry_context").update({ is_active: false }).neq("id", "00000000-0000-0000-0000-000000000000");
    const { error } = await sb().from("ministry_context").update({ is_active: true }).eq("id", id);
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers });
    _cached = null;
    return new Response(JSON.stringify({ success: true }), { status: 200, headers });
  }
  if (req.method === "PATCH" && id) {
    const body = await req.json();
    const updates = {};
    if (body.label !== void 0) updates.label = body.label.trim();
    if (body.notes !== void 0) updates.notes = body.notes?.trim() || null;
    const { error } = await sb().from("ministry_context").update(updates).eq("id", id);
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers });
    return new Response(JSON.stringify({ success: true }), { status: 200, headers });
  }
  return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers });
}
var config = { path: "/api/ministry-context" };
export {
  config,
  handler as default
};
