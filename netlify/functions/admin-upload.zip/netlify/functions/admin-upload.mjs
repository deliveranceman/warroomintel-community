
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-upload.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey, bucket: supabaseBucket } = JSON.parse(process.env.SUPABASE || "{}");
var CLERK_SECRET = process.env.CLERK_SECRET_KEY;
var SUPABASE_URL = supabaseUrl;
var SUPABASE_KEY = supabaseServiceKey;
var BUCKET = supabaseBucket || "resources";
var ALLOWED_TYPES = {
  "application/pdf": { maxBytes: 25 * 1024 * 1024 },
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": { maxBytes: 25 * 1024 * 1024 },
  "audio/mpeg": { maxBytes: 50 * 1024 * 1024 },
  "image/png": { maxBytes: 5 * 1024 * 1024 },
  "image/jpeg": { maxBytes: 5 * 1024 * 1024 }
};
async function resolveUser(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) {
      console.error("Token is not a JWT \u2014 parts:", parts.length);
      return null;
    }
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    console.log("JWT payload sub:", payload.sub);
    console.log("JWT payload azp:", payload.azp);
    const userId = payload.sub;
    if (!userId) {
      console.error("No sub in JWT payload");
      return null;
    }
    const userRes = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${CLERK_SECRET}` }
    });
    console.log("User fetch status:", userRes.status);
    if (!userRes.ok) return null;
    const userData = await userRes.json();
    console.log("publicMetadata:", JSON.stringify(userData?.public_metadata));
    return { userId, userData };
  } catch (e) {
    console.error("resolveUser error:", e);
    return null;
  }
}
async function handler(req) {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const headers = { "Content-Type": "application/json" };
  const authHeader = req.headers.get("Authorization");
  const sessionToken = authHeader?.replace("Bearer ", "").trim();
  if (!sessionToken) {
    return new Response(JSON.stringify({ error: "No auth token provided" }), { status: 401, headers });
  }
  const auth = await resolveUser(sessionToken);
  if (!auth) return new Response(JSON.stringify({ error: "Unauthorized \u2014 invalid session" }), { status: 401, headers });
  const role = auth.userData?.public_metadata?.role;
  if (role !== "minister") {
    return new Response(JSON.stringify({
      error: "Forbidden \u2014 minister role required",
      debug: { userId: auth.userId, role, publicMetadata: auth.userData?.public_metadata }
    }), { status: 403, headers });
  }
  let formData;
  try {
    formData = await req.formData();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid form data" }), { status: 400 });
  }
  const file = formData.get("file");
  const title = (formData.get("title") || "").trim();
  const description = (formData.get("description") || "").trim();
  const tier = formData.get("tier") || "Free";
  const topic = formData.get("topic") || formData.get("category") || "General Ministry";
  const tagsRaw = formData.get("tags");
  const tags = tagsRaw ? JSON.parse(tagsRaw) : [];
  const spiritTagsRaw = formData.get("spirit_tags");
  const spirit_tags = spiritTagsRaw ? JSON.parse(spiritTagsRaw) : [];
  const aiAnalyze = formData.get("aiAnalyze") === "true";
  if (aiAnalyze) {
    if (!file) {
      return new Response(JSON.stringify({ error: "file is required for analysis" }), { status: 400, headers });
    }
    const fileName = file.name.replace(/\.[^.]+$/, "").replace(/[_-]/g, " ");
    const fileBuffer = await file.arrayBuffer();
    const fileText = new TextDecoder("utf-8", { fatal: false }).decode(fileBuffer.slice(0, 8e3));
    const prompt = `You are analyzing a deliverance ministry document for the War Room Intel platform.

Filename: ${file.name}
Content preview (first portion):
${fileText.slice(0, 3e3)}

Based on the filename and content, provide metadata in JSON format only. No other text.

Return exactly this structure:
{
  "title": "Clean readable title (remove underscores, file extensions, WRI_R01 prefixes etc)",
  "description": "2-3 sentence description of what this document is and how ministers would use it",
  "topic": "one of: Soul Ties, Generational Curses, Forgiveness, Ungodly Vows, Freemasonry & Secret Societies, Sexual Bondage, Fear & Rejection, Identity & Sonship, Inner Healing, Witchcraft & Occult, Marine Kingdom, Mind Control, Leviathan & Pride, Jezebel & Control, Python & Constriction, Deliverance Foundations, Aftercare, Prayer & Intercession, Scripture Reference, General Ministry",
  "tier": "one of: free, soldier, commander, general",
  "tags": ["pick 1-4 from: Renunciation Prayer, Worksheet, Teaching, Protocol, Session Tool, Scripture Reference, Aftercare, Assessment Tool, Quick Reference, Leader Guide, Self-Deliverance, Group Exercise"]
}

For tier: free = basic/intro content, soldier = intermediate ministry tools, commander = advanced protocols, general = leadership/comprehensive guides.
Respond with valid JSON only.`;
    try {
      const aiRes = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": process.env.ANTHROPIC_API_KEY || "",
          "anthropic-version": "2023-06-01"
        },
        body: JSON.stringify({
          model: "claude-haiku-4-5",
          max_tokens: 500,
          messages: [{ role: "user", content: prompt }]
        })
      });
      if (aiRes.ok) {
        const aiData = await aiRes.json();
        const text = aiData.content?.[0]?.text || "";
        const clean = text.replace(/```json|```/g, "").trim();
        const parsed = JSON.parse(clean);
        return new Response(JSON.stringify(parsed), {
          status: 200,
          headers: { ...headers, "Content-Type": "application/json" }
        });
      }
    } catch (e) {
    }
    const cleanTitle = fileName.replace(/^WRI[_\s]R?\d+[_\s]/i, "").replace(/\b\w/g, (c) => c.toUpperCase()).trim();
    return new Response(JSON.stringify({
      title: cleanTitle,
      description: "",
      topic: "General Ministry",
      tier: "free",
      tags: []
    }), { status: 200, headers });
  }
  if (!file || !title) {
    return new Response(JSON.stringify({ error: "file and title are required" }), { status: 400 });
  }
  const allowed = ALLOWED_TYPES[file.type];
  if (!allowed) {
    return new Response(JSON.stringify({ error: `File type ${file.type} not allowed` }), { status: 400 });
  }
  if (file.size > allowed.maxBytes) {
    return new Response(JSON.stringify({ error: `File too large (max ${allowed.maxBytes / 1024 / 1024}MB for this type)` }), { status: 400 });
  }
  const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
  const { data: existingFiles } = await supabase.from("resources").select("id, title, filename").ilike("file_path", `%${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}%`).neq("topic", "ministry-library").limit(1);
  if (existingFiles && existingFiles.length > 0) {
    return new Response(JSON.stringify({
      error: "duplicate",
      message: "A file with this filename already exists",
      existingId: existingFiles[0].id,
      existingTitle: existingFiles[0].title
    }), { status: 409, headers: { "Content-Type": "application/json" } });
  }
  const safeName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
  const filePath = `${tier.toLowerCase()}/${safeName}`;
  const buffer = await file.arrayBuffer();
  const { error: uploadErr } = await supabase.storage.from(BUCKET).upload(filePath, buffer, { contentType: file.type, upsert: false });
  if (uploadErr) {
    return new Response(JSON.stringify({ error: `Storage upload failed: ${uploadErr.message}` }), { status: 500 });
  }
  const { data: row, error: insertErr } = await supabase.from("resources").insert({
    title,
    description: description || null,
    tier,
    topic,
    tags: tags.length > 0 ? tags : [],
    spirit_tags: spirit_tags.length > 0 ? spirit_tags : [],
    file_path: filePath,
    file_type: file.type,
    file_size: file.size,
    // ⚠️ ARSENAL marker — arsenal-resources.ts filters on source_type to separate Arsenal from Ministry Library
    source_type: "arsenal"
  }).select().single();
  if (insertErr) {
    await supabase.storage.from(BUCKET).remove([filePath]);
    return new Response(JSON.stringify({ error: `DB insert failed: ${insertErr.message}` }), { status: 500 });
  }
  return new Response(JSON.stringify({ success: true, resource: row }), {
    status: 200,
    headers: { "Content-Type": "application/json" }
  });
}
var config = { path: "/api/admin-upload" };
export {
  config,
  handler as default
};
