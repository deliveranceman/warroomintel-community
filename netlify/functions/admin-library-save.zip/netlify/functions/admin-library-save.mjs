
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-library-save.mts
import { createClient } from "@supabase/supabase-js";
import { createRequire } from "module";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var require2 = createRequire(import.meta.url);
var BUCKET = "ministry-library";
var MAX_CHARS = 12e4;
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function makeSupabase() {
  return createClient(
    supabaseUrl,
    supabaseServiceKey
  );
}
function getUserId(authHeader) {
  if (!authHeader?.startsWith("Bearer ")) return null;
  const token = authHeader.slice(7);
  try {
    const parts = token.split(".");
    if (parts.length < 2) return null;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    return payload.sub || null;
  } catch {
    return null;
  }
}
async function isMinister(userId) {
  try {
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return false;
    const data = await res.json();
    return data?.public_metadata?.role === "minister";
  } catch {
    return false;
  }
}
async function extractText(buffer, filename) {
  const ext = filename.toLowerCase().split(".").pop();
  if (ext === "txt") {
    return new TextDecoder("utf-8").decode(buffer).replace(/\0/g, " ").slice(0, MAX_CHARS);
  }
  if (ext === "docx") {
    try {
      const mammoth = require2("mammoth");
      const result = await mammoth.extractRawText({ buffer });
      return (result.value || "").slice(0, MAX_CHARS);
    } catch (e) {
      console.error("[LIBRARY-UPLOAD] mammoth docx error:", e?.message);
      return "";
    }
  }
  if (ext === "pdf") {
    console.log("[LIBRARY-UPLOAD] PDF uploaded \u2014 text extraction not available, will need manual re-index");
    return "";
  }
  return "";
}
async function handler(req) {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: HEADERS });
  }
  if (req.method !== "POST") {
    return Response.json({ error: "Method not allowed" }, { status: 405 });
  }
  const userId = getUserId(req.headers.get("authorization"));
  if (!userId) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const ok = await isMinister(userId);
  if (!ok) return Response.json({ error: "Forbidden \u2014 minister role required" }, { status: 403 });
  let body;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid JSON body" }, { status: 400 });
  }
  const { title, author, notes, spirit_tags, filename, file_size, file_path, ai_generated, sourceType } = body;
  const source_type = sourceType === "intelligence" ? "intelligence" : "christian";
  console.log("[LIBRARY-UPLOAD] Request received", { userId, filename, file_size, file_path });
  if (!title?.trim() || !file_path) {
    return Response.json({ error: "title and file_path are required" }, { status: 400 });
  }
  const resolvedFilename = filename || file_path.split("/").pop() || "";
  const fileType = resolvedFilename.toLowerCase().endsWith(".pdf") ? "pdf" : "txt";
  const sb = makeSupabase();
  if (resolvedFilename) {
    const { data: existing } = await sb.from("resources").select("id, title, filename").eq("topic", "ministry-library").ilike("filename", resolvedFilename).limit(1);
    if (existing && existing.length > 0) {
      return Response.json({
        error: "duplicate",
        message: "A file with this filename already exists",
        existingId: existing[0].id,
        existingTitle: existing[0].title
      }, { status: 409 });
    }
  }
  console.log("[LIBRARY-UPLOAD] Writing to Supabase resources table...", { title: title.trim(), fileType, file_path });
  const { data: row, error } = await sb.from("resources").insert({
    title: title.trim(),
    author: author?.trim() || "Unknown",
    notes: notes?.trim() || "",
    filename: resolvedFilename,
    file_size: file_size || 0,
    file_path,
    file_type: fileType,
    topic: "ministry-library",
    user_id: userId,
    ai_generated: Boolean(ai_generated),
    active: true,
    spirit_tags: Array.isArray(spirit_tags) ? spirit_tags : [],
    source_type
  }).select().single();
  if (error) {
    console.error("[LIBRARY-UPLOAD] FAILED at step: Supabase insert", error.message);
    return Response.json({ success: false, error: error.message }, { status: 500 });
  }
  console.log("[LIBRARY-UPLOAD] Supabase insert result", { id: row.id, fileType });
  try {
    console.log("[LIBRARY-UPLOAD] Downloading file from storage for text extraction...", { file_path });
    const { data: fileBlob, error: dlErr } = await sb.storage.from(BUCKET).download(file_path);
    if (dlErr || !fileBlob) {
      console.error("[LIBRARY-UPLOAD] FAILED at step: Storage download", dlErr?.message);
    } else {
      const fileBuffer = Buffer.from(await fileBlob.arrayBuffer());
      console.log("[LIBRARY-UPLOAD] File downloaded from storage", { bytes: fileBuffer.length });
      const extractedText = await extractText(fileBuffer, resolvedFilename);
      console.log("[LIBRARY-UPLOAD] Text extraction result", {
        textLength: extractedText.length,
        preview: extractedText.slice(0, 300)
      });
      if (extractedText && extractedText.length >= 50) {
        const { error: updateErr } = await sb.from("resources").update({ extracted_text: extractedText }).eq("id", row.id);
        if (updateErr) {
          console.error("[LIBRARY-UPLOAD] FAILED at step: Update extracted_text", updateErr.message);
        } else {
          console.log("[LIBRARY-UPLOAD] extracted_text stored", { chars: extractedText.length, resourceId: row.id });
          try {
            console.log("[LIBRARY-UPLOAD] Calling Claude for tags...");
            const excerpt = extractedText.slice(0, 8e3);
            const aiPrompt = `You are analyzing a deliverance ministry document.

DOCUMENT TEXT (first 8000 chars):
${excerpt}

Your task:
1. Read the full text carefully
2. Identify EVERY demonic spirit, demon name, spiritual entity, or occult force mentioned or strongly implied
3. Include both explicit names (Leviathan, Baal, Jezebel) AND functional spirits (Pride, Rejection, Fear, Witchcraft, Divination)
4. Cross-reference against known demon taxonomy:
   Principalities: Satan, Leviathan, Baal, Jezebel, Python, Belial, Beelzebub, Apollyon, Abaddon, Mammon, Molech, Chemosh, Dagon, Ashtoreth, Baphomet
   Powers: Witchcraft, Divination, Freemasonry spirits, Marine spirits, Religious spirit, Spirit of Death, Infirmity
   Common spirits: Pride, Rejection, Fear, Shame, Lust, Perversion, Addiction, Confusion, Torment, Suicide, Rage, Control, Manipulation, Deception, Rebellion, Bitterness, Unforgiveness, Grief, Trauma
   Occult: Familiar spirits, Ancestral spirits, Incubus, Succubus, Voodoo spirits, Santeria, New Age spirits
5. Identify the document's PRIMARY ministry function
6. Identify the PRIMARY topic category

Return ONLY a raw JSON object. No markdown. No code fences. No explanation before or after. Start with { and end with }.
{
  "title": "clean professional document title",
  "description": "2-3 sentence summary written for a deliverance minister explaining what this document is and how to use it in ministry",
  "spirit_tags": ["Spirit1", "Spirit2"],
  "function_tags": ["Teaching"],
  "topic": "Deliverance Foundations"
}

function_tags must be from: Teaching, Protocol, Worksheet, Session Tool, Scripture Reference, Aftercare, Assessment Tool, Quick Reference, Leader Guide, Self-Deliverance, Group Exercise, Renunciation Prayer
topic must be from: Soul Ties, Generational Curses, Forgiveness, Ungodly Vows, Freemasonry & Secret Societies, Sexual Bondage, Fear, Deliverance Foundations, Witchcraft & Occult, Marine Kingdom, False Religion / Paganism, Death & Destruction, Deception / Lies, Inner Healing, Trauma & Abuse`;
            const aiRes = await fetch("https://api.anthropic.com/v1/messages", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "x-api-key": process.env.ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01"
              },
              body: JSON.stringify({
                model: "claude-haiku-4-5-20251001",
                max_tokens: 1e3,
                system: "You are a deliverance ministry document analyst. Return ONLY valid JSON. No markdown, no code fences, no explanation. Start with { and end with }.",
                messages: [{ role: "user", content: aiPrompt }]
              }),
              signal: AbortSignal.timeout(15e3)
            });
            if (aiRes.ok) {
              const aiData = await aiRes.json();
              const rawText = (aiData.content?.[0]?.text || "").trim();
              console.log("[LIBRARY-UPLOAD] Claude raw response:", rawText.slice(0, 500));
              let cleaned = rawText.replace(/^```json\s*/im, "").replace(/^```\s*/im, "").replace(/```\s*$/im, "").trim();
              const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
              if (jsonMatch) cleaned = jsonMatch[0];
              let parsed = { spirit_tags: [], function_tags: [] };
              try {
                parsed = JSON.parse(cleaned);
              } catch {
                console.error("[LIBRARY-UPLOAD] JSON parse failed:", cleaned.slice(0, 300));
              }
              console.log("[LIBRARY-UPLOAD] Parsed spirit_tags:", parsed.spirit_tags);
              const aiUpdate = {
                spirit_tags: Array.isArray(parsed.spirit_tags) ? parsed.spirit_tags : [],
                function_tags: Array.isArray(parsed.function_tags) ? parsed.function_tags : []
              };
              if (parsed.description) aiUpdate.description = parsed.description;
              if (parsed.topic) aiUpdate.topic = parsed.topic;
              await sb.from("resources").update(aiUpdate).eq("id", row.id);
              console.log("[LIBRARY-UPLOAD] AI tagging stored", { spirits: aiUpdate.spirit_tags.length, topic: aiUpdate.topic });
            }
          } catch (e) {
            console.error("[LIBRARY-UPLOAD] AI tagging failed:", e?.message);
          }
        }
      } else {
        console.log("[LIBRARY-UPLOAD] Insufficient text extracted \u2014 skipping AI tagging");
      }
    }
  } catch (e) {
    console.error("[LIBRARY-UPLOAD] FAILED at step: Text extraction", e?.message);
  }
  return Response.json({ success: true, book: row });
}
var config = { path: "/api/admin-library-save" };
export {
  config,
  handler as default
};
