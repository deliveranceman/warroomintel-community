
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/stream-video-token.ts
import { StreamClient } from "@stream-io/node-sdk";
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
};
var JSON_HEADERS = { ...CORS, "Content-Type": "application/json" };
function extractPayload(authHeader) {
  if (!authHeader) return null;
  const token = authHeader.replace(/^Bearer\s+/i, "").trim();
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    return JSON.parse(Buffer.from(parts[1], "base64url").toString());
  } catch {
    return null;
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const payload = extractPayload(req.headers.get("Authorization"));
  if (!payload?.sub) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: JSON_HEADERS });
  }
  const userId = payload.sub;
  const meta = payload?.publicMetadata || payload?.public_metadata || {};
  const firstName = payload.firstName || payload.first_name || meta.first_name || "";
  const lastName = payload.lastName || payload.last_name || meta.last_name || "";
  const name = [firstName, lastName].filter(Boolean).join(" ") || payload.name || "Soldier";
  const { apiKey, apiSecret } = JSON.parse(process.env.STREAM || "{}");
  if (!apiKey || !apiSecret) {
    return new Response(JSON.stringify({ error: "Stream not configured" }), { status: 500, headers: JSON_HEADERS });
  }
  try {
    const client = new StreamClient(apiKey, apiSecret);
    try {
      await client.upsertUsers([{ id: userId, name }]);
    } catch (upsertErr) {
      console.error("[stream-video-token] upsert failed (non-fatal):", upsertErr?.message);
    }
    const token = client.generateUserToken({ user_id: userId, validity_in_seconds: 3600 });
    return new Response(JSON.stringify({ apiKey, token, userId, name }), {
      status: 200,
      headers: JSON_HEADERS
    });
  } catch (err) {
    console.error("[stream-video-token]", err.message);
    return new Response(JSON.stringify({ error: err.message || "Failed to generate token" }), {
      status: 500,
      headers: JSON_HEADERS
    });
  }
}
var config = { path: "/api/stream-video-token" };
export {
  config,
  handler as default
};
