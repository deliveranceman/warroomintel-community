
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/content-suggestions.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function sb() {
  return createClient(supabaseUrl, supabaseServiceKey);
}
async function resolveMinister(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return { isMinister: false, userId: null };
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return { isMinister: false, userId: null };
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return { isMinister: false, userId };
    const data = await res.json();
    return { isMinister: data?.public_metadata?.role === "minister", userId };
  } catch {
    return { isMinister: false, userId: null };
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: HEADERS });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: HEADERS });
  const { isMinister, userId } = await resolveMinister(token);
  if (!isMinister) return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: HEADERS });
  const url = new URL(req.url);
  const client = sb();
  if (req.method === "GET") {
    const statusFilter = url.searchParams.get("status") || null;
    const weekOf = url.searchParams.get("week_of") || null;
    const contentType = url.searchParams.get("content_type") || null;
    let query = client.from("content_suggestions").select("*").order("created_at", { ascending: false }).limit(50);
    if (statusFilter) query = query.eq("status", statusFilter);
    if (weekOf) query = query.eq("week_of", weekOf);
    if (contentType) query = query.eq("content_type", contentType);
    const { data, error } = await query;
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: HEADERS });
    return new Response(JSON.stringify({ suggestions: data || [] }), { status: 200, headers: HEADERS });
  }
  if (req.method === "PATCH") {
    const id = url.searchParams.get("id");
    if (!id) return new Response(JSON.stringify({ error: "id required" }), { status: 400, headers: HEADERS });
    const body = await req.json().catch(() => ({}));
    const { action, scheduled_for, title, full_draft, summary, notes } = body;
    if (!action || !["approve", "reject", "publish"].includes(action)) {
      return new Response(JSON.stringify({ error: "action must be approve | reject | publish" }), { status: 400, headers: HEADERS });
    }
    const { data: suggestion, error: fetchErr } = await client.from("content_suggestions").select("*").eq("id", id).single();
    if (fetchErr || !suggestion) {
      return new Response(JSON.stringify({ error: "Suggestion not found" }), { status: 404, headers: HEADERS });
    }
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const updates = { reviewed_by: userId, reviewed_at: now };
    if (title !== void 0) updates.title = title;
    if (full_draft !== void 0) updates.full_draft = full_draft;
    if (summary !== void 0) updates.summary = summary;
    if (notes !== void 0) updates.notes = notes;
    if (action === "approve") {
      updates.status = "approved";
      if (scheduled_for) updates.scheduled_for = scheduled_for;
    } else if (action === "reject") {
      updates.status = "rejected";
    } else if (action === "publish") {
      updates.status = "published";
      updates.published_at = now;
      const effectiveTitle = title || suggestion.title;
      const effectiveDraft = full_draft || suggestion.full_draft || "";
      const effectiveTier = suggestion.suggested_tier || "watchman";
      if (suggestion.content_type === "daily_brief") {
        const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
        await client.from("daily_devotions").insert({
          date: today,
          title: effectiveTitle,
          devotional_text: effectiveDraft,
          min_tier: effectiveTier,
          published: true,
          created_by: "ai-agent"
        });
      } else if (suggestion.content_type === "weekly_intel") {
        await client.from("intel_posts").insert({
          title: effectiveTitle,
          body: effectiveDraft,
          post_type: "briefing",
          published: true
        });
      }
    }
    const { error: updateErr } = await client.from("content_suggestions").update(updates).eq("id", id);
    if (updateErr) return new Response(JSON.stringify({ error: updateErr.message }), { status: 500, headers: HEADERS });
    return new Response(JSON.stringify({ success: true, action }), { status: 200, headers: HEADERS });
  }
  return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: HEADERS });
}
var config = { path: "/api/content-suggestions" };
export {
  config,
  handler as default
};
