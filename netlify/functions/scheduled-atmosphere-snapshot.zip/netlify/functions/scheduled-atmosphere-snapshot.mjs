
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/scheduled-atmosphere-snapshot.ts
var { url: supabaseUrl, serviceRoleKey } = JSON.parse(process.env.SUPABASE || "{}");
var SB = (p) => `${supabaseUrl}/rest/v1${p}`;
var sbH = {
  apikey: serviceRoleKey,
  Authorization: `Bearer ${serviceRoleKey}`,
  "Content-Type": "application/json",
  Prefer: "return=representation"
};
async function sbFetch(path, method = "GET", body) {
  const res = await fetch(SB(path), {
    method,
    headers: sbH,
    body: body !== void 0 ? JSON.stringify(body) : void 0
  });
  let data;
  try {
    data = await res.json();
  } catch {
    data = [];
  }
  return { status: res.status, data };
}
async function handler() {
  const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  console.log("[scheduled-atmosphere] Running snapshot for", today);
  const { data: rows } = await sbFetch(
    `/atmosphere_checkins?date=eq.${today}&is_public=eq.true&select=category,status`
  );
  const arr = Array.isArray(rows) ? rows : [];
  const tally = { green: 0, amber: 0, purple: 0 };
  const statusCounts = {};
  for (const r of arr) {
    tally[r.category] = (tally[r.category] || 0) + 1;
    statusCounts[r.status] = (statusCounts[r.status] || 0) + 1;
  }
  const topStatuses = Object.entries(statusCounts).sort(([, a], [, b]) => b - a).slice(0, 5).map(([s2, c]) => ({ status: s2, count: c }));
  const dominantCat = Object.entries(tally).sort(([, a], [, b]) => b - a)[0]?.[0] || null;
  const dominantStatus = topStatuses[0]?.status || null;
  const row = {
    date: today,
    total_checkins: arr.length,
    green_count: tally.green,
    amber_count: tally.amber,
    purple_count: tally.purple,
    dominant_status: dominantStatus,
    dominant_category: dominantCat,
    top_statuses: topStatuses,
    snapshot_at: (/* @__PURE__ */ new Date()).toISOString()
  };
  const { status: s } = await sbFetch("/atmosphere_snapshots", "POST", row);
  if (s >= 400) {
    await sbFetch(`/atmosphere_snapshots?date=eq.${today}`, "PATCH", row);
  }
  console.log("[scheduled-atmosphere] Snapshot saved:", JSON.stringify(row));
}
var config = {
  schedule: "0 5 * * *"
};
export {
  config,
  handler as default
};
