
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/stream-webhook.mts
import crypto from "crypto";
import webpush2 from "web-push";
import { createClient } from "@supabase/supabase-js";

// netlify/functions/_shared/sendWebPush.ts
import webpush from "web-push";
function getVapid() {
  const json = JSON.parse(process.env.VAPID || "{}");
  const publicKey = process.env.VAPID_PUBLIC_KEY || json.publicKey || "";
  const privateKey = process.env.VAPID_PRIVATE_KEY || json.privateKey || "";
  const email = json.email || "exorcist@warroomintel.com";
  const contact = email.startsWith("mailto:") ? email : `mailto:${email}`;
  return { publicKey, privateKey, contact };
}
async function sendWebPushToUser(userId, title, body, extraData) {
  const { url: supabaseUrl2, serviceRoleKey: serviceRoleKey2 } = JSON.parse(process.env.SUPABASE || "{}");
  const sbH = { apikey: serviceRoleKey2, Authorization: `Bearer ${serviceRoleKey2}` };
  const { publicKey, privateKey, contact } = getVapid();
  webpush.setVapidDetails(contact, publicKey, privateKey);
  const subRes = await fetch(
    `${supabaseUrl2}/rest/v1/push_subscriptions?user_id=eq.${encodeURIComponent(userId)}&select=id,user_id,endpoint,subscription`,
    { headers: sbH }
  );
  const rows = await subRes.json().catch(() => []);
  console.log(`[push] user=${userId} subscriptions=${Array.isArray(rows) ? rows.length : 0}`);
  if (!Array.isArray(rows) || rows.length === 0) {
    return { sent: 0, failed: 0, total: 0, errors: [] };
  }
  const payload = JSON.stringify({
    title,
    body,
    url: "/community",
    icon: "/icons/icon-192.png",
    badge: "/icons/badge-72.png",
    ...extraData ? { data: extraData } : {}
  });
  let sent = 0, failed = 0;
  const errors = [];
  for (const row of rows) {
    let pushSub;
    try {
      pushSub = typeof row.subscription === "string" ? JSON.parse(row.subscription) : row.subscription;
    } catch {
      failed++;
      errors.push({ id: row.id, statusCode: null, message: "Invalid subscription JSON" });
      continue;
    }
    try {
      await webpush.sendNotification(pushSub, payload, { TTL: 86400 });
      sent++;
      console.log(`[push] sent user=${userId} sub=${row.id}`);
    } catch (err) {
      failed++;
      const sc = err.statusCode ?? 0;
      errors.push({ id: row.id, statusCode: sc, message: err.body || err.message || String(err) });
      console.error(`[push] failed user=${userId} sub=${row.id} status=${sc} body=${err.body || err.message}`);
      if (sc === 410 || sc === 404 || sc === 400) {
        await fetch(
          `${supabaseUrl2}/rest/v1/push_subscriptions?id=eq.${encodeURIComponent(row.id)}`,
          { method: "DELETE", headers: sbH }
        ).catch(() => {
        });
        console.log(`[push] deleted stale sub ${row.id} (status=${sc})`);
      }
    }
  }
  return { sent, failed, total: rows.length, errors };
}

// netlify/functions/stream-webhook.mts
var { apiKey: streamApiKey, apiSecret } = JSON.parse(process.env.STREAM || "{}");
var { publicKey: vapidPublicKey, privateKey: vapidPrivateKey, email: vapidEmail } = JSON.parse(process.env.VAPID || "{}");
var { url: supabaseUrl, serviceRoleKey } = JSON.parse(process.env.SUPABASE || "{}");
var ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY ?? "";
var HEADERS = { "Content-Type": "application/json" };
var NOTIFIED_CHANNELS = /* @__PURE__ */ new Set(["war-room-general", "commanders-room", "generals-table"]);
var SOL_BOT_ID = "sol-bot";
webpush2.setVapidDetails(`mailto:${vapidEmail}`, vapidPublicKey, vapidPrivateKey);
function streamJWT(payload) {
  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const sig = crypto.createHmac("sha256", apiSecret ?? "").update(`${header}.${body}`).digest("base64url");
  return `${header}.${body}.${sig}`;
}
var serverToken = () => streamJWT({ server: true });
var userToken = (userId) => streamJWT({ user_id: userId });
function streamHeaders(token) {
  return { "Content-Type": "application/json", Authorization: token, "stream-auth-type": "jwt" };
}
async function ensureSolBot() {
  const url = `https://chat.stream-io-api.com/users?api_key=${streamApiKey}`;
  const res = await fetch(url, {
    method: "POST",
    headers: streamHeaders(serverToken()),
    body: JSON.stringify({ users: { [SOL_BOT_ID]: { id: SOL_BOT_ID, name: "SOL", role: "user" } } })
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`ensureSolBot failed ${res.status}: ${text}`);
  }
}
async function postStreamMessage(channelType, channelId, text) {
  const url = `https://chat.stream-io-api.com/channels/${channelType}/${channelId}/message?api_key=${streamApiKey}`;
  const res = await fetch(url, {
    method: "POST",
    headers: streamHeaders(userToken(SOL_BOT_ID)),
    body: JSON.stringify({ message: { text } })
  });
  if (!res.ok) {
    const errText = await res.text();
    if (res.status === 400 && errText.includes("user")) {
      await ensureSolBot();
      const retry = await fetch(url, {
        method: "POST",
        headers: streamHeaders(userToken(SOL_BOT_ID)),
        body: JSON.stringify({ message: { text } })
      });
      if (!retry.ok) {
        const retryText = await retry.text();
        throw new Error(`postStreamMessage retry failed ${retry.status}: ${retryText}`);
      }
      return;
    }
    throw new Error(`postStreamMessage failed ${res.status}: ${errText}`);
  }
}
async function callAnthropic(systemPrompt, userMessage, maxTokens = 400) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-5",
      max_tokens: maxTokens,
      system: systemPrompt,
      messages: [{ role: "user", content: userMessage }]
    })
  });
  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Anthropic error ${res.status}: ${err}`);
  }
  const data = await res.json();
  const reply = data.content?.find((b) => b.type === "text")?.text ?? "";
  if (!reply) throw new Error("Empty Anthropic response");
  return reply;
}
var SOL_SYSTEM_BRIEF = "You are SOL, the AI intelligence agent of War Room Intel \u2014 a spiritual warfare ministry platform. You are brief, direct, and speak with authority. You help deliverance ministers identify spirits, understand manifestations, and pray with precision. Keep responses under 200 words.";
async function solMentionReply(messageText, channelType, channelId) {
  const reply = await callAnthropic(SOL_SYSTEM_BRIEF, messageText, 300);
  await postStreamMessage(channelType, channelId, reply);
  console.log(`[stream-webhook] SOL mention replied channel=${channelId}`);
}
async function solDMReply(messageText, channelId, senderId) {
  const sb = createClient(supabaseUrl, serviceRoleKey);
  const { data: ctxRows } = await sb.from("ministry_context").select("context_text").limit(1);
  const ministryContext = ctxRows?.[0]?.context_text ?? "";
  const systemPrompt = "You are SOL, the intelligence agent of War Room Intel \u2014 a spiritual warfare ministry platform built by Pastor Justin Payne of Staffordtown Church, Copperhill TN. You assist deliverance ministers with identifying spirits, understanding manifestations, legal ground, and strategic prayer. Be concise, authoritative, and spiritually grounded. Keep responses under 300 words. Never break character." + (ministryContext ? `

${ministryContext}` : "");
  const reply = await callAnthropic(systemPrompt, messageText, 400);
  await postStreamMessage("messaging", channelId, reply);
  await sb.from("ai_search_history").insert({ user_id: senderId, tool: "sol-dm", query: messageText.slice(0, 500), response: reply.slice(0, 1e3), context: {} }).catch((err) => console.error("[stream-webhook] ai_search_history insert error:", err));
  console.log(`[stream-webhook] SOL DM replied channel=${channelId} user=${senderId}`);
}
async function sendDMPush(channelId, senderId, senderName, messageText) {
  const sbH = { apikey: serviceRoleKey, Authorization: `Bearer ${serviceRoleKey}` };
  const dmRes = await fetch(
    `${supabaseUrl}/rest/v1/dm_requests?channel_id=eq.${channelId}&status=eq.accepted&select=requester_id,recipient_id`,
    { headers: sbH }
  );
  const dms = await dmRes.json().catch(() => []);
  console.log("[webhook] dm_requests found:", Array.isArray(dms) ? dms.length : 0, "for channel:", channelId);
  const dm = Array.isArray(dms) ? dms[0] : null;
  if (!dm) {
    console.log("[webhook] no accepted dm_request for channel:", channelId);
    return;
  }
  const recipientId = dm.requester_id === senderId ? dm.recipient_id : dm.requester_id;
  console.log("[webhook] sending push to recipientId:", recipientId);
  const result = await sendWebPushToUser(
    recipientId,
    `\u{1F4AC} ${senderName}`,
    messageText.slice(0, 100),
    { type: "dm_message", channelId, section: "dms" }
  );
  console.log("[webhook] DM push result:", JSON.stringify(result));
}
async function sendFireTeamPush(channelId, senderUserId, senderName, messageText) {
  const sbH = { apikey: serviceRoleKey, Authorization: `Bearer ${serviceRoleKey}` };
  const ftTeamRes = await fetch(
    `${supabaseUrl}/rest/v1/fire_teams?stream_channel_id=eq.${encodeURIComponent(channelId)}&select=id`,
    { headers: sbH }
  );
  const teams = await ftTeamRes.json().catch(() => []);
  const teamId = Array.isArray(teams) ? teams[0]?.id : null;
  if (!teamId) {
    console.log("[webhook] no fire_team for channel:", channelId);
    return;
  }
  const membersRes = await fetch(
    `${supabaseUrl}/rest/v1/fire_team_members?fire_team_id=eq.${encodeURIComponent(teamId)}&status=eq.active&user_id=neq.${encodeURIComponent(senderUserId)}&select=user_id`,
    { headers: sbH }
  );
  const members = await membersRes.json().catch(() => []);
  console.log("[webhook] fire team push teamId:", teamId, "recipients:", Array.isArray(members) ? members.length : 0);
  await Promise.allSettled(
    (Array.isArray(members) ? members : []).map(
      (member) => sendWebPushToUser(
        member.user_id,
        `\u2694 ${senderName}`,
        messageText.slice(0, 100),
        { type: "fire_team_message", channelId, section: "dms" }
      ).catch(() => {
      })
    )
  );
  console.log("[webhook] fire team push done channelId:", channelId);
}
async function handler(req) {
  console.log("[webhook] received:", req.method, req.url);
  console.log("[webhook] apiSecret set:", !!apiSecret, "length:", (apiSecret ?? "").length);
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: HEADERS });
  }
  const rawBody = await req.text();
  const signature = req.headers.get("x-signature") ?? "";
  console.log("[webhook] x-signature header present:", !!signature, "length:", signature.length);
  const expected = crypto.createHmac("sha256", apiSecret ?? "").update(rawBody).digest("hex");
  const sigValid = expected === signature;
  console.log("[webhook] signature valid:", sigValid);
  if (!sigValid) {
    console.warn("[webhook] SIGNATURE MISMATCH \u2014 continuing anyway for debug");
  }
  let body;
  try {
    body = JSON.parse(rawBody);
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: HEADERS });
  }
  console.log("[webhook] event type:", body.type ?? "unknown", "| keys:", Object.keys(body).join(","));
  const { type } = body;
  if (type === "message.new") {
    const channelId = body.channel_id ?? "";
    const channelType = body.channel_type ?? "messaging";
    const senderUserId = body.user?.id ?? "";
    const messageText = body.message?.text ?? "";
    console.log("[webhook] message.new channelId:", channelId, "type:", channelType, "sender:", senderUserId);
    if (senderUserId === SOL_BOT_ID) {
      return new Response(JSON.stringify({ ok: true }), { status: 200, headers: HEADERS });
    }
    if (channelType === "messaging") {
      const senderName = body.user?.name || senderUserId;
      if (channelId.startsWith("ft-")) {
        await sendFireTeamPush(channelId, senderUserId, senderName, messageText).catch(
          (err) => console.error("[stream-webhook] sendFireTeamPush error:", err)
        );
        return new Response(JSON.stringify({ ok: true }), { status: 200, headers: HEADERS });
      }
      await sendDMPush(channelId, senderUserId, senderName, messageText).catch(
        (err) => console.error("[stream-webhook] sendDMPush error:", err)
      );
      if (channelId === "sol" || channelId.startsWith("sol-")) {
        solDMReply(messageText, channelId, senderUserId).catch(
          (err) => console.error("[stream-webhook] solDMReply error:", err)
        );
      }
      return new Response(JSON.stringify({ ok: true }), { status: 200, headers: HEADERS });
    }
    if (channelId === "war-room-general" && /@sol\b/i.test(messageText)) {
      solMentionReply(messageText, channelType, channelId).catch(
        (err) => console.error("[stream-webhook] solMentionReply error:", err)
      );
    }
    if (NOTIFIED_CHANNELS.has(channelId)) {
      try {
        const sb = createClient(supabaseUrl, serviceRoleKey);
        const { data: subs, error } = await sb.from("push_subscriptions").select("*").neq("user_id", senderUserId);
        if (error) {
          console.error("[stream-webhook] supabase error:", error.message);
        } else {
          const payload = JSON.stringify({
            title: "War Room Intel",
            body: messageText.length > 100 ? messageText.slice(0, 100) + "\u2026" : messageText
          });
          let sent = 0, failed = 0;
          await Promise.allSettled(
            (subs ?? []).map(async (row) => {
              try {
                await webpush2.sendNotification(row.subscription, payload);
                sent++;
              } catch (err) {
                failed++;
                if (err.statusCode === 410) {
                  await sb.from("push_subscriptions").delete().eq("id", row.id).catch(() => {
                  });
                }
              }
            })
          );
          console.log(`[stream-webhook] push channel=${channelId} sent=${sent} failed=${failed}`);
        }
      } catch (err) {
        console.error("[stream-webhook] push error:", err);
      }
    }
  } else if (type === "user.created") {
    console.log("[stream-webhook] user.created", JSON.stringify(body));
  } else {
    console.log(`[stream-webhook] unhandled type: ${type}`);
  }
  return new Response(JSON.stringify({ ok: true }), { status: 200, headers: HEADERS });
}
var config = { path: "/api/stream-webhook" };
export {
  config,
  handler as default
};
