
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/taxonomy-spirits.ts
var { token: airtableToken } = JSON.parse(process.env.AIRTABLE || "{}");
var AIRTABLE_TOKEN = airtableToken;
var BASE_ID = "appVXEj2DLPBTJTtD";
var TABLE_ID = "tblcP4lgVykzOhLi4";
var NAME_FIELD = "\u2694 WAR ROOM COMMUNITY \u2014 MASTER DEMON DATABASE";
var headers = { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" };
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { status: 200, headers });
  if (req.method !== "GET") return new Response(JSON.stringify({ error: "GET required" }), { status: 405, headers });
  try {
    const records = [];
    let offset;
    do {
      const url = new URL(`https://api.airtable.com/v0/${BASE_ID}/${TABLE_ID}`);
      url.searchParams.set("pageSize", "100");
      for (const f of [NAME_FIELD, "Kingdom", "Sub-Kingdom", "Biblical Rank"]) {
        url.searchParams.append("fields[]", f);
      }
      if (offset) url.searchParams.set("offset", offset);
      const res = await fetch(url.toString(), {
        headers: { Authorization: `Bearer ${AIRTABLE_TOKEN}` }
      });
      if (!res.ok) throw new Error(`Airtable ${res.status}`);
      const data = await res.json();
      records.push(...data.records || []);
      offset = data.offset;
    } while (offset);
    const spirits = records.map((r) => ({
      recordId: r.id,
      name: r.fields[NAME_FIELD] || "",
      kingdom: r.fields["Kingdom"] || "",
      subKingdom: r.fields["Sub-Kingdom"] || "",
      biblicalRank: r.fields["Biblical Rank"] || ""
    })).filter((s) => s.name && s.name !== "Primary Name");
    return new Response(JSON.stringify({ spirits, total: spirits.length }), { status: 200, headers });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers });
  }
}
var config = { path: "/api/taxonomy-spirits" };
export {
  config,
  handler as default
};
