
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/stream-token.ts
import { StreamClient } from "@stream-io/node-sdk";
var stream_token_default = async (req, _context) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    });
  }
  const stream = JSON.parse(process.env.STREAM || "{}");
  const streamApiKey = stream.apiKey;
  const streamApiSecret = stream.apiSecret;
  try {
    const { userId: rawUserId, userName, userImage } = await req.json();
    if (!rawUserId) {
      return new Response(JSON.stringify({ error: "userId required" }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }
    const userId = rawUserId.replace(/[^a-zA-Z0-9_-]/g, "_");
    const apiKey = streamApiKey;
    const apiSecret = streamApiSecret;
    if (!apiKey || !apiSecret) {
      return new Response(JSON.stringify({ error: "Stream not configured" }), {
        status: 500,
        headers: { "Content-Type": "application/json" }
      });
    }
    const client = new StreamClient(apiKey, apiSecret);
    await client.upsertUsers([{
      id: userId,
      name: (userName || "").trim() || "Warrior",
      image: userImage || "",
      role: "user"
    }]);
    const prayerChannel = client.chat.channel("messaging", "prayer-wall-requests");
    await prayerChannel.getOrCreate({
      data: {
        created_by_id: userId
      }
    });
    await prayerChannel.update({ add_members: [{ user_id: userId }] });
    const generalChannel = client.chat.channel("messaging", "war-room-general");
    await generalChannel.getOrCreate({
      data: {
        created_by_id: userId
      }
    });
    await generalChannel.update({ add_members: [{ user_id: userId }] });
    const token = client.createToken(userId, Math.floor(Date.now() / 1e3) + 3600);
    return new Response(JSON.stringify({ token, apiKey, userId }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch (err) {
    console.error("stream-token error:", err);
    return new Response(JSON.stringify({ error: err.message || "Stream error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
};
var config = { path: "/api/stream-token" };
export {
  config,
  stream_token_default as default
};
