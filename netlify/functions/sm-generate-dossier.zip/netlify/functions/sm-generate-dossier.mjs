
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/sm-generate-dossier.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function supabase() {
  return createClient(supabaseUrl, supabaseServiceKey);
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers });
  try {
    const { regionId, assessmentId } = await req.json();
    if (!regionId || !assessmentId) {
      return new Response(JSON.stringify({ error: "regionId and assessmentId required" }), { status: 400, headers });
    }
    const sb = supabase();
    const { data: region } = await sb.from("sm_regions").select("*").eq("id", regionId).single();
    const { data: assessment } = await sb.from("sm_assessments").select("*").eq("id", assessmentId).single();
    const { data: spirits } = await sb.from("sm_region_spirits").select("*").eq("region_id", regionId).order("tier_level", { ascending: false });
    const { data: research } = await sb.from("sm_research_cache").select("category, summary").eq("region_id", regionId);
    if (!region || !assessment) {
      return new Response(JSON.stringify({ error: "Region or assessment not found" }), { status: 404, headers });
    }
    const researchContext = research?.map((r) => `[${r.category?.toUpperCase()}]
${r.summary}`).join("\n\n") || "";
    const spiritsList = spirits?.map(
      (s) => `- ${s.spirit_name} (Tier ${s.tier_level}) \u2014 ${s.confidence} \u2014 ${s.legal_rights || "No legal rights documented"}`
    ).join("\n") || "";
    const assessmentContext = `
REGION: ${region.name}
Population: ${assessment.s1_population || region.population || "Unknown"}
Tier: ${region.tier}

SECTION 1 \u2014 REGIONAL IDENTITY:
${assessment.s1_description || ""}
Church Unity: ${assessment.s1_church_unity || "Unknown"}

SECTION 2 \u2014 HISTORICAL:
Ancient Peoples: ${assessment.s2_ancient_peoples || ""}
Bloodshed Events: ${assessment.s2_bloodshed_events || ""}
Masonic History: ${assessment.s2_masonic_history || ""}
Founding Covenants: ${assessment.s2_founding_covenants || ""}
Environmental Devastation: ${assessment.s2_environmental_devastation || ""}
Broken Treaties: ${assessment.s2_broken_treaties || ""}
False Religion History: ${assessment.s2_false_religion_history || ""}
Land Dedications: ${assessment.s2_land_dedications || ""}

SECTION 3 \u2014 CURRENT CONDITIONS:
Addiction Patterns: ${assessment.s3_addiction_patterns || ""}
Poverty Indicators: ${assessment.s3_poverty_indicators || ""}
Crime Patterns: ${assessment.s3_crime_patterns || ""}
Occult Activity: ${assessment.s3_occult_activity || ""}
Dominant Idols: ${assessment.s3_dominant_idols || ""}
Church Division: ${assessment.s3_church_division_notes || ""}

SECTION 4 \u2014 DISCERNMENT:
Prophetic Words: ${assessment.s4_prophetic_words || ""}
Field Discernment: ${assessment.s4_field_discernment || ""}
Dreams/Visions: ${assessment.s4_dreams_visions || ""}
Physical Manifestations: ${assessment.s4_physical_manifestations || ""}
Spiritual Atmosphere: ${assessment.s4_spiritual_atmosphere || ""}

SECTION 6 \u2014 LEGAL GROUND:
Bloodshed: ${assessment.s6_bloodshed_confirmed ? `CONFIRMED \u2014 ${assessment.s6_bloodshed_details}` : "Not confirmed"}
Idolatry: ${assessment.s6_idolatry_confirmed ? `CONFIRMED \u2014 ${assessment.s6_idolatry_details}` : "Not confirmed"}
Broken Covenants: ${assessment.s6_broken_covenants_confirmed ? `CONFIRMED \u2014 ${assessment.s6_broken_covenants_details}` : "Not confirmed"}
Sexual Perversion: ${assessment.s6_sexual_perversion_confirmed ? `CONFIRMED \u2014 ${assessment.s6_sexual_perversion_details}` : "Not confirmed"}
Additional: ${assessment.s6_additional_legal_ground || ""}

SECTION 7 \u2014 IDENTIFIED PRINCIPALITIES:
${spiritsList || "None documented"}

SECTION 8 \u2014 REDEMPTIVE GIFT:
Redemptive Gift: ${assessment.s8_redemptive_gift || region.redemptive_gift || "Unknown"}
Gift Perversion: ${assessment.s8_gift_perversion || ""}
Signs of Hope: ${assessment.s8_signs_of_hope || ""}
God's Original Design: ${assessment.s8_gods_original_design || ""}
Scripture Promise: ${assessment.s8_scripture_promise || ""}

SECTION 9 \u2014 OPERATION DETAILS:
Apostolic Covering: ${assessment.s9_apostolic_covering || ""}
Team Size: ${assessment.s9_team_size || ""}
Team Composition: ${assessment.s9_team_composition || ""}
Operation Date: ${assessment.s9_operation_date || ""}
Personal Deliverance Confirmed: ${assessment.s9_personal_deliverance_confirmed ? "YES" : "NO"}
Prayer Cover Confirmed: ${assessment.s9_prayer_cover_confirmed ? "YES" : "NO"}

RESEARCH INTELLIGENCE:
${researchContext}
`;
    const systemPrompt = `You are a War Room Intel analyst generating a classified Field Intelligence Dossier for a spiritual mapping operation. You combine assessment data, field discernment, and research intelligence into a comprehensive, classified document.

Output ONLY valid JSON with this exact structure:
{
  "title": "string \u2014 formal title of the dossier",
  "classification": "string \u2014 e.g. CLASSIFIED \u2014 COMMANDER+ CLEARANCE REQUIRED",
  "operation_name": "string \u2014 code name for this operation (e.g. Operation: Copper Veil)",
  "executive_summary": "string \u2014 2-3 paragraph overview of the spiritual condition of the region",
  "sections": [
    {
      "heading": "string \u2014 section title",
      "content": "string \u2014 detailed analysis content"
    }
  ],
  "declarations": "string \u2014 prophetic declarations and intercession targets based on the data",
  "prepared_by": "War Room Intel \u2014 Spiritual Mapping Division",
  "date": "string \u2014 current date"
}

The sections array must include: Territorial Assessment, Historical Legal Ground, Current Conditions, Identified Principalities, Redemptive Design, Operational Recommendations.

Write in classified intelligence report style. Be specific, tactical, and spiritually informed.`;
    const apiRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-5",
        max_tokens: 4e3,
        system: systemPrompt,
        messages: [{ role: "user", content: assessmentContext }]
      })
    });
    if (!apiRes.ok) {
      const errText = await apiRes.text();
      console.error("Claude API error:", errText);
      return new Response(JSON.stringify({ error: "Dossier generation failed \u2014 AI error" }), { status: 500, headers });
    }
    const data = await apiRes.json();
    const rawText = data.content?.[0]?.text || "";
    const jsonMatch = rawText.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      return new Response(JSON.stringify({ error: "Failed to parse dossier JSON from AI response" }), { status: 500, headers });
    }
    const dossier = JSON.parse(jsonMatch[0]);
    await sb.from("sm_assessments").update({
      generated_at: (/* @__PURE__ */ new Date()).toISOString(),
      generation_count: (assessment.generation_count || 0) + 1,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", assessmentId);
    return new Response(JSON.stringify({ dossier }), { status: 200, headers });
  } catch (err) {
    console.error("sm-generate-dossier error:", err);
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers });
  }
}
var config = { path: "/api/sm-generate-dossier" };
export {
  config,
  handler as default
};
