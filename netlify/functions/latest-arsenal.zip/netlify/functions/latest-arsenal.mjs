
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/latest-arsenal.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function sb() {
  return createClient(supabaseUrl, supabaseServiceKey);
}
async function handler(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: HEADERS });
  }
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: HEADERS });
  }
  let userId;
  try {
    const parts = token.split(".");
    if (parts.length !== 3) throw new Error("Invalid JWT");
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    userId = payload.sub;
    if (!userId) throw new Error("No sub in JWT");
  } catch {
    return new Response(JSON.stringify({ error: "Unauthorized \u2014 invalid token" }), { status: 401, headers: HEADERS });
  }
  const supabase = sb();
  const { data, error } = await supabase.from("resources").select("id, title, topic, created_at").neq("topic", "ministry-library").order("created_at", { ascending: false }).limit(3);
  if (error) {
    return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: HEADERS });
  }
  return new Response(JSON.stringify({ resources: data ?? [] }), { status: 200, headers: HEADERS });
}
var config = { path: "/api/latest-arsenal" };
export {
  config,
  handler as default
};
