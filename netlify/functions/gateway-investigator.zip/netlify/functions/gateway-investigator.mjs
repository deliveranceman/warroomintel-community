
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/getMinistryContext.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var _cached = null;
var _cacheExpiry = 0;
async function getMinistryContext() {
  if (_cached !== null && Date.now() < _cacheExpiry) return _cached;
  try {
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { data } = await supabase.from("ministry_context").select("context_text").eq("is_active", true).single();
    const text = data?.context_text || "";
    _cached = text;
    _cacheExpiry = Date.now() + 6e4;
    return text;
  } catch {
    return "";
  }
}

// netlify/lib/ai-rate-limit.ts
import { createClient as createClient2 } from "@supabase/supabase-js";
var { url: supabaseUrl2, serviceRoleKey: supabaseServiceKey2 } = JSON.parse(process.env.SUPABASE || "{}");
async function checkAndIncrementUsage(_userId, _tier, _feature) {
  return { allowed: true, remaining: 999, limit: 999, current: 0 };
}
var FEATURE_LABELS = {
  ask_dake: "Ask Dake",
  ai_assistant: "AI Assistant",
  bible_ask: "Bible Study AI",
  symptom_investigator: "Symptom Investigator",
  gateway: "Gateway Investigator",
  dream: "Dream Interpreter",
  document: "Document Creator",
  session_ai: "Session AI",
  assessment: "Assessment Strategy"
};
function getUpgradeMessage(tier, feature) {
  const tiers = {
    watchman: "Soldier",
    free: "Soldier",
    soldier: "Commander",
    charter_soldier: "Commander",
    commander: "General",
    charter_commander: "General"
  };
  const nextTier = tiers[tier];
  const label = FEATURE_LABELS[feature] || feature;
  if (!nextTier) return `You have reached your daily limit for ${label}.`;
  return `Daily limit reached for ${label}. Upgrade to ${nextTier} for more.`;
}

// netlify/lib/clean-ai-output.ts
function cleanAIOutput(text) {
  return text.replace(/\s—\s/g, ", ").replace(/—/g, " - ").replace(/\s–\s/g, ", ").replace(/\bIn conclusion,?\s*/gi, "").replace(/\bTo summarize,?\s*/gi, "").replace(/\bIt is worth noting that\s*/gi, "").replace(/\bIt is important to note that\s*/gi, "").replace(/\bNotably,?\s*/gi, "").replace(/\bFurthermore,?\s*/gi, "").replace(/\bMoreover,?\s*/gi, "").replace(/\bAdditionally,?\s*/gi, "").replace(/\bIn other words,?\s*/gi, "").replace(/\bAs previously mentioned,?\s*/gi, "").replace(/\bAs we can see,?\s*/gi, "").replace(/\bIt goes without saying\s*/gi, "").replace(/\bNeedless to say,?\s*/gi, "").replace(/\bAt the end of the day,?\s*/gi, "").replace(/\bWith that said,?\s*/gi, "").replace(/\bThat being said,?\s*/gi, "").replace(/\bHaving said that,?\s*/gi, "").replace(/  +/g, " ").replace(/\s,/g, ",").trim();
}

// netlify/functions/gateway-investigator.ts
var { token: airtableToken } = JSON.parse(process.env.AIRTABLE || "{}");
var { url: _sbUrl, serviceRoleKey: _sbKey } = JSON.parse(process.env.SUPABASE || "{}");
var AIRTABLE_TOKEN = airtableToken;
var BASE_ID = "appVXEj2DLPBTJTtD";
var TABLE_ID = "tblcP4lgVykzOhLi4";
var NAME_FIELD = "\u2694 WAR ROOM COMMUNITY \u2014 MASTER DEMON DATABASE";
var headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
async function resolveUser(token) {
  try {
    if (!token || token.split(".").length !== 3) return { ok: false, tier: "", userId: "" };
    const payload = JSON.parse(Buffer.from(token.split(".")[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return { ok: false, tier: "", userId: "" };
    const jwtMeta = payload?.publicMetadata || payload?.public_metadata || {};
    let tier = jwtMeta.tier || "watchman";
    let role = jwtMeta.role || "";
    const tierLvl = (t) => ({ free: 0, watchman: 0, soldier: 1, commander: 2, general: 3 })[t?.toLowerCase()] ?? 0;
    try {
      const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
        headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
      });
      if (res.ok) {
        const data = await res.json();
        role = data?.public_metadata?.role || role;
        tier = data?.public_metadata?.tier || tier;
      }
    } catch {
    }
    const hasAccess = role === "minister" || tierLvl(tier) >= 1;
    return { ok: hasAccess, tier, userId };
  } catch {
    return { ok: false, tier: "", userId: "" };
  }
}
async function fetchSpiritContext(spiritName) {
  try {
    const url = new URL(`https://api.airtable.com/v0/${BASE_ID}/${TABLE_ID}`);
    url.searchParams.set("maxRecords", "1");
    url.searchParams.set("filterByFormula", `LOWER({${NAME_FIELD}}) = "${spiritName.toLowerCase()}"`);
    for (const f2 of [NAME_FIELD, "Description", "Manifestiation", "Cultural Presence", "Session Trigger Questions", "Kingdom", "Sub-Kingdom", "Biblical Rank"]) {
      url.searchParams.append("fields[]", f2);
    }
    const res = await fetch(url.toString(), {
      headers: { Authorization: `Bearer ${AIRTABLE_TOKEN}` },
      signal: AbortSignal.timeout(4e3)
    });
    if (!res.ok) return "";
    const data = await res.json();
    const rec = data.records?.[0];
    if (!rec) return "";
    const f = rec.fields || {};
    const parts = [];
    if (f["Description"]) parts.push(`Description: ${String(f["Description"]).slice(0, 300)}`);
    if (f["Manifestiation"]) parts.push(`Manifestations: ${String(f["Manifestiation"]).slice(0, 200)}`);
    if (f["Kingdom"]) parts.push(`Kingdom: ${f["Kingdom"]}`);
    if (f["Biblical Rank"]) parts.push(`Biblical Rank: ${f["Biblical Rank"]}`);
    if (f["Sub-Kingdom"]) parts.push(`Sub-Kingdom: ${f["Sub-Kingdom"]}`);
    if (Array.isArray(f["Cultural Presence"]) && f["Cultural Presence"].length) {
      parts.push(`Known Cultural Presence: ${f["Cultural Presence"].join(", ")}`);
    }
    if (f["Session Trigger Questions"]) {
      parts.push(`Existing Trigger Questions:
${String(f["Session Trigger Questions"]).slice(0, 400)}`);
    }
    return parts.join("\n");
  } catch {
    return "";
  }
}
async function callClaude(spiritName, dbContext, personContext) {
  const subject = spiritName || personContext.slice(0, 60) || "General Analysis";
  const systemPrompt = `You are a spiritual warfare intelligence system specializing in demonic gateway analysis for deliverance ministers.
You MUST respond with ONLY a valid JSON object.
Do NOT include any text before or after the JSON.
Do NOT use markdown code fences.
Start your response with { and end with }.`;
  const userPrompt = `Analyze the demonic gateways and entry points for this case.
${spiritName ? `Spirit/demon: ${spiritName}` : ""}
${dbContext ? `Database intel on this spirit:
${dbContext}` : ""}
${personContext ? `Cultural exposure or session context: ${personContext}` : ""}

Return this exact JSON structure:
{
  "spirit": "${subject}",
  "summary": "2-3 sentence executive summary of the gateway profile for a deliverance minister",
  "sections": [
    {
      "title": "Primary Entry Points",
      "items": ["specific entry point 1", "specific entry point 2", "specific entry point 3"]
    },
    {
      "title": "Legal Grounds",
      "items": ["legal ground 1 \u2014 sin, trauma, vow, or ancestral tie", "legal ground 2"]
    },
    {
      "title": "Generational Patterns",
      "items": ["family pattern 1", "family pattern 2"]
    },
    {
      "title": "Cultural and Exposure Gateways",
      "items": ["specific media/music/game/book title and explanation", "specific subculture or practice"]
    },
    {
      "title": "Session Questions",
      "items": ["Have you ever...? (specific intake question)", "Did you or a family member...? (specific question)", "Were you exposed to...? (specific question)", "Have you participated in...?", "Did you experience...?"]
    },
    {
      "title": "Recommended Deliverance Sequence",
      "items": ["Step 1: confess and renounce...", "Step 2: break legal ground of...", "Step 3: command the spirit of... to go"]
    }
  ]
}

Rules:
- Each section must have 3-6 specific items \u2014 no vague generalities
- Name actual titles, artists, practices, and communities by name
- Session questions must reference specific things the person may have been exposed to
- Return ONLY the JSON. Nothing else.`;
  const ministryContext = await getMinistryContext();
  const effectiveSystem = ministryContext ? `${ministryContext}

---

${systemPrompt}` : systemPrompt;
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 2e3,
      system: effectiveSystem,
      messages: [{ role: "user", content: userPrompt }]
    }),
    signal: AbortSignal.timeout(25e3)
  });
  if (!res.ok) throw new Error(`Claude error ${res.status}`);
  const data = await res.json();
  const rawText = cleanAIOutput((data.content?.[0]?.text || "").trim());
  console.log("[GATEWAY] Raw Claude response (first 1000 chars):");
  console.log(rawText.slice(0, 1e3));
  console.log("[GATEWAY] Response length:", rawText.length);
  let result = null;
  try {
    result = JSON.parse(rawText);
    console.log("[GATEWAY] Parse strategy 1 succeeded (direct)");
  } catch {
  }
  if (!result) {
    try {
      const stripped = rawText.replace(/^```json\s*/im, "").replace(/^```\s*/im, "").replace(/```\s*$/im, "").trim();
      result = JSON.parse(stripped);
      console.log("[GATEWAY] Parse strategy 2 succeeded (fence strip)");
    } catch {
    }
  }
  if (!result) {
    try {
      const match = rawText.match(/\{[\s\S]*\}/);
      if (match) {
        result = JSON.parse(match[0]);
        console.log("[GATEWAY] Parse strategy 3 succeeded (brace extract)");
      }
    } catch {
    }
  }
  if (!result) {
    console.error("[GATEWAY] All parse strategies failed. Raw:", rawText.slice(0, 500));
    result = {
      spirit: subject,
      summary: "Analysis complete \u2014 see content below.",
      sections: [
        {
          title: "Gateway Analysis",
          items: [rawText]
        }
      ]
    };
  }
  return result;
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "POST required" }), { status: 405, headers });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
  const auth = await resolveUser(token);
  if (!auth.ok) return new Response(JSON.stringify({ error: "Soldier tier or higher required" }), { status: 403, headers });
  const usage = await checkAndIncrementUsage(auth.userId, auth.tier || "watchman", "gateway");
  if (!usage.allowed) {
    return new Response(JSON.stringify({ error: getUpgradeMessage(auth.tier || "watchman", "gateway"), rateLimited: true, limit: usage.limit, remaining: 0 }), { status: 429, headers });
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers });
  }
  const { spiritName = "", personContext = "" } = body || {};
  if (!spiritName?.trim() && !personContext?.trim()) {
    return new Response(JSON.stringify({ error: "Provide a spirit name, cultural exposure context, or both." }), { status: 400, headers });
  }
  try {
    const dbContext = spiritName?.trim() ? await fetchSpiritContext(spiritName.trim()) : "";
    const report = await callClaude(spiritName?.trim() || "", dbContext, personContext?.trim() || "");
    if (auth.userId && _sbUrl && _sbKey) {
      const q = [spiritName?.trim(), personContext?.trim()].filter(Boolean).join(" | ").slice(0, 500);
      fetch(`${_sbUrl}/rest/v1/ai_search_history`, {
        method: "POST",
        headers: { apikey: _sbKey, Authorization: `Bearer ${_sbKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ user_id: auth.userId, tool: "gateway-investigator", query: q, response: JSON.stringify(report).slice(0, 1e3), context: {} })
      }).catch(() => {
      });
    }
    return new Response(JSON.stringify(report), { status: 200, headers });
  } catch (e) {
    console.error("[gateway-investigator] Error:", e.message);
    return new Response(JSON.stringify({ error: e.message || "Investigation failed" }), { status: 500, headers });
  }
}
var config = { path: "/api/gateway-investigator" };
export {
  config,
  handler as default
};
