
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/investigate.ts
import Anthropic from "@anthropic-ai/sdk";

// netlify/lib/ai-rate-limit.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
async function checkAndIncrementUsage(_userId, _tier, _feature) {
  return { allowed: true, remaining: 999, limit: 999, current: 0 };
}
var FEATURE_LABELS = {
  ask_dake: "Ask Dake",
  ai_assistant: "AI Assistant",
  bible_ask: "Bible Study AI",
  symptom_investigator: "Symptom Investigator",
  gateway: "Gateway Investigator",
  dream: "Dream Interpreter",
  document: "Document Creator",
  session_ai: "Session AI",
  assessment: "Assessment Strategy"
};
function getUpgradeMessage(tier, feature) {
  const tiers = {
    watchman: "Soldier",
    free: "Soldier",
    soldier: "Commander",
    charter_soldier: "Commander",
    commander: "General",
    charter_commander: "General"
  };
  const nextTier = tiers[tier];
  const label = FEATURE_LABELS[feature] || feature;
  if (!nextTier) return `You have reached your daily limit for ${label}.`;
  return `Daily limit reached for ${label}. Upgrade to ${nextTier} for more.`;
}

// netlify/lib/clean-ai-output.ts
function cleanAIOutput(text) {
  return text.replace(/\s—\s/g, ", ").replace(/—/g, " - ").replace(/\s–\s/g, ", ").replace(/\bIn conclusion,?\s*/gi, "").replace(/\bTo summarize,?\s*/gi, "").replace(/\bIt is worth noting that\s*/gi, "").replace(/\bIt is important to note that\s*/gi, "").replace(/\bNotably,?\s*/gi, "").replace(/\bFurthermore,?\s*/gi, "").replace(/\bMoreover,?\s*/gi, "").replace(/\bAdditionally,?\s*/gi, "").replace(/\bIn other words,?\s*/gi, "").replace(/\bAs previously mentioned,?\s*/gi, "").replace(/\bAs we can see,?\s*/gi, "").replace(/\bIt goes without saying\s*/gi, "").replace(/\bNeedless to say,?\s*/gi, "").replace(/\bAt the end of the day,?\s*/gi, "").replace(/\bWith that said,?\s*/gi, "").replace(/\bThat being said,?\s*/gi, "").replace(/\bHaving said that,?\s*/gi, "").replace(/  +/g, " ").replace(/\s,/g, ",").trim();
}

// netlify/functions/investigate.ts
var client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
var { url: _sbUrl, serviceRoleKey: _sbKey } = JSON.parse(process.env.SUPABASE || "{}");
function checkRateLimit(_ip) {
  return true;
}
var systemPrompt = `You are a spiritual warfare intelligence analyst for War Room Intel, a platform serving trained deliverance ministers. Your role is to analyze observed symptoms, manifestations, and patterns and return structured intelligence that helps ministers identify probable demonic entities and build a deliverance strategy.

You have deep knowledge of:
- Spirit hierarchy and families (Fear, Rejection, Marine Kingdom, Occult/Witchcraft, Freemasonry, Perversion, Death/Destruction, Religious/Legalism, General Oppression)
- Common entry points: trauma, sexual sin, occult involvement, generational iniquity, unforgiveness, vows and oaths, Freemasonry bloodlines
- Deliverance sequencing: always address legal rights first, then work from outer to inner, strongmen last
- Scripture warfare

Return ONLY valid JSON. No preamble, no markdown, no explanation outside the JSON.

Return this exact structure:
{
  "summary": "2-3 sentence intelligence summary of the pattern you are observing",
  "probableSpirits": [
    {
      "name": "Spirit name",
      "confidence": "High" | "Medium" | "Low",
      "reason": "One sentence explaining why this spirit is indicated",
      "category": "One of: Fear / Rejection | Marine Kingdom | Occult / Witchcraft | Freemasonry | Perversion | Death / Destruction | Religious | General Oppression"
    }
  ],
  "entryPoints": ["entry point 1", "entry point 2"],
  "deliveranceSequence": [
    "Step 1 description",
    "Step 2 description"
  ],
  "counterScriptures": [
    "Reference \u2014 brief quote or description"
  ],
  "warningFlags": [
    "Any red flags or cautions for the minister"
  ]
}

Rules:
- List 3-8 probable spirits ordered by confidence (High first)
- List 4-8 deliverance sequence steps, always starting with legal rights
- List 3-6 counter scriptures
- Warning flags are optional \u2014 only include if there are genuine concerns (DID indicators, suicidal ideation patterns, need for trauma counseling first, etc)
- Stay grounded in biblical deliverance theology
- Do not speculate beyond what the symptoms indicate`;
async function handler(req) {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }
  const jsonHeaders = { "Content-Type": "application/json" };
  try {
    const authHeader = req.headers.get("Authorization");
    const sessionToken = authHeader?.replace("Bearer ", "").trim();
    let userId = "anonymous";
    let tier = "watchman";
    if (sessionToken && sessionToken.split(".").length === 3) {
      try {
        const payload = JSON.parse(Buffer.from(sessionToken.split(".")[1], "base64url").toString());
        userId = payload.sub || "anonymous";
        tier = payload?.publicMetadata?.tier || payload?.public_metadata?.tier || "watchman";
        if (userId !== "anonymous" && process.env.CLERK_SECRET_KEY) {
          try {
            const clerkRes = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
              headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
            });
            if (clerkRes.ok) {
              const clerkData = await clerkRes.json();
              tier = clerkData?.public_metadata?.tier || tier;
            }
          } catch {
          }
        }
      } catch (e) {
        console.warn("JWT resolve failed:", e);
      }
    }
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0].trim() || "unknown";
    if (!checkRateLimit(ip)) {
      return new Response(JSON.stringify({ error: "Rate limit exceeded. Try again in a minute." }), { status: 429, headers: jsonHeaders });
    }
    if (userId !== "anonymous") {
      const usage = await checkAndIncrementUsage(userId, tier, "symptom_investigator");
      if (!usage.allowed) {
        return new Response(JSON.stringify({ error: getUpgradeMessage(tier, "symptom_investigator"), rateLimited: true, limit: usage.limit, remaining: 0 }), { status: 429, headers: jsonHeaders });
      }
    }
    const { symptoms } = await req.json();
    if (!symptoms || typeof symptoms !== "string" || symptoms.trim().length < 5) {
      return new Response(JSON.stringify({ error: "Symptoms required (minimum 5 characters)" }), { status: 400, headers: jsonHeaders });
    }
    const userMessage = `Observed symptoms and manifestations:

${symptoms.trim()}`;
    const timeoutPromise = new Promise(
      (_, reject) => setTimeout(() => reject(new Error("Analysis timeout")), 25e3)
    );
    const message = await Promise.race([
      client.messages.create({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 1500,
        system: systemPrompt,
        messages: [{ role: "user", content: userMessage }]
      }),
      timeoutPromise
    ]);
    const text = cleanAIOutput(message.content[0].type === "text" ? message.content[0].text ?? "" : "");
    const clean = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);
    if (userId !== "anonymous" && _sbUrl && _sbKey) {
      fetch(`${_sbUrl}/rest/v1/ai_search_history`, {
        method: "POST",
        headers: { apikey: _sbKey, Authorization: `Bearer ${_sbKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ user_id: userId, tool: "symptom-investigator", query: symptoms.slice(0, 500), response: text.slice(0, 1e3), context: {} })
      }).catch(() => {
      });
    }
    return new Response(JSON.stringify(parsed), { status: 200, headers: jsonHeaders });
  } catch (e) {
    console.error("Investigate error:", e.message);
    return new Response(JSON.stringify({
      error: e.message === "Analysis timeout" ? "Analysis timed out \u2014 try a shorter description" : "Investigation failed",
      detail: e.message
    }), { status: 500, headers: jsonHeaders });
  }
}
var config = { path: "/api/investigate" };
export {
  config,
  handler as default
};
