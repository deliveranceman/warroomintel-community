
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/intake-request.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function sb() {
  return createClient(supabaseUrl, supabaseServiceKey);
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: HEADERS });
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: HEADERS });
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: HEADERS });
  }
  const { name, email, phone, issues, duration, received_before, description, contact_method } = body || {};
  if (!name?.trim()) {
    return new Response(JSON.stringify({ error: "name is required" }), { status: 400, headers: HEADERS });
  }
  if (!email?.trim()) {
    return new Response(JSON.stringify({ error: "email is required" }), { status: 400, headers: HEADERS });
  }
  const client = sb();
  const { data, error } = await client.from("intake_requests").insert({
    name: name.trim().slice(0, 200),
    email: email.trim().toLowerCase().slice(0, 200),
    phone: phone?.trim().slice(0, 50) || null,
    issues: Array.isArray(issues) ? issues : [],
    duration: duration?.trim().slice(0, 100) || null,
    received_before: Boolean(received_before),
    description: description?.trim().slice(0, 5e3) || null,
    contact_method: contact_method?.trim().slice(0, 50) || "email"
  }).select("id").single();
  if (error) {
    console.error("[intake-request] insert error:", error.message);
    return new Response(JSON.stringify({ error: "Failed to submit request" }), { status: 500, headers: HEADERS });
  }
  const emailBase = `${new URL(req.url).origin}/api/send-email`;
  const emailBody = { name, phone, issues, duration, received_before, description, contact_method };
  Promise.all([
    fetch(emailBase, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "intake-confirmation", to: email.trim().toLowerCase(), name: name.trim(), submissionId: data.id })
    }),
    fetch(emailBase, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type: "intake-admin", to: email.trim().toLowerCase(), name: name.trim(), submissionId: data.id, details: emailBody })
    })
  ]).catch((err) => console.error("[intake-request] email error:", err));
  return new Response(JSON.stringify({ success: true, id: data.id }), { status: 200, headers: HEADERS });
}
var config = { path: "/api/intake-request" };
export {
  config,
  handler as default
};
