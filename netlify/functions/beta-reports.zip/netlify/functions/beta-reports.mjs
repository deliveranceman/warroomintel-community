
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/beta-reports.ts
var { url: supabaseUrl, serviceRoleKey } = JSON.parse(process.env.SUPABASE || "{}");
var sbHeaders = {
  apikey: serviceRoleKey,
  Authorization: `Bearer ${serviceRoleKey}`,
  "Content-Type": "application/json"
};
var sb = (path) => `${supabaseUrl}/rest/v1${path}`;
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, POST, PATCH, OPTIONS"
};
var JSON_HEADERS = { ...CORS, "Content-Type": "application/json" };
function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });
}
function decodeToken(authHeader) {
  if (!authHeader) return null;
  const token = authHeader.replace(/^Bearer\s+/i, "").trim();
  if (!token) return null;
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return null;
    const userName = payload.name || [payload.firstName, payload.lastName].filter(Boolean).join(" ") || userId;
    return { userId, userName };
  } catch {
    return null;
  }
}
async function getIsMinister(userId) {
  try {
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return false;
    const data = await res.json();
    const meta = data.public_metadata || {};
    return meta.role === "minister" || meta.isAdmin === true;
  } catch {
    return false;
  }
}
async function getList(userId, isMinister, params) {
  const type = params.get("type") || "";
  const status = params.get("status") || "";
  const sort = params.get("sort") || "new";
  const mine = params.get("mine") === "true";
  const selectFields = isMinister ? "id,user_id,user_name,type,title,description,page_section,screenshot_url,screenshot_url_2,screenshot_url_3,status,priority,upvotes,upvoted_by,admin_notes,fix_summary,fixed_at,created_at,updated_at" : "id,user_id,user_name,type,title,description,page_section,screenshot_url,screenshot_url_2,screenshot_url_3,status,priority,upvotes,upvoted_by,fix_summary,fixed_at,created_at,updated_at";
  let url = `${sb("/beta_reports")}?select=${selectFields}&limit=200`;
  if (type) url += `&type=eq.${encodeURIComponent(type)}`;
  if (mine) url += `&user_id=eq.${encodeURIComponent(userId)}`;
  if (status === "open") {
    url += `&status=in.(new,confirmed,in_progress)`;
  } else if (status === "fixed") {
    url += `&status=in.(fixed,deployed)`;
  }
  url += sort === "top" ? `&order=upvotes.desc,created_at.desc` : `&order=created_at.desc`;
  const res = await fetch(url, { headers: sbHeaders });
  if (!res.ok) return json({ error: "Database error", detail: await res.text() }, 500);
  return json({ reports: await res.json() });
}
async function getStats() {
  const res = await fetch(
    `${sb("/beta_reports")}?select=id,type,status,upvotes,title&limit=1000`,
    { headers: sbHeaders }
  );
  if (!res.ok) return json({ error: "Database error" }, 500);
  const all = await res.json();
  const byStatus = {
    new: 0,
    confirmed: 0,
    in_progress: 0,
    fixed: 0,
    deployed: 0,
    wont_fix: 0,
    by_design: 0,
    duplicate: 0
  };
  const byType = { bug: 0, feature: 0, question: 0, praise: 0 };
  for (const r of all) {
    if (r.status in byStatus) byStatus[r.status]++;
    if (r.type in byType) byType[r.type]++;
  }
  const topUpvoted = [...all].sort((a, b) => (b.upvotes || 0) - (a.upvotes || 0)).slice(0, 5).map((r) => ({ id: r.id, title: r.title, upvotes: r.upvotes, status: r.status, type: r.type }));
  return json({ total: all.length, byStatus, byType, topUpvoted });
}
async function submitReport(userId, userName, body) {
  const { type, title, description, pageSection, screenshotUrl, screenshotUrl2, screenshotUrl3 } = body || {};
  const validTypes = ["bug", "feature", "question", "praise"];
  if (!type || !validTypes.includes(type)) return json({ error: "Invalid type" }, 400);
  if (!title?.trim() || title.length > 120) return json({ error: "title required, max 120 chars" }, 400);
  if (!description?.trim() || description.length > 3e3) return json({ error: "description required, max 3000 chars" }, 400);
  const res = await fetch(`${sb("/beta_reports")}?select=*`, {
    method: "POST",
    headers: { ...sbHeaders, Prefer: "return=representation" },
    body: JSON.stringify({
      user_id: userId,
      user_name: userName,
      type,
      title: title.trim(),
      description: description.trim(),
      page_section: pageSection || null,
      screenshot_url: screenshotUrl || null,
      screenshot_url_2: screenshotUrl2 || null,
      screenshot_url_3: screenshotUrl3 || null
    })
  });
  if (!res.ok) return json({ error: "Insert failed", detail: await res.text() }, 500);
  const rows = await res.json();
  return json({ report: rows[0] ?? null }, 201);
}
async function upvoteReport(userId, body) {
  const { reportId } = body || {};
  if (!reportId) return json({ error: "reportId required" }, 400);
  const getRes = await fetch(
    `${sb("/beta_reports")}?id=eq.${encodeURIComponent(reportId)}&select=upvoted_by,upvotes`,
    { headers: sbHeaders }
  );
  if (!getRes.ok) return json({ error: "Database error" }, 500);
  const rows = await getRes.json();
  if (!rows.length) return json({ error: "Not found" }, 404);
  const upvotedBy = rows[0].upvoted_by || [];
  const alreadyVoted = upvotedBy.includes(userId);
  const newUpvotedBy = alreadyVoted ? upvotedBy.filter((id) => id !== userId) : [...upvotedBy, userId];
  const patchRes = await fetch(`${sb("/beta_reports")}?id=eq.${encodeURIComponent(reportId)}`, {
    method: "PATCH",
    headers: { ...sbHeaders, Prefer: "return=minimal" },
    body: JSON.stringify({ upvoted_by: newUpvotedBy, upvotes: newUpvotedBy.length })
  });
  if (!patchRes.ok) return json({ error: "Update failed" }, 500);
  return json({ upvoted: !alreadyVoted, upvotes: newUpvotedBy.length });
}
async function triageReport(userId, isMinister, body) {
  void userId;
  if (!isMinister) return json({ error: "Forbidden" }, 403);
  const { id, status, priority, adminNotes, fixSummary } = body || {};
  if (!id) return json({ error: "id required" }, 400);
  const patch = { updated_at: (/* @__PURE__ */ new Date()).toISOString() };
  if (status !== void 0) patch.status = status;
  if (priority !== void 0) patch.priority = priority;
  if (adminNotes !== void 0) patch.admin_notes = adminNotes;
  if (fixSummary !== void 0) patch.fix_summary = fixSummary;
  if (status === "fixed" || status === "deployed") patch.fixed_at = (/* @__PURE__ */ new Date()).toISOString();
  const patchRes = await fetch(`${sb("/beta_reports")}?id=eq.${encodeURIComponent(id)}&select=*`, {
    method: "PATCH",
    headers: { ...sbHeaders, Prefer: "return=representation" },
    body: JSON.stringify(patch)
  });
  if (!patchRes.ok) return json({ error: "Update failed", detail: await patchRes.text() }, 500);
  const resRows = await patchRes.json();
  return json({ report: resRows[0] ?? null });
}
async function uploadScreenshot(userId, req) {
  const formData = await req.formData();
  const file = formData.get("file");
  if (!file || typeof file === "string") return json({ error: "file required" }, 400);
  const f = file;
  if (!["image/jpeg", "image/png", "image/gif", "image/webp"].includes(f.type))
    return json({ error: "image files only (jpeg, png, gif, webp)" }, 400);
  if (f.size > 10 * 1024 * 1024) return json({ error: "max 10MB" }, 400);
  const buffer = Buffer.from(await f.arrayBuffer());
  const safeName = f.name.replace(/[^a-zA-Z0-9._-]/g, "_");
  const timestamp = Date.now();
  const filePath = `beta/${userId}/${timestamp}-${safeName}`;
  const uploadRes = await fetch(`${supabaseUrl}/storage/v1/object/beta-screenshots/${filePath}`, {
    method: "POST",
    headers: {
      apikey: serviceRoleKey,
      Authorization: `Bearer ${serviceRoleKey}`,
      "Content-Type": f.type
    },
    body: buffer
  });
  if (!uploadRes.ok) return json({ error: "Upload failed", detail: await uploadRes.text() }, 500);
  const url = `${supabaseUrl}/storage/v1/object/public/beta-screenshots/${filePath}`;
  return json({ url });
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const auth = decodeToken(req.headers.get("Authorization"));
  if (!auth) return json({ error: "Unauthorized" }, 401);
  const { userId, userName } = auth;
  const url = new URL(req.url);
  const action = url.searchParams.get("action") ?? "";
  if (action === "upload") return uploadScreenshot(userId, req);
  if (action === "stats") return getStats();
  if (action === "upvote") {
    const body = await req.json().catch(() => ({}));
    return upvoteReport(userId, body);
  }
  if (req.method === "GET") {
    const isMinister = await getIsMinister(userId);
    return getList(userId, isMinister, url.searchParams);
  }
  if (req.method === "POST") {
    const body = await req.json().catch(() => ({}));
    return submitReport(userId, userName, body);
  }
  if (req.method === "PATCH") {
    const isMinister = await getIsMinister(userId);
    const body = await req.json().catch(() => ({}));
    return triageReport(userId, isMinister, body);
  }
  return json({ error: "Not found" }, 404);
}
var config = { path: "/api/beta-reports" };
export {
  config,
  handler as default
};
