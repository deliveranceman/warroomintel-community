
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/spirit-of-day.ts
var { url: supabaseUrl, serviceRoleKey } = JSON.parse(process.env.SUPABASE || "{}");
var { token: airtableToken } = JSON.parse(process.env.AIRTABLE || "{}");
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, OPTIONS"
};
var JSON_HEADERS = { ...CORS, "Content-Type": "application/json" };
var BASE_ID = "appVXEj2DLPBTJTtD";
var TABLE_ID = "tblcP4lgVykzOhLi4";
var NAME_FIELD = "\u2694 WAR ROOM COMMUNITY \u2014 MASTER DEMON DATABASE";
var SB = (p) => `${supabaseUrl}/rest/v1${p}`;
var sbH = {
  apikey: serviceRoleKey,
  Authorization: `Bearer ${serviceRoleKey}`,
  "Content-Type": "application/json",
  Prefer: "return=representation"
};
var DAY_THEMES = {
  0: "revival",
  1: "control",
  2: "warfare",
  3: "deception",
  4: "oppression",
  5: "affliction",
  6: "infirmity"
};
function decodeUserId(authHeader) {
  if (!authHeader) return null;
  const token = authHeader.replace(/^Bearer\s+/i, "").trim();
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    return payload.sub ?? null;
  } catch {
    return null;
  }
}
function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });
}
async function fetchFromAirtable(formula) {
  const url = new URL(`https://api.airtable.com/v0/${BASE_ID}/${TABLE_ID}`);
  url.searchParams.set("pageSize", "20");
  url.searchParams.set("filterByFormula", formula);
  for (const f of [NAME_FIELD, "Manifestiation", "Legal Rights", "Scripture Context", "Kingdom"]) {
    url.searchParams.append("fields[]", f);
  }
  const res = await fetch(url.toString(), {
    headers: { Authorization: `Bearer ${airtableToken}` }
  });
  if (!res.ok) return [];
  const data = await res.json();
  return data.records || [];
}
async function getRecentSpiritIds() {
  const sevenDaysAgo = /* @__PURE__ */ new Date();
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
  const from = sevenDaysAgo.toISOString().slice(0, 10);
  const res = await fetch(
    SB(`/spirit_of_day_cache?cache_date=gte.${from}&select=spirit_id`),
    { headers: sbH }
  );
  const rows = await res.json().catch(() => []);
  return new Set(Array.isArray(rows) ? rows.map((r) => r.spirit_id).filter(Boolean) : []);
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const userId = decodeUserId(req.headers.get("Authorization"));
  if (!userId) return json({ error: "Unauthorized" }, 401);
  const url = new URL(req.url);
  const today = url.searchParams.get("date") || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const cacheRes = await fetch(SB(`/spirit_of_day_cache?cache_date=eq.${today}&select=*`), { headers: sbH });
  const cacheRows = await cacheRes.json().catch(() => []);
  if (Array.isArray(cacheRows) && cacheRows[0]) {
    const r = cacheRows[0];
    return json({
      spirit: {
        name: r.spirit_name,
        manifestation: r.manifestation,
        legalGround: r.legal_ground,
        scripture: r.scripture,
        spiritId: r.spirit_id
      }
    });
  }
  const dayOfWeek = (/* @__PURE__ */ new Date(today + "T12:00:00")).getDay();
  const theme = DAY_THEMES[dayOfWeek] || "warfare";
  const recentIds = await getRecentSpiritIds();
  let records = await fetchFromAirtable(
    `SEARCH("${theme}", LOWER({Kingdom})) > 0`
  );
  if (!records.length) {
    records = await fetchFromAirtable(`{${NAME_FIELD}} != ""`);
  }
  const pick = records.find((r) => r.id && !recentIds.has(r.id)) || records[0];
  if (!pick) return json({ spirit: null });
  const f = pick.fields;
  const name = (f[NAME_FIELD] || "").trim();
  const manifestation = (f["Manifestiation"] || "").slice(0, 120).trim();
  const legalGround = (f["Legal Rights"] || "").slice(0, 100).trim();
  const scriptureRaw = f["Scripture Context"] || "";
  const scriptureMatch = scriptureRaw.match(/[1-3]?\s?[A-Z][a-z]+\.?\s+\d+:\d+[-\d]*/)?.[0] || scriptureRaw.slice(0, 60);
  const scripture = scriptureMatch.trim();
  if (!name) return json({ spirit: null });
  const row = {
    cache_date: today,
    spirit_name: name,
    manifestation: manifestation || null,
    legal_ground: legalGround || null,
    scripture: scripture || null,
    spirit_id: pick.id
  };
  await fetch(SB("/spirit_of_day_cache"), {
    method: "POST",
    headers: sbH,
    body: JSON.stringify(row)
  }).catch(() => {
  });
  return json({
    spirit: {
      name,
      manifestation: manifestation || null,
      legalGround: legalGround || null,
      scripture: scripture || null,
      spiritId: pick.id
    }
  });
}
var config = { path: "/api/spirit-of-day" };
export {
  config,
  handler as default
};
