
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/library-intelligence.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var { token: airtableToken } = JSON.parse(process.env.AIRTABLE || "{}");
var MAX_BOOKS = 20;
var AT_TOKEN = () => airtableToken;
var AT_BASE = "appVXEj2DLPBTJTtD";
var AT_TABLE = "tblcP4lgVykzOhLi4";
var AT_NAME_FIELD = "\u2694 WAR ROOM COMMUNITY \u2014 MASTER DEMON DATABASE";
async function fetchExistingSpiritNames() {
  const names = /* @__PURE__ */ new Set();
  let offset;
  try {
    do {
      const url = new URL(`https://api.airtable.com/v0/${AT_BASE}/${AT_TABLE}`);
      url.searchParams.set("pageSize", "100");
      url.searchParams.append("fields[]", AT_NAME_FIELD);
      if (offset) url.searchParams.set("offset", offset);
      const res = await fetch(url.toString(), {
        headers: { Authorization: `Bearer ${AT_TOKEN()}` },
        signal: AbortSignal.timeout(12e3)
      });
      if (!res.ok) {
        console.error("[GAP] Airtable error:", res.status);
        break;
      }
      const data = await res.json();
      for (const r of data.records || []) {
        const n = r.fields[AT_NAME_FIELD];
        if (n && n !== "Primary Name") names.add(n.toLowerCase().trim());
      }
      offset = data.offset;
    } while (offset);
  } catch (e) {
    console.error("[GAP] Airtable fetch failed:", e.message);
  }
  return { names, total: names.size };
}
var headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function sb() {
  return createClient(supabaseUrl, supabaseServiceKey);
}
async function fetchLibraryBooks() {
  const { data, error } = await sb().from("resources").select("id, title, author, extracted_text").eq("topic", "ministry-library").not("extracted_text", "is", null).limit(MAX_BOOKS);
  console.log("[LIB-INTEL] Books found:", data?.length ?? 0, error?.message ?? null);
  return data || [];
}
function cleanExtractedText(raw) {
  if (typeof raw !== "string") return "";
  return raw.replace(/\0/g, " ").replace(/[^\x09\x0A\x0D\x20-\x7E]/g, " ").replace(/\s+/g, " ").trim();
}
async function claudeCall(system, user) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model: "claude-sonnet-4-5", max_tokens: 4e3, system, messages: [{ role: "user", content: user }] })
  });
  if (!res.ok) throw new Error(`Claude API error: ${res.status}`);
  const data = await res.json();
  return data.content?.[0]?.text || "";
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers });
  const body = await req.json().catch(() => ({}));
  const { tool, query } = body;
  console.log("[LIBRARY-INTEL] tool:", tool, "query:", query?.slice(0, 80));
  const authHeader = req.headers.get("Authorization") || "";
  const rawToken = authHeader.replace("Bearer ", "").trim();
  let userId = "";
  if (rawToken && rawToken.split(".").length === 3) {
    try {
      const payload = JSON.parse(Buffer.from(rawToken.split(".")[1], "base64url").toString("utf8"));
      userId = payload.sub || payload.userId || "";
    } catch (e) {
      console.error("[LIB-INTEL] JWT decode failed:", e);
    }
  }
  if (!userId && tool !== "gap-analysis" && tool !== "content-query") {
    return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
  }
  if (tool === "gap-analysis") {
    console.log("[GAP] Gap analysis \u2014 fetching library cache + Airtable names");
    const client = sb();
    const [{ data: cached, error: cacheErr }, { data: books }, { names: existingNames, total: spiritCount }] = await Promise.all([
      client.from("library_spirit_cache").select("spirit_name, normalized_name, source, confidence").order("confidence", { ascending: false }).limit(200),
      client.from("resources").select("title").eq("topic", "ministry-library"),
      fetchExistingSpiritNames()
    ]);
    if (cacheErr) {
      return new Response(JSON.stringify({ error: cacheErr.message }), { status: 500, headers });
    }
    console.log(`[GAP] Library cache: ${cached?.length ?? 0} entries, Airtable: ${spiritCount} spirits`);
    const seen = /* @__PURE__ */ new Set();
    const gaps = (cached || []).filter((r) => {
      const normalizedKey = r.normalized_name?.toLowerCase().trim() ?? "";
      if (seen.has(normalizedKey)) return false;
      seen.add(normalizedKey);
      if (existingNames.has(r.spirit_name.toLowerCase().trim())) return false;
      if (normalizedKey && existingNames.has(normalizedKey)) return false;
      return true;
    }).map((r) => ({
      name: r.spirit_name,
      description: "Found in your ministry library",
      source: r.source,
      suggested_kingdom: "Unknown",
      confidence: r.confidence
    }));
    return new Response(JSON.stringify({
      gaps,
      spiritCount,
      summary: `Found ${gaps.length} spirits in your library not yet in your database (${spiritCount} spirits already in DB).`,
      bookCount: books?.length || 0,
      bookTitles: (books || []).map((b) => b.title)
    }), { status: 200, headers });
  }
  if (tool === "content-query") {
    if (!query?.trim()) return new Response(JSON.stringify({ error: "query required" }), { status: 400, headers });
    const OPENAI_KEY = process.env.OPENAI_API_KEY || "";
    let libraryText = "";
    let bookTitles = [];
    if (OPENAI_KEY) {
      try {
        const embRes = await fetch("https://api.openai.com/v1/embeddings", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${OPENAI_KEY}` },
          body: JSON.stringify({ model: "text-embedding-3-small", input: [query.trim()] }),
          signal: AbortSignal.timeout(8e3)
        });
        if (embRes.ok) {
          const embData = await embRes.json();
          const vector = embData.data?.[0]?.embedding;
          if (vector) {
            const { data: chunks } = await sb().rpc("match_library_chunks", {
              query_embedding: vector,
              match_threshold: 0.6,
              match_count: 8
            });
            if (chunks?.length > 0) {
              libraryText = chunks.map((c) => `[From "${c.book_title}" \u2014 similarity ${(c.similarity * 100).toFixed(0)}%]:
${c.chunk_text}`).join("\n\n---\n\n");
              bookTitles = Array.from(new Set(chunks.map((c) => c.book_title)));
              console.log(`[CONTENT-QUERY] Vector search: ${chunks.length} chunks from ${bookTitles.length} books`);
            }
          }
        }
      } catch (e) {
        console.log("[CONTENT-QUERY] Vector search failed, using full-text fallback:", e.message);
      }
    }
    if (!libraryText) {
      const books = await fetchLibraryBooks();
      if (!books.length) return new Response(JSON.stringify({ error: "No library content available." }), { status: 400, headers });
      bookTitles = books.map((b) => `${b.title}${b.author ? ` by ${b.author}` : ""}`);
      libraryText = books.map(
        (b) => `[${b.title}${b.author ? ` by ${b.author}` : ""}]:
${cleanExtractedText(b.extracted_text).slice(0, 3e3)}`
      ).join("\n\n---\n\n");
    }
    const system = `You are a ministry content strategist for War Room Intel (warroomintel.com), a spiritual warfare platform for deliverance ministers. The platform has: Intel Archive (demon database), Field Ministry (knowledge base articles), Arsenal (scripture library), Assessment (diagnostic wizard), Training (courses/episodes), Fringe Intelligence (articles), Testimony Wall, Prayer Wall, Body Map, Spirit Network, Spiritual Mapping module. You have access to the admin's internal ministry library. Answer questions about what content exists in the library and how it could be used to build out the platform.`;
    const userMsg = `${query.trim()}

Library documents:
${libraryText}`;
    const response = await claudeCall(system, userMsg);
    return new Response(JSON.stringify({ response, bookTitles }), { status: 200, headers });
  }
  return new Response(JSON.stringify({ error: "Unknown tool. Use gap-analysis or content-query." }), { status: 400, headers });
}
var config = { path: "/api/library-intelligence" };
export {
  config,
  handler as default
};
