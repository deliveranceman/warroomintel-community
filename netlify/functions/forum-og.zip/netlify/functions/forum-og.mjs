
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/forum-og.ts
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function extractYouTubeId(url) {
  const patterns = [
    /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/v\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/
  ];
  for (const re of patterns) {
    const m = url.match(re);
    if (m) return m[1];
  }
  return null;
}
function extractMeta(html, property) {
  const patterns = [
    new RegExp(`<meta[^>]+property=["']${property}["'][^>]+content=["']([^"']+)["']`, "i"),
    new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+property=["']${property}["']`, "i"),
    new RegExp(`<meta[^>]+name=["']${property.replace("og:", "")}["'][^>]+content=["']([^"']+)["']`, "i"),
    new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+name=["']${property.replace("og:", "")}["']`, "i")
  ];
  for (const re of patterns) {
    const m = html.match(re);
    if (m?.[1]) return m[1].replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;/g, "'").trim();
  }
  return "";
}
function extractTitle(html) {
  const m = html.match(/<title[^>]*>([^<]+)<\/title>/i);
  return m?.[1]?.replace(/&amp;/g, "&").replace(/&quot;/g, '"').trim() || "";
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: HEADERS });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "POST required" }), { status: 405, headers: HEADERS });
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: HEADERS });
  }
  const { url: rawUrl } = body;
  if (!rawUrl?.trim()) return new Response(JSON.stringify({ error: "url required" }), { status: 400, headers: HEADERS });
  let parsedUrl;
  try {
    parsedUrl = new URL(rawUrl.trim());
  } catch {
    return new Response(JSON.stringify({ error: "Invalid URL" }), { status: 400, headers: HEADERS });
  }
  const domain = parsedUrl.hostname.replace("www.", "");
  const ytId = extractYouTubeId(rawUrl);
  if (ytId) {
    return new Response(JSON.stringify({
      title: "",
      thumbnail: `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`,
      description: "",
      url: rawUrl,
      domain
    }), { status: 200, headers: HEADERS });
  }
  try {
    const res = await fetch(rawUrl, {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; WarRoomBot/1.0)" },
      signal: AbortSignal.timeout(8e3)
    });
    if (!res.ok) return new Response(JSON.stringify({ title: "", thumbnail: "", description: "", url: rawUrl, domain }), { status: 200, headers: HEADERS });
    const html = await res.text();
    const title = extractMeta(html, "og:title") || extractTitle(html);
    const thumbnail = extractMeta(html, "og:image");
    const description = extractMeta(html, "og:description");
    return new Response(JSON.stringify({ title, thumbnail, description, url: rawUrl, domain }), { status: 200, headers: HEADERS });
  } catch {
    return new Response(JSON.stringify({ title: "", thumbnail: "", description: "", url: rawUrl, domain }), { status: 200, headers: HEADERS });
  }
}
var config = { path: "/api/forum-og" };
export {
  config,
  handler as default
};
