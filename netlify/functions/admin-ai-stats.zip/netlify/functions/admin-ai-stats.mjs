
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-ai-stats.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function sb() {
  return createClient(supabaseUrl, supabaseServiceKey);
}
async function resolveAdminOrMinister(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return { ok: false, reason: "Invalid JWT" };
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return { ok: false, reason: "No userId in token" };
    const clerkRes = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!clerkRes.ok) return { ok: false, reason: `Clerk error ${clerkRes.status}` };
    const clerkUser = await clerkRes.json();
    const role = clerkUser?.public_metadata?.role;
    if (role !== "admin" && role !== "minister") {
      return { ok: false, reason: `Forbidden \u2014 admin or minister role required (got: ${role ?? "none"})` };
    }
    return { ok: true, reason: "" };
  } catch (e) {
    return { ok: false, reason: e instanceof Error ? e.message : "Auth error" };
  }
}
var ZERO_STATS = { totalCalls: 0, totalTokens: 0, totalCost: 0, topUsers: [] };
async function handler(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: HEADERS });
  }
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: HEADERS });
  }
  const auth = await resolveAdminOrMinister(token);
  if (!auth.ok) {
    const status = auth.reason.startsWith("Forbidden") ? 403 : 401;
    return new Response(JSON.stringify({ error: auth.reason }), { status, headers: HEADERS });
  }
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const supabase = sb();
  const { data: rows, error } = await supabase.from("ai_usage").select("user_id, call_count, tokens_used, cost_usd").eq("date", today);
  if (error) {
    if (error.code === "42P01" || error.message?.includes("does not exist")) {
      return new Response(JSON.stringify(ZERO_STATS), { status: 200, headers: HEADERS });
    }
    return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: HEADERS });
  }
  if (!rows || rows.length === 0) {
    return new Response(JSON.stringify(ZERO_STATS), { status: 200, headers: HEADERS });
  }
  let totalCalls = 0;
  let totalTokens = 0;
  let totalCost = 0;
  for (const row of rows) {
    totalCalls += Number(row.call_count) || 0;
    totalTokens += Number(row.tokens_used) || 0;
    totalCost += Number(row.cost_usd) || 0;
  }
  const topUsers = [...rows].sort((a, b) => (Number(b.call_count) || 0) - (Number(a.call_count) || 0)).slice(0, 5).map((r) => ({
    userId: r.user_id,
    calls: Number(r.call_count) || 0,
    cost: Number(r.cost_usd) || 0
  }));
  return new Response(
    JSON.stringify({ totalCalls, totalTokens, totalCost, topUsers }),
    { status: 200, headers: HEADERS }
  );
}
var config = { path: "/api/admin-ai-stats" };
export {
  config,
  handler as default
};
