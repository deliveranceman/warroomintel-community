
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/verify-tier.ts
async function resolveUser(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return null;
    const userRes = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!userRes.ok) return null;
    const userData = await userRes.json();
    return { userId, userData };
  } catch {
    return null;
  }
}
var headers = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
  const auth = await resolveUser(token);
  if (!auth) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
  const tier = auth.userData?.public_metadata?.tier || "free";
  const role = auth.userData?.public_metadata?.role || null;
  return new Response(JSON.stringify({ tier, role, userId: auth.userId }), { status: 200, headers });
}
var config = { path: "/api/verify-tier" };
export {
  config,
  handler as default
};
