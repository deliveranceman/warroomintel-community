
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-resources.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey, bucket: supabaseBucket } = JSON.parse(process.env.SUPABASE || "{}");
var CLERK_SECRET = process.env.CLERK_SECRET_KEY;
var SUPABASE_URL = supabaseUrl;
var SUPABASE_KEY = supabaseServiceKey;
var BUCKET = supabaseBucket || "resources";
async function resolveUser(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) {
      console.error("Token is not a JWT \u2014 parts:", parts.length);
      return null;
    }
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    console.log("JWT payload sub:", payload.sub);
    console.log("JWT payload azp:", payload.azp);
    const userId = payload.sub;
    if (!userId) {
      console.error("No sub in JWT payload");
      return null;
    }
    const userRes = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${CLERK_SECRET}` }
    });
    console.log("User fetch status:", userRes.status);
    if (!userRes.ok) return null;
    const userData = await userRes.json();
    console.log("publicMetadata:", JSON.stringify(userData?.public_metadata));
    return { userId, userData };
  } catch (e) {
    console.error("resolveUser error:", e);
    return null;
  }
}
async function handler(req) {
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });
  const auth = await resolveUser(token);
  if (!auth) return new Response(JSON.stringify({ error: "Unauthorized \u2014 invalid session" }), { status: 401 });
  if (auth.userData?.public_metadata?.role !== "minister") {
    return new Response(JSON.stringify({
      error: "Forbidden \u2014 minister role required",
      debug: { userId: auth.userId, role: auth.userData?.public_metadata?.role, allMetadata: auth.userData?.public_metadata }
    }), { status: 403 });
  }
  const { userId: _userId } = auth;
  const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
  if (req.method === "GET") {
    const { data, error } = await supabase.from("resources").select("*").eq("source_type", "arsenal").order("created_at", { ascending: false });
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    return new Response(JSON.stringify({ resources: data }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  }
  if (req.method === "PATCH") {
    let body;
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400 });
    }
    if (Array.isArray(body?.ids)) {
      const { ids, tier: tier2, topic: topic2 } = body;
      if (!ids.length) return new Response(JSON.stringify({ error: "ids required" }), { status: 400 });
      const updates2 = {};
      if (tier2 !== void 0 && tier2) updates2.tier = tier2;
      if (topic2 !== void 0 && topic2) updates2.topic = topic2;
      if (!Object.keys(updates2).length) return new Response(JSON.stringify({ error: "no updates provided" }), { status: 400 });
      const { error: error2 } = await supabase.from("resources").update(updates2).in("id", ids);
      if (error2) return new Response(JSON.stringify({ error: error2.message }), { status: 500 });
      return new Response(JSON.stringify({ success: true, updated: ids.length }), { status: 200, headers: { "Content-Type": "application/json" } });
    }
    const { id, title, tier, topic, notes, tags, spirit_tags } = body || {};
    if (!id) return new Response(JSON.stringify({ error: "id required" }), { status: 400 });
    const updates = {};
    if (title !== void 0) updates.title = title;
    if (tier !== void 0) updates.tier = tier;
    if (topic !== void 0) updates.topic = topic;
    if (notes !== void 0) updates.notes = notes;
    if (tags !== void 0) updates.tags = Array.isArray(tags) ? tags : [];
    if (spirit_tags !== void 0) updates.spirit_tags = Array.isArray(spirit_tags) ? spirit_tags : [];
    const { data: row, error } = await supabase.from("resources").update(updates).eq("id", id).select().single();
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500 });
    return new Response(JSON.stringify({ resource: row }), { status: 200, headers: { "Content-Type": "application/json" } });
  }
  if (req.method === "DELETE") {
    const url = new URL(req.url);
    const idsParam = url.searchParams.get("ids");
    const id = url.searchParams.get("id");
    if (idsParam) {
      const ids = idsParam.split(",").filter(Boolean);
      if (!ids.length) return new Response(JSON.stringify({ error: "ids required" }), { status: 400 });
      const { data: rows } = await supabase.from("resources").select("file_path").in("id", ids);
      const paths = (rows || []).map((r) => r.file_path).filter(Boolean);
      if (paths.length) await supabase.storage.from(BUCKET).remove(paths);
      const { error } = await supabase.from("resources").delete().in("id", ids);
      if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500 });
      return new Response(JSON.stringify({ success: true, deleted: ids.length }), { status: 200, headers: { "Content-Type": "application/json" } });
    }
    if (!id) return new Response(JSON.stringify({ error: "id required" }), { status: 400 });
    const { data: row, error: fetchErr } = await supabase.from("resources").select("file_path").eq("id", id).single();
    if (fetchErr || !row) return new Response(JSON.stringify({ error: "Resource not found" }), { status: 404 });
    await supabase.storage.from(BUCKET).remove([row.file_path]);
    const { error: deleteErr } = await supabase.from("resources").delete().eq("id", id);
    if (deleteErr) return new Response(JSON.stringify({ error: deleteErr.message }), { status: 500 });
    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });
  }
  return new Response("Method not allowed", { status: 405 });
}
var config = { path: "/api/admin-resources" };
export {
  config,
  handler as default
};
