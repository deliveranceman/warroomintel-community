
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/download.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey, bucket: supabaseBucket } = JSON.parse(process.env.SUPABASE || "{}");
var CLERK_SECRET = process.env.CLERK_SECRET_KEY;
var SUPABASE_URL = supabaseUrl;
var SUPABASE_KEY = supabaseServiceKey;
var EXPIRY_SECS = 14400;
var TIER_ORDER = {
  free: 0,
  Free: 0,
  soldier: 1,
  Soldier: 1,
  commander: 2,
  Commander: 2,
  general: 3,
  General: 3
};
function bucketForPath(filePath) {
  return filePath.startsWith("user_") ? "ministry-library" : supabaseBucket || "resources";
}
async function verifyAndGetTier(token) {
  const verifyRes = await fetch("https://api.clerk.com/v1/sessions/verify", {
    method: "POST",
    headers: { Authorization: `Bearer ${CLERK_SECRET}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ token })
  });
  if (!verifyRes.ok) return null;
  const session = await verifyRes.json();
  const userId = session.user_id;
  if (!userId) return null;
  const userRes = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
    headers: { Authorization: `Bearer ${CLERK_SECRET}` }
  });
  if (!userRes.ok) return null;
  const userData = await userRes.json();
  const tier = userData.public_metadata?.tier || "Free";
  return { userId, tier };
}
async function handler(req) {
  if (req.method !== "GET") return new Response("Method not allowed", { status: 405 });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401 });
  const auth = await verifyAndGetTier(token);
  if (!auth) return new Response(JSON.stringify({ error: "Invalid session" }), { status: 401 });
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (!id) return new Response(JSON.stringify({ error: "id required" }), { status: 400 });
  const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
  const { data: resource, error } = await supabase.from("resources").select("tier, file_path").eq("id", id).single();
  if (error || !resource) return new Response(JSON.stringify({ error: "Resource not found" }), { status: 404 });
  const userLevel = TIER_ORDER[auth.tier] ?? 0;
  const resourceLevel = TIER_ORDER[resource.tier] ?? 0;
  if (userLevel < resourceLevel) {
    return new Response(JSON.stringify({ error: `${resource.tier} tier required` }), { status: 403 });
  }
  const bucket = bucketForPath(resource.file_path);
  const { data: signed, error: signErr } = await supabase.storage.from(bucket).createSignedUrl(resource.file_path, EXPIRY_SECS);
  if (signErr || !signed?.signedUrl) {
    return new Response(JSON.stringify({ error: "Could not generate download link" }), { status: 500 });
  }
  return new Response(JSON.stringify({ url: signed.signedUrl }), {
    status: 200,
    headers: { "Content-Type": "application/json" }
  });
}
var config = { path: "/api/download" };
export {
  config,
  handler as default
};
