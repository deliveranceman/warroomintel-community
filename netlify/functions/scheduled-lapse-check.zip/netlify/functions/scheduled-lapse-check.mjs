
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/scheduled-lapse-check.ts
var SIX_MONTHS_MS = 6 * 30 * 24 * 60 * 60 * 1e3;
var PAID_TIERS = /* @__PURE__ */ new Set(["soldier", "commander", "general"]);
async function listClerkUsers(page, limit = 100) {
  const offset = page * limit;
  const res = await fetch(
    `https://api.clerk.com/v1/users?limit=${limit}&offset=${offset}&order_by=-created_at`,
    { headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` } }
  );
  if (!res.ok) return [];
  return res.json();
}
async function downgradeUser(userId, currentMeta) {
  await fetch(`https://api.clerk.com/v1/users/${userId}`, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      public_metadata: {
        ...currentMeta,
        tier: "watchman",
        lapseDowngradedAt: (/* @__PURE__ */ new Date()).toISOString(),
        preLapseTier: currentMeta.tier
      }
    })
  });
}
async function handler() {
  console.log("\u{1F550} Lapse check starting...");
  const cutoff = Date.now() - SIX_MONTHS_MS;
  let page = 0;
  let totalChecked = 0;
  let totalDowngraded = 0;
  while (true) {
    const users = await listClerkUsers(page);
    if (!users.length) break;
    for (const user of users) {
      totalChecked++;
      const meta = user.public_metadata || {};
      const tier = (meta.tier || "watchman").toLowerCase();
      if (!PAID_TIERS.has(tier)) continue;
      if (meta.foundingMember || meta.foundingGeneral) continue;
      const lastLogin = meta.last_login_at ? new Date(meta.last_login_at).getTime() : null;
      if (lastLogin !== null && lastLogin > cutoff) continue;
      const createdAt = new Date(user.created_at).getTime();
      if (!lastLogin && createdAt > cutoff) continue;
      await downgradeUser(user.id, meta);
      totalDowngraded++;
      console.log(`\u2B07 Lapse downgrade: ${user.id} (${tier} \u2192 watchman), last login: ${meta.last_login_at || "never"}`);
    }
    if (users.length < 100) break;
    page++;
  }
  console.log(`\u2705 Lapse check done. Checked: ${totalChecked}, Downgraded: ${totalDowngraded}`);
}
var config = { schedule: "@daily" };
export {
  config,
  handler as default
};
