
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-tracker.ts
import { createClient } from "@supabase/supabase-js";
var { url: supabaseUrl, serviceRoleKey: supabaseServiceKey } = JSON.parse(process.env.SUPABASE || "{}");
var HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function sb() {
  return createClient(supabaseUrl, supabaseServiceKey);
}
async function isMinister(token) {
  try {
    if (!token || token.split(".").length !== 3) return { ok: false, name: "" };
    const payload = JSON.parse(Buffer.from(token.split(".")[1], "base64url").toString());
    const userId = payload.sub;
    if (!userId) return { ok: false, name: "" };
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return { ok: false, name: "" };
    const data = await res.json();
    const ok = data?.public_metadata?.role === "minister";
    const name = [data.first_name, data.last_name].filter(Boolean).join(" ") || data.username || "Minister";
    return { ok, name };
  } catch {
    return { ok: false, name: "" };
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: HEADERS });
  const token = req.headers.get("Authorization")?.replace("Bearer ", "").trim();
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: HEADERS });
  const { ok, name: ministerName } = await isMinister(token);
  if (!ok) return new Response(JSON.stringify({ error: "Minister role required" }), { status: 403, headers: HEADERS });
  const client = sb();
  if (req.method === "GET") {
    const url = new URL(req.url);
    const category = url.searchParams.get("category");
    let query = client.from("admin_tracker").select("*").order("category").order("name");
    if (category) query = query.eq("category", category);
    const { data, error } = await query;
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: HEADERS });
    return new Response(JSON.stringify({ items: data }), { status: 200, headers: HEADERS });
  }
  if (req.method === "POST") {
    let body;
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: HEADERS });
    }
    const { category, name, route, description, status, notes, priority, external_url, metadata } = body || {};
    if (!category || !name) return new Response(JSON.stringify({ error: "category and name required" }), { status: 400, headers: HEADERS });
    const { data, error } = await client.from("admin_tracker").insert({
      category,
      name,
      route,
      description,
      status: status || "in_progress",
      notes,
      priority: priority || "medium",
      external_url,
      metadata: metadata || {}
    }).select().single();
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: HEADERS });
    return new Response(JSON.stringify({ item: data }), { status: 200, headers: HEADERS });
  }
  if (req.method === "PATCH") {
    let body;
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: HEADERS });
    }
    const { id, ...fields } = body || {};
    if (!id) return new Response(JSON.stringify({ error: "id required" }), { status: 400, headers: HEADERS });
    const updates = { updated_at: (/* @__PURE__ */ new Date()).toISOString() };
    for (const k of ["status", "notes", "priority", "name", "description", "route", "external_url", "metadata"]) {
      if (k in fields) updates[k] = fields[k];
    }
    if (fields.status === "approved") {
      updates.approved_by = ministerName;
      updates.approved_at = (/* @__PURE__ */ new Date()).toISOString();
    } else if (fields.status && fields.status !== "approved") {
      updates.approved_by = null;
      updates.approved_at = null;
    }
    const { data, error } = await client.from("admin_tracker").update(updates).eq("id", id).select().single();
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: HEADERS });
    return new Response(JSON.stringify({ item: data }), { status: 200, headers: HEADERS });
  }
  if (req.method === "DELETE") {
    const url = new URL(req.url);
    const id = url.searchParams.get("id");
    if (!id) return new Response(JSON.stringify({ error: "id required" }), { status: 400, headers: HEADERS });
    const { error } = await client.from("admin_tracker").delete().eq("id", id);
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: HEADERS });
    return new Response(JSON.stringify({ ok: true }), { status: 200, headers: HEADERS });
  }
  return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: HEADERS });
}
var config = { path: "/api/admin-tracker" };
export {
  config,
  handler as default
};
