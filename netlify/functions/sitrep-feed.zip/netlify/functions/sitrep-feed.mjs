
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/sitrep-feed.mts
import crypto from "crypto";
import { createClient } from "@supabase/supabase-js";
var { apiKey, apiSecret } = JSON.parse(process.env.STREAM || "{}");
var { url: supabaseUrl, serviceRoleKey } = JSON.parse(process.env.SUPABASE || "{}");
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS"
};
var JSON_HEADERS = { ...CORS, "Content-Type": "application/json" };
var FEEDS_BASE = "https://us-east-api.stream-io-api.com/api/v1.0";
var TIER_LEVEL = {
  watchman: 0,
  free: 0,
  soldier: 1,
  charter_soldier: 1,
  commander: 2,
  charter_commander: 2,
  general: 3,
  founding_general: 3,
  minister: 99
};
function serverJWT() {
  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
  const body = Buffer.from(JSON.stringify({ resource: "*", action: "*", feed_id: "*" })).toString("base64url");
  const sig = crypto.createHmac("sha256", apiSecret ?? "").update(`${header}.${body}`).digest("base64url");
  return `${header}.${body}.${sig}`;
}
function userJWT(userId) {
  const header = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
  const body = Buffer.from(JSON.stringify({ user_id: userId })).toString("base64url");
  const sig = crypto.createHmac("sha256", apiSecret ?? "").update(`${header}.${body}`).digest("base64url");
  return `${header}.${body}.${sig}`;
}
function feedHeaders() {
  console.log("[sitrep] auth: JWT {resource:*,action:*,feed_id:*}, apiKey:", apiKey, "secret exists:", !!apiSecret);
  return {
    "Content-Type": "application/json",
    Authorization: serverJWT(),
    "stream-auth-type": "jwt"
  };
}
function feedUrl(path) {
  const sep = path.includes("?") ? "&" : "?";
  return `${FEEDS_BASE}${path}${sep}api_key=${apiKey}`;
}
function extractUserId(authHeader) {
  if (!authHeader) return null;
  const token = authHeader.replace(/^Bearer\s+/i, "").trim();
  if (!token) return null;
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    return payload.sub ?? null;
  } catch {
    return null;
  }
}
function extractTierFromJWT(authHeader) {
  if (!authHeader) return "watchman";
  const token = authHeader.replace(/^Bearer\s+/i, "").trim();
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return "watchman";
    const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
    return payload?.publicMetadata?.tier || payload?.public_metadata?.tier || "watchman";
  } catch {
    return "watchman";
  }
}
async function resolveUserInfo(userId, jwtTier = "watchman") {
  try {
    const res = await fetch(`https://api.clerk.com/v1/users/${userId}`, {
      headers: { Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}` }
    });
    if (!res.ok) return { tier: jwtTier, name: userId };
    const data = await res.json();
    const tier = data.public_metadata?.tier?.toLowerCase() || (data.public_metadata?.role === "minister" ? "minister" : jwtTier);
    const name = [data.first_name, data.last_name].filter(Boolean).join(" ") || data.username || userId;
    return { tier, name };
  } catch {
    return { tier: jwtTier, name: userId };
  }
}
function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });
}
async function feedFetch(url, method = "GET", body) {
  console.log("[sitrep] feedFetch:", method, url.replace(/api_key=[^&]+/, "api_key=***"));
  const res = await fetch(url, {
    method,
    headers: feedHeaders(),
    body: body !== void 0 ? JSON.stringify(body) : void 0
  });
  let data;
  try {
    data = await res.json();
  } catch {
    data = {};
  }
  console.log("[sitrep] response:", res.status, JSON.stringify(data).slice(0, 200));
  return { status: res.status, data };
}
async function upsertUser(userId, name) {
  await feedFetch(feedUrl("/users/"), "POST", {
    users: [{ id: userId, name: name || userId }]
  }).catch(() => {
  });
}
async function getToken(userId) {
  const token = userJWT(userId);
  return json({ token });
}
async function uploadPhoto(userId, req) {
  const formData = await req.formData();
  const file = formData.get("file");
  if (!file || typeof file === "string") return json({ error: "file required" }, 400);
  const f = file;
  if (!f.type.startsWith("image/")) return json({ error: "image files only" }, 400);
  if (f.size > 10 * 1024 * 1024) return json({ error: "max 10MB" }, 400);
  const arrayBuffer = await f.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  const safeName = f.name.replace(/[^a-zA-Z0-9._-]/g, "_");
  const fileName = `sitrep/${userId}/${Date.now()}-${safeName}`;
  const sb = createClient(supabaseUrl, serviceRoleKey);
  const { error } = await sb.storage.from("sitrep-photos").upload(fileName, buffer, { contentType: f.type, upsert: false });
  if (error) return json({ error: error.message }, 500);
  const { data: { publicUrl } } = sb.storage.from("sitrep-photos").getPublicUrl(fileName);
  return json({ url: publicUrl });
}
async function postActivity(userId, userTier, userName, body) {
  const { type, text, imageUrl, scriptureRef, spiritTag, locationTag, photoUrl, resourceUrl } = body;
  const validTypes = ["thought", "scripture", "testimony", "resource", "photo", "prayer", "revelation", "field"];
  if (!validTypes.includes(type)) return json({ error: "Invalid type" }, 400);
  if (type !== "photo" && !text?.trim()) return json({ error: "text required" }, 400);
  const tierLevel = TIER_LEVEL[userTier] ?? 0;
  if (tierLevel < 1) return json({ error: "Soldier tier required to post" }, 403);
  const now = Date.now();
  const activityBody = {
    verb: type,
    object: `post:${now}`,
    foreign_id: `post:${userId}:${now}`,
    time: (/* @__PURE__ */ new Date()).toISOString(),
    text: String(text || "").slice(0, 1e3),
    actor: userId,
    userName,
    userTier,
    // fan-out: Stream copies this activity to wri-community feed automatically
    to: ["user:wri-community"],
    data: {
      type,
      imageUrl: imageUrl || null,
      scriptureRef: scriptureRef || null,
      spiritTag: spiritTag || null,
      locationTag: locationTag || null,
      photoUrl: photoUrl || null,
      resourceUrl: resourceUrl || null
    }
  };
  await upsertUser(userId, userName);
  const { status, data } = await feedFetch(feedUrl(`/feed/user/${userId}/`), "POST", { activities: [activityBody] });
  if (status >= 400) {
    return json({ error: "Failed to post", detail: data }, 502);
  }
  const activity = data?.activities?.[0] || activityBody;
  return json({ ok: true, activityId: activity.id || `post:${userId}:${now}`, activity });
}
async function getTimeline(userId, params) {
  const limit = parseInt(params.get("limit") || "20", 10);
  const idLt = params.get("id_lt") || "";
  const tab = params.get("tab") || "all";
  upsertUser(userId).catch(() => {
  });
  feedFetch(feedUrl(`/feed/timeline/${userId}/follows/`), "POST", {
    target: "user:wri-community",
    activity_copy_limit: 300
  }).catch(() => {
  });
  const ltParam = idLt ? `&id_lt=${encodeURIComponent(idLt)}` : "";
  const feedPath = tab === "following" ? `/feed/timeline/${userId}/?limit=${limit}${ltParam}` : `/feed/user/wri-community/?limit=${limit}${ltParam}`;
  const { data } = await feedFetch(feedUrl(feedPath));
  const activities = data?.results || [];
  activities.sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime());
  const page = activities.slice(0, limit);
  const next = page.length >= limit ? page[page.length - 1]?.id || null : null;
  return json({ activities: page, next });
}
async function getUserFeed(params) {
  const targetUserId = params.get("userId") || "";
  if (!targetUserId) return json({ error: "userId required" }, 400);
  const limit = parseInt(params.get("limit") || "20", 10);
  const idLt = params.get("id_lt") || "";
  const ltParam = idLt ? `&id_lt=${encodeURIComponent(idLt)}` : "";
  const { data } = await feedFetch(feedUrl(`/feed/user/${targetUserId}/?limit=${limit}${ltParam}`));
  const activities = data?.results || [];
  const next = activities.length >= limit ? activities[activities.length - 1]?.id || null : null;
  return json({ activities, next });
}
async function follow(userId, body) {
  const { targetUserId } = body;
  if (!targetUserId) return json({ error: "targetUserId required" }, 400);
  const { status, data } = await feedFetch(
    feedUrl(`/feed/timeline/${userId}/follows/`),
    "POST",
    { target: `user:${targetUserId}`, activity_copy_limit: 10 }
  );
  if (status >= 400) return json({ error: "Follow failed", detail: data }, 502);
  return json({ ok: true });
}
async function unfollow(userId, body) {
  const { targetUserId } = body;
  if (!targetUserId) return json({ error: "targetUserId required" }, 400);
  const { status, data } = await feedFetch(
    feedUrl(`/feed/timeline/${userId}/follows/user:${targetUserId}/`),
    "DELETE"
  );
  if (status >= 400 && status !== 404) return json({ error: "Unfollow failed", detail: data }, 502);
  return json({ ok: true });
}
async function getFollowers(userId, params) {
  const targetUserId = params.get("userId") || userId;
  const [followersRes, followingRes] = await Promise.all([
    feedFetch(feedUrl(`/feed/user/${targetUserId}/followers/?limit=50`)),
    feedFetch(feedUrl(`/feed/timeline/${userId}/follows/?limit=200`))
  ]);
  const followers = (followersRes.data?.results || []).map((f) => f.feed_id?.split(":")[1]).filter(Boolean);
  const following = (followingRes.data?.results || []).map((f) => f.target_id?.split(":")[1]).filter(Boolean);
  return json({ followers, following, followingSet: following });
}
async function react(userId, body) {
  const { activityId, kind } = body;
  if (!activityId || !kind) return json({ error: "activityId and kind required" }, 400);
  const validKinds = ["cover", "pray", "relay"];
  if (!validKinds.includes(kind)) return json({ error: "Invalid reaction kind" }, 400);
  const { status, data } = await feedFetch(feedUrl("/reaction/"), "POST", {
    kind,
    activity_id: activityId,
    user_id: userId
  });
  if (status >= 400) return json({ error: "Reaction failed", detail: data }, 502);
  return json({ ok: true });
}
async function solPicks() {
  const { data } = await feedFetch(feedUrl("/feed/user/wri-community/?limit=50"));
  const activities = data?.results || [];
  if (!activities.length) return json({ picks: [] });
  const Anthropic = (await import("@anthropic-ai/sdk")).default;
  const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  try {
    const message = await anthropic.messages.create({
      model: "claude-sonnet-4-5",
      max_tokens: 256,
      system: 'You are SOL, the AI intelligence officer for War Room Intel, a spiritual warfare ministry platform. Review these recent field reports and community posts from deliverance ministers. Select the 5 most valuable, spiritually significant, or tactically useful posts. Return ONLY a JSON array of activity ids: ["id1","id2","id3","id4","id5"]. No explanation.',
      messages: [{
        role: "user",
        content: JSON.stringify(activities.map((a) => ({ id: a.id, type: a.verb, text: a.data?.text || a.text || "", time: a.time })))
      }]
    });
    const text = message.content[0].type === "text" ? message.content[0].text : "[]";
    const match = text.match(/\[[\s\S]*\]/);
    const ids = match ? JSON.parse(match[0]) : [];
    const idSet = new Set(ids);
    const picks = activities.filter((a) => idSet.has(a.id)).slice(0, 5);
    return json({ picks });
  } catch {
    return json({ picks: activities.slice(0, 5) });
  }
}
async function handler(req) {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const userId = extractUserId(req.headers.get("Authorization"));
  if (!userId) return json({ error: "Unauthorized" }, 401);
  const url = new URL(req.url);
  const action = url.searchParams.get("action") ?? "";
  if (action === "get-token") return getToken(userId);
  if (action === "sol-picks") return solPicks();
  if (action === "get-timeline") return getTimeline(userId, url.searchParams);
  if (action === "get-user-feed") return getUserFeed(url.searchParams);
  if (action === "get-followers") return getFollowers(userId, url.searchParams);
  if (action === "upload-photo") return uploadPhoto(userId, req);
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  const body = await req.json().catch(() => ({}));
  if (action === "post") {
    const jwtTier = extractTierFromJWT(req.headers.get("Authorization"));
    const { tier, name } = await resolveUserInfo(userId, jwtTier);
    return postActivity(userId, tier, name, body);
  }
  if (action === "follow") return follow(userId, body);
  if (action === "unfollow") return unfollow(userId, body);
  if (action === "react") return react(userId, body);
  return json({ error: "Unknown action" }, 400);
}
var config = { path: "/api/sitrep-feed" };
export {
  config,
  handler as default
};
